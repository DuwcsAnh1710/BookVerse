# Bookverse - Nền Tảng Thương Mại Điện Tử Hiện Đại Cho Sách

Một nền tảng thương mại điện tử toàn diện được xây dựng với Node.js, Express, MongoDB và PHP. Bookverse cung cấp giải pháp marketplace hoàn chỉnh cho việc mua bán sách với các tính năng tiên tiến bao gồm quản lý người dùng, dashboard người bán, panel quản trị và hệ thống thanh toán tích hợp.

## 🚀 Tính Năng

### Tính Năng Công Khai
- **Trang Chủ Hiện Đại** với hero section và nội dung nổi bật
- **Danh Sách Sản Phẩm Nâng Cao** với bộ lọc, tìm kiếm và phân trang
- **Trang Chi Tiết Sản Phẩm** với đánh giá và gợi ý
- **Trang Giới Thiệu** với thông tin đội ngũ và câu chuyện công ty
- **Trang Demo** giới thiệu tất cả tính năng của nền tảng

### Tính Năng Người Dùng
- **Đăng Ký & Xác Thực Người Dùng** với JWT tokens
- **Quản Lý Hồ Sơ** với thông tin cá nhân
- **Theo Dõi Đơn Hàng** với cập nhật trạng thái thời gian thực
- **Tính Năng Yêu Thích** để lưu sách yêu thích
- **Hệ Thống Ví Điện Tử** cho nạp tiền và thanh toán
- **Đặt Lại Mật Khẩu** với xác thực OTP

### Tính Năng Người Bán
- **Đăng Ký Người Bán** với thông tin kinh doanh
- **Quản Lý Sản Phẩm** với các thao tác CRUD
- **Quản Lý Đơn Hàng** với theo dõi trạng thái
- **Thiết Lập Tài Khoản Ngân Hàng** cho xử lý thanh toán
- **Phân Tích Dashboard** với thông tin bán hàng
- **Theo Dõi Hoa Hồng** với giám sát quản trị

### Tính Năng Quản Trị
- **Hệ Thống Đăng Nhập Admin** với xác thực bảo mật
- **Quản Lý Người Dùng** với kiểm soát truy cập dựa trên vai trò
- **Giám Sát Sản Phẩm** với quy trình phê duyệt
- **Quản Lý Đơn Hàng** với theo dõi toàn diện
- **Hệ Thống Thanh Toán & Hoa Hồng**
- **Giám Sát Sức Khỏe Hệ Thống**

## 🛠️ Công Nghệ Sử Dụng

### Backend
- **Node.js** - Môi trường runtime
- **Express.js** - Framework web
- **MongoDB** - Cơ sở dữ liệu với Mongoose ODM
- **JWT** - Token xác thực
- **bcrypt** - Mã hóa mật khẩu
- **CORS** - Chia sẻ tài nguyên đa nguồn

### Frontend
- **PHP** - Render phía server
- **HTML5** - Đánh dấu ngữ nghĩa
- **CSS3** - Styling hiện đại với biến
- **JavaScript (ES6+)** - Chức năng phía client
- **Responsive Design** - Thiết kế mobile-first

### Thư Viện & Công Cụ Chính
- **Mongoose** - Mô hình hóa đối tượng MongoDB
- **Express-validator** - Xác thực đầu vào
- **Multer** - Xử lý upload file
- **Nodemailer** - Dịch vụ email
- **Rate limiting** - Bảo vệ API

## 📁 Cấu Trúc Dự Án

```
Bookverse/
├── backend/
│   ├── config/
│   │   └── database.js
│   ├── middlewares/
│   │   ├── auth.js
│   │   └── validation.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Product.js
│   │   ├── Category.js
│   │   ├── Order.js
│   │   ├── Review.js
│   │   ├── Payment.js
│   │   └── Transaction.js
│   ├── routes/
│   │   ├── auth.js
│   │   ├── users.js
│   │   ├── products.js
│   │   ├── orders.js
│   │   ├── reviews.js
│   │   ├── admin.js
│   │   └── payments.js
│   ├── scripts/
│   │   └── seed.js
│   ├── package.json
│   └── server.js
├── frontend/
│   ├── assets/
│   │   ├── css/
│   │   │   ├── main.css
│   │   │   ├── responsive.css
│   │   │   ├── auth.css
│   │   │   ├── account.css
│   │   │   ├── seller.css
│   │   │   ├── admin.css
│   │   │   ├── cart.css
│   │   │   ├── checkout.css
│   │   │   ├── products.css
│   │   │   ├── product-detail.css
│   │   │   ├── about.css
│   │   │   ├── wallet.css
│   │   │   └── bank-account.css
│   │   ├── js/
│   │   │   ├── main.js
│   │   │   ├── api.js
│   │   │   ├── auth.js
│   │   │   ├── admin-auth.js
│   │   │   ├── seller.js
│   │   │   ├── admin.js
│   │   │   ├── cart.js
│   │   │   ├── checkout.js
│   │   │   ├── product.js
│   │   │   ├── products.js
│   │   │   └── pages/
│   │   │       ├── profile.js
│   │   │       ├── orders.js
│   │   │       ├── wishlist.js
│   │   │       ├── wallet.js
│   │   │       ├── bank-account.js
│   │   │       └── products-list.js
│   │   └── images/
│   │       ├── logo.svg
│   │       ├── logo-text.svg
│   │       ├── logo-icon.svg
│   │       └── placeholder-book.svg
│   ├── includes/
│   │   ├── header.php
│   │   ├── footer.php
│   │   ├── navigation-simple.php
│   │   ├── auth-header.php
│   │   └── auth-footer.php
│   ├── pages/
│   │   ├── auth/
│   │   │   ├── login.php
│   │   │   ├── register.php
│   │   │   ├── forgot.php
│   │   │   ├── reset.php
│   │   │   └── seller-register.php
│   │   ├── admin/
│   │   │   ├── login.php
│   │   │   └── dashboard.php
│   │   ├── seller/
│   │   │   ├── dashboard.php
│   │   │   ├── products.php
│   │   │   ├── orders.php
│   │   │   └── bank-account.php
│   │   ├── account/
│   │   │   ├── profile.php
│   │   │   ├── orders.php
│   │   │   ├── wishlist.php
│   │   │   └── wallet.php
│   │   ├── products/
│   │   │   ├── list.php
│   │   │   └── detail.php
│   │   ├── cart/
│   │   │   └── cart.php
│   │   └── checkout/
│   │       ├── checkout.php
│   │       └── success.php
│   ├── index.php
│   ├── about.php
│   └── demo.php
├── database/
├── README.md
├── DEVELOPMENT_GUIDE.md
├── QUICK_START.md
└── PROGRESS_REPORT.md
```

## 🚀 Hướng Dẫn Bắt Đầu

### Yêu Cầu Hệ Thống
- Node.js (v14 trở lên)
- MongoDB (v4.4 trở lên)
- PHP (v7.4 trở lên)
- XAMPP hoặc máy chủ local tương tự

### Cài Đặt

1. **Clone repository**
   ```bash
   git clone https://github.com/yourusername/bookverse.git
   cd bookverse
   ```

2. **Thiết Lập Backend**
   ```bash
   cd backend
   npm install
   cp env.example .env
   # Chỉnh sửa .env với chuỗi kết nối MongoDB của bạn
   npm start
   ```

3. **Thiết Lập Frontend**
   - Đặt thư mục `frontend` vào thư mục web server (ví dụ: XAMPP htdocs)
   - Đảm bảo PHP được cấu hình và chạy
   - Truy cập qua `http://localhost/Bookverse/frontend/`

4. **Thiết Lập Cơ Sở Dữ Liệu**
   ```bash
   cd backend
   node scripts/seed.js
   ```

### Biến Môi Trường

Tạo file `.env` trong thư mục backend:

```env
PORT=3000
MONGODB_URI=mongodb://localhost:27017/bookverse
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRE=7d
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_email_password
```

## 🔧 API Endpoints

### Xác Thực
- `POST /api/auth/register` - Đăng ký người dùng
- `POST /api/auth/login` - Đăng nhập người dùng
- `POST /api/auth/forgot-password` - Yêu cầu đặt lại mật khẩu
- `POST /api/auth/reset-password` - Đặt lại mật khẩu với OTP
- `POST /api/auth/change-password` - Thay đổi mật khẩu

### Người Dùng
- `GET /api/users/profile` - Lấy thông tin hồ sơ người dùng
- `PUT /api/users/profile` - Cập nhật hồ sơ người dùng
- `GET /api/users/orders` - Lấy đơn hàng của người dùng

### Sản Phẩm
- `GET /api/products` - Lấy tất cả sản phẩm
- `GET /api/products/:id` - Lấy sản phẩm theo ID
- `POST /api/products` - Tạo sản phẩm (Người bán)
- `PUT /api/products/:id` - Cập nhật sản phẩm (Người bán)
- `DELETE /api/products/:id` - Xóa sản phẩm (Người bán)

### Đơn Hàng
- `GET /api/orders` - Lấy đơn hàng của người dùng
- `POST /api/orders` - Tạo đơn hàng mới
- `PUT /api/orders/:id` - Cập nhật trạng thái đơn hàng

### Quản Trị
- `GET /api/admin/dashboard` - Dữ liệu dashboard quản trị
- `GET /api/admin/users` - Lấy tất cả người dùng
- `GET /api/admin/orders` - Lấy tất cả đơn hàng
- `GET /api/admin/payments` - Lấy dữ liệu thanh toán

## 🎨 Hệ Thống Thiết Kế

### Bảng Màu
- Chính: #3B82F6 (Xanh dương)
- Phụ: #10B981 (Xanh lá)
- Nhấn: #F59E0B (Vàng)
- Trung tính: #6B7280 (Xám)
- Nền: #F9FAFB (Xám nhạt)

### Typography
- Tiêu đề: Inter, system-ui, sans-serif
- Nội dung: system-ui, -apple-system, sans-serif
- Code: 'Fira Code', 'Monaco', monospace

### Thành Phần
- **Navigation**: Hệ thống điều hướng thông minh với menu dựa trên vai trò
- **Cards**: Thiết kế card nhất quán với hiệu ứng hover
- **Forms**: Form có thể truy cập với xác thực
- **Buttons**: Các biến thể chính, phụ và nguy hiểm
- **Modals**: Dialog modal responsive

## 🔐 Tính Năng Bảo Mật

- **Xác Thực JWT** với xử lý token bảo mật
- **Mã Hóa Mật Khẩu** sử dụng bcrypt
- **Xác Thực Đầu Vào** với express-validator
- **Giới Hạn Tốc Độ** để ngăn chặn lạm dụng
- **Cấu Hình CORS** cho yêu cầu đa nguồn
- **Bảo Vệ SQL Injection** với truy vấn tham số hóa
- **Bảo Vệ XSS** với làm sạch đầu vào

## 📱 Thiết Kế Responsive

- **Mobile-First** approach
- **Breakpoints**: 320px, 768px, 1024px, 1280px
- **Giao Diện Thân Thiện** với cảm ứng
- **Hình Ảnh Tối Ưu** với lazy loading
- **Cải Tiến Dần** cho trình duyệt cũ

## 🧪 Kiểm Thử

### Kiểm Thử Thủ Công
- Tương thích đa trình duyệt (Chrome, Firefox, Safari, Edge)
- Responsive trên mobile (iOS, Android)
- Xác thực form và xử lý lỗi
- Điều hướng và luồng người dùng

### Hiệu Suất
- **Điểm Lighthouse**: 90+ trên tất cả các chỉ số
- **Core Web Vitals**: Tối ưu cho LCP, FID, CLS
- **Tối Ưu Hình Ảnh**: Định dạng WebP với fallback
- **Chia Nhỏ Code**: Tải JavaScript hiệu quả

## 🚀 Triển Khai

### Triển Khai Backend
1. Deploy lên Heroku, Vercel, hoặc AWS
2. Thiết lập MongoDB Atlas cho cơ sở dữ liệu production
3. Cấu hình biến môi trường
4. Thiết lập chứng chỉ SSL

### Triển Khai Frontend
1. Deploy lên Netlify, Vercel, hoặc GitHub Pages
2. Cấu hình quy trình build
3. Thiết lập CDN cho assets
4. Bật HTTPS

## 🤝 Đóng Góp

1. Fork repository
2. Tạo feature branch (`git checkout -b feature/amazing-feature`)
3. Commit thay đổi (`git commit -m 'Add amazing feature'`)
4. Push lên branch (`git push origin feature/amazing-feature`)
5. Mở Pull Request

### Hướng Dẫn Phát Triển
- Tuân theo style code hiện có
- Viết commit message có ý nghĩa
- Thêm comment cho logic phức tạp
- Kiểm thử thay đổi kỹ lưỡng
- Cập nhật tài liệu khi cần

## 📄 Giấy Phép

Dự án này được cấp phép dưới MIT License - xem file [LICENSE](LICENSE) để biết chi tiết.

## 👥 Đội Ngũ

- **Nguyễn Trường Phục** - Trưởng Dự Án & Full-Stack Developer
- **Nguyễn Đức Lượng** - Backend Developer & Chuyên Gia API
- **Lê Đức Anh** - Frontend Developer & UI/UX Designer
- **Nguyễn Minh Huy** - Kiến Trúc Sư Database & DevOps Engineer
- **Nguyễn Phạm Thiên Phước** - Chuyên Gia Kiểm Thử & QA

## 📞 Hỗ Trợ

Để được hỗ trợ, email support@bookverse.com hoặc tham gia cộng đồng Discord của chúng tôi.

## 🔮 Lộ Trình Phát Triển

### Giai Đoạn 1 (Hiện Tại)
- ✅ Xác thực và quản lý người dùng
- ✅ Danh mục sản phẩm và tìm kiếm
- ✅ Giỏ hàng và thanh toán
- ✅ Dashboard người bán và quản lý
- ✅ Panel quản trị và giám sát
- ✅ Tích hợp hệ thống thanh toán

### Giai Đoạn 2 (Kế Hoạch)
- 🔄 Phân tích và báo cáo nâng cao
- 🔄 Ứng dụng di động (React Native)
- 🔄 Thông báo thời gian thực
- 🔄 Tìm kiếm nâng cao với AI
- 🔄 Hỗ trợ đa ngôn ngữ

### Giai Đoạn 3 (Tương Lai)
- 🔄 Tích hợp Blockchain
- 🔄 Xem trước sách AR/VR
- 🔄 Tính năng xã hội và đánh giá
- 🔄 Mô hình đăng ký
- 🔄 Marketplace API

---

**Bookverse** - Nơi sách gặp gỡ công nghệ. Được xây dựng với niềm đam mê cho tình yêu đọc sách và sức mạnh của phát triển web hiện đại.
