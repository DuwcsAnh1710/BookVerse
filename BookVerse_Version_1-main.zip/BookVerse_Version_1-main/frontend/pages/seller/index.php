<?php
/**
 * Seller Pages Index - Should not be accessed directly
 * This file exists to prevent directory listing
 * All seller pages should be accessed directly (dashboard.php, products.php, etc.)
 */

// If someone accesses /seller/ or /seller/index.php, show a proper page
header('HTTP/1.1 200 OK');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Dashboard - Bookverse</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            background: white;
            padding: 3rem;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            text-align: center;
            max-width: 500px;
        }
        h1 {
            color: #667eea;
            margin-bottom: 1rem;
        }
        p {
            color: #666;
            margin-bottom: 2rem;
        }
        .links {
            display: grid;
            gap: 1rem;
        }
        a {
            display: block;
            padding: 1rem;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 600;
            transition: transform 0.2s;
        }
        a:hover {
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏪 Seller Dashboard</h1>
        <p>Chọn trang bạn muốn truy cập:</p>
        <div class="links">
            <a href="dashboard.php">📊 Dashboard</a>
            <a href="products.php">📦 Quản lý Sản phẩm</a>
            <a href="orders.php">🛒 Quản lý Đơn hàng</a>
            <a href="settings.php">⚙️ Cài đặt</a>
            <a href="bank-account.php">🏦 Tài khoản Ngân hàng</a>
            <a href="../../index.php">🏠 Về Trang chủ</a>
        </div>
    </div>
</body>
</html>

