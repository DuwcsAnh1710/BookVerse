<?php 
$pageTitle='Quản lý sản phẩm'; 
$path = '../../'; // Set path for footer.php to load scripts correctly
$extraCss=['assets/css/global.css', 'assets/css/seller.css']; 
$extraJs=[]; // Core JS loaded by footer, no extra JS needed
include __DIR__.'/../../includes/header.php'; 
?>

<!-- Client-side auth check -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<!-- Load CSS -->
<link rel="stylesheet" href="../../assets/css/seller.css">

<!-- Note: Core JS (config, api, main) are loaded by footer.php -->

<!-- Breadcrumb -->
<nav class="breadcrumb" aria-label="Breadcrumb">
    <div class="container">
        <ol class="breadcrumb-list">
            <li><a href="../../index.php">Trang chủ</a></li>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li aria-current="page">Quản lý sản phẩm</li>
        </ol>
    </div>
</nav>

<main class="seller-main">
    <div class="container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <div class="header-info">
                    <h1>Quản lý sản phẩm</h1>
                    <p>Quản lý và theo dõi sản phẩm của bạn</p>
                </div>
                <div class="header-actions">
                    <button class="btn btn-primary" id="addProductBtn">
                        <span class="btn-icon">➕</span>
                        <span>Thêm sản phẩm</span>
                    </button>
                    <button class="btn btn-outline" id="exportProductsBtn">
                        <span class="btn-icon">📊</span>
                        <span>Xuất báo cáo</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Filters and Search -->
        <div class="products-filters">
            <div class="filters-left">
                <div class="search-box">
                    <input type="text" id="searchInput" placeholder="Tìm kiếm sản phẩm..." />
                    <button class="search-btn" id="searchBtn">
                        <span class="search-icon">🔍</span>
                    </button>
                </div>
                
                <select id="categoryFilter" class="filter-select">
                    <option value="">Tất cả danh mục</option>
                </select>
                
                <select id="statusFilter" class="filter-select">
                    <option value="">Tất cả trạng thái</option>
                    <option value="pending">Chờ duyệt</option>
                    <option value="approved">Đã duyệt</option>
                    <option value="rejected">Bị từ chối</option>
                    <option value="inactive">Không hoạt động</option>
                </select>
            </div>
            
            <div class="filters-right">
                <select id="sortFilter" class="filter-select">
                    <option value="newest">Mới nhất</option>
                    <option value="oldest">Cũ nhất</option>
                    <option value="price-high">Giá cao nhất</option>
                    <option value="price-low">Giá thấp nhất</option>
                    <option value="sales">Bán chạy nhất</option>
                    <option value="rating">Đánh giá cao nhất</option>
                </select>
                
                <div class="view-toggle">
                    <button class="view-btn active" data-view="grid" title="Xem dạng lưới">
                        <span>⊞</span>
                    </button>
                    <button class="view-btn" data-view="list" title="Xem dạng danh sách">
                        <span>☰</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Batch Actions -->
        <div class="batch-actions" id="batchActions" style="display: none;">
            <div class="batch-info">
                <span id="selectedCount">0</span> sản phẩm được chọn
            </div>
            <div class="batch-buttons">
                <button class="btn btn-outline btn-sm" id="batchActivate">Kích hoạt</button>
                <button class="btn btn-outline btn-sm" id="batchDeactivate">Tạm dừng</button>
                <button class="btn btn-outline btn-sm" id="batchDelete">Xóa</button>
            </div>
        </div>

        <!-- Products Container -->
        <div class="products-container">
            <div id="productsLoading" class="loading-state">
                <div class="loading-spinner"></div>
                <p>Đang tải sản phẩm...</p>
            </div>
            
            <div id="productsGrid" class="products-grid" style="display: none;">
                <!-- Products will be loaded here -->
            </div>
            
            <div id="productsList" class="products-list" style="display: none;">
                <!-- Products list view will be loaded here -->
            </div>
            
            <div id="productsEmpty" class="empty-state" style="display: none;">
                <div class="empty-icon">📦</div>
                <h3>Chưa có sản phẩm nào</h3>
                <p>Bắt đầu thêm sản phẩm đầu tiên của bạn!</p>
                <button class="btn btn-primary" id="addFirstProduct">
                    <span class="btn-icon">➕</span>
                    <span>Thêm sản phẩm đầu tiên</span>
                </button>
            </div>
        </div>

        <!-- Pagination -->
        <div id="productsPagination" class="pagination" style="display: none;">
            <!-- Pagination will be loaded here -->
        </div>
    </div>
</main>

<!-- Add/Edit Product Modal -->
<div id="addProductModal" class="modal" style="display: none;">
    <div class="modal-overlay"></div>
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h2 id="modalTitle">Thêm sản phẩm mới</h2>
            <button class="modal-close" id="closeAddProductModal">×</button>
        </div>
        <div class="modal-body">
            <form id="addProductForm" class="product-form">
                <div id="productError" class="error-message" style="display: none;"></div>
                <div id="productSuccess" class="success-message" style="display: none;"></div>
                
                <!-- Basic Information -->
                <div class="form-section">
                    <h3>Thông tin cơ bản</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="productTitle">Tên sản phẩm *</label>
                            <input type="text" id="productTitle" name="title" required placeholder="Nhập tên sản phẩm" />
                        </div>
                        <div class="form-group">
                            <label for="productAuthor">Tác giả *</label>
                            <input type="text" id="productAuthor" name="author" required placeholder="Nhập tên tác giả" />
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="productPublisher">Nhà xuất bản</label>
                            <input type="text" id="productPublisher" name="publisher" placeholder="Nhập nhà xuất bản" />
                        </div>
                        <div class="form-group">
                            <label for="productIsbn">ISBN</label>
                            <input type="text" id="productIsbn" name="isbn" placeholder="Nhập mã ISBN" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="productDescription">Mô tả sản phẩm</label>
                        <textarea id="productDescription" name="description" rows="4" placeholder="Mô tả chi tiết về sản phẩm"></textarea>
                    </div>
                </div>
                
                <!-- Pricing and Inventory -->
                <div class="form-section">
                    <h3>Giá cả và tồn kho</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="productPrice">Giá bán *</label>
                            <input type="number" id="productPrice" name="price" required min="0" placeholder="0" />
                        </div>
                        <div class="form-group">
                            <label for="productOriginalPrice">Giá gốc</label>
                            <input type="number" id="productOriginalPrice" name="originalPrice" min="0" placeholder="0" />
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="productStock">Số lượng tồn kho *</label>
                            <input type="number" id="productStock" name="stock" required min="0" placeholder="0" />
                        </div>
                        <div class="form-group">
                            <label for="productCondition">Tình trạng</label>
                            <select id="productCondition" name="condition">
                                <option value="new">Mới</option>
                                <option value="like_new">Như mới</option>
                                <option value="good">Tốt</option>
                                <option value="fair">Khá</option>
                                <option value="poor">Cũ</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Category and Details -->
                <div class="form-section">
                    <h3>Phân loại và chi tiết</h3>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="productCategory">Danh mục *</label>
                            <select id="productCategory" name="category" required>
                                <option value="">Chọn danh mục</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="productPublishYear">Năm xuất bản</label>
                            <input type="number" id="productPublishYear" name="publishYear" min="1000" max="2025" placeholder="2024" />
                        </div>
                        <div class="form-group">
                            <label for="productPages">Số trang</label>
                            <input type="number" id="productPages" name="pages" min="1" placeholder="200" />
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="productTags">Tags (phân cách bằng dấu phẩy)</label>
                        <input type="text" id="productTags" name="tags" placeholder="sách hay, bestseller, tiểu thuyết" />
                    </div>
                </div>
                
                <!-- Images -->
                <div class="form-section">
                    <h3>Hình ảnh sản phẩm</h3>
                    <div class="form-group">
                        <label for="productImages">Tải lên hình ảnh</label>
                        <input type="file" id="productImages" name="images" multiple accept="image/*" />
                        <div class="image-preview" id="imagePreview">
                            <!-- Image previews will be shown here -->
                        </div>
                    </div>
                </div>
                
                <!-- SEO -->
                <div class="form-section">
                    <h3>SEO</h3>
                    <div class="form-group">
                        <label for="productMetaTitle">Meta Title</label>
                        <input type="text" id="productMetaTitle" name="metaTitle" placeholder="Tiêu đề SEO" />
                    </div>
                    <div class="form-group">
                        <label for="productMetaDescription">Meta Description</label>
                        <textarea id="productMetaDescription" name="metaDescription" rows="3" placeholder="Mô tả SEO"></textarea>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-outline" id="cancelProduct">Hủy</button>
            <button type="submit" form="addProductForm" class="btn btn-primary" id="saveProduct">
                <span class="btn-text">Lưu sản phẩm</span>
                <span class="btn-loading" style="display: none;">⏳</span>
            </button>
        </div>
    </div>
</div>

<!-- Product Actions Modal -->
<div id="productActionsModal" class="modal" style="display: none;">
    <div class="modal-overlay"></div>
    <div class="modal-content">
        <div class="modal-header">
            <h2>Thao tác sản phẩm</h2>
            <button class="modal-close" id="closeActionsModal">×</button>
        </div>
        <div class="modal-body">
            <div class="action-buttons">
                <button class="btn btn-outline" id="editProduct">
                    <span class="btn-icon">✏️</span>
                    <span>Chỉnh sửa</span>
                </button>
                <button class="btn btn-outline" id="toggleProduct">
                    <span class="btn-icon">🔄</span>
                    <span>Kích hoạt/Tạm dừng</span>
                </button>
                <button class="btn btn-outline" id="duplicateProduct">
                    <span class="btn-icon">📋</span>
                    <span>Sao chép</span>
                </button>
                <button class="btn btn-outline" id="viewProduct">
                    <span class="btn-icon">👁️</span>
                    <span>Xem chi tiết</span>
                </button>
                <button class="btn btn-danger" id="deleteProduct">
                    <span class="btn-icon">🗑️</span>
                    <span>Xóa sản phẩm</span>
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// Debug: Check what scripts are loaded
console.log('🔍 Checking loaded scripts...');
console.log('- api available?', typeof api);
console.log('- SellerDashboard available?', typeof SellerDashboard);
console.log('- appConfig available?', typeof appConfig);

// Simple direct event listener for debugging
document.addEventListener('DOMContentLoaded', function() {
    console.log('✅ DOM loaded');
    
    const addBtn = document.getElementById('addProductBtn');
    const modal = document.getElementById('addProductModal');
    
    console.log('- Add button found?', !!addBtn);
    console.log('- Modal found?', !!modal);
    
    if (addBtn && modal) {
        // Add direct click handler
        addBtn.addEventListener('click', function(e) {
            console.log('🖱️ Button clicked!');
            e.preventDefault();
            e.stopPropagation();
            
            // Show modal directly
            modal.style.display = 'flex';
            modal.classList.add('show');
            
            console.log('✅ Modal should be visible now');
        });
        
        // Close button
        const closeBtn = document.getElementById('closeAddProductModal');
        if (closeBtn) {
            closeBtn.addEventListener('click', function() {
                console.log('❌ Close button clicked');
                modal.style.display = 'none';
                modal.classList.remove('show');
            });
        }
        
        // Close on overlay click
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                console.log('❌ Overlay clicked');
                modal.style.display = 'none';
                modal.classList.remove('show');
            }
        });
    } else {
        console.error('❌ Button or modal not found!');
    }
    
    // Load products
    async function loadProducts() {
        const productsLoading = document.getElementById('productsLoading');
        const productsGrid = document.getElementById('productsGrid');
        const productsEmpty = document.getElementById('productsEmpty');
        
        try {
            console.log('📦 Loading products...');
            
            // Show loading
            if (productsLoading) productsLoading.style.display = 'flex';
            if (productsGrid) productsGrid.style.display = 'none';
            if (productsEmpty) productsEmpty.style.display = 'none';
            
            // Get seller's products
            const response = await api.request('/products/seller/my-products');
            console.log('✅ Products loaded:', response);
            
            // Hide loading
            if (productsLoading) productsLoading.style.display = 'none';
            
            if (response.success && response.data && response.data.products) {
                const products = response.data.products;
                
                if (products.length === 0) {
                    // Show empty state
                    if (productsEmpty) productsEmpty.style.display = 'flex';
                } else {
                    // Show products
                    if (productsGrid) {
                        productsGrid.style.display = 'grid';
                        productsGrid.innerHTML = products.map(product => `
                            <div class="product-card" data-product-id="${product._id}">
                                <div class="product-image">
                                    <img src="${product.images && product.images[0] ? product.images[0].url : 'https://via.placeholder.com/300x400?text=No+Image'}" 
                                         alt="${product.title}" />
                                    <div class="product-status status-${product.status}">
                                        ${getStatusText(product.status)}
                                    </div>
                                </div>
                                <div class="product-info">
                                    <h3 class="product-title">${product.title}</h3>
                                    <p class="product-author">Tác giả: ${product.author}</p>
                                    <div class="product-meta">
                                        <span class="product-price">${formatPrice(product.price)}</span>
                                        <span class="product-stock">Tồn: ${product.stock}</span>
                                    </div>
                                    <div class="product-stats">
                                        <span>👁️ ${product.viewCount || 0}</span>
                                        <span>⭐ ${product.averageRating || 0}</span>
                                        <span>📦 ${product.totalSold || 0}</span>
                                    </div>
                                    <div class="product-actions">
                                        <button class="btn btn-sm btn-outline" onclick="viewProduct('${product._id}')">
                                            👁️ Xem
                                        </button>
                                        <button class="btn btn-sm btn-outline" onclick="editProduct('${product._id}')">
                                            ✏️ Sửa
                                        </button>
                                        <button class="btn btn-sm btn-danger" onclick="deleteProduct('${product._id}')">
                                            🗑️ Xóa
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `).join('');
                    }
                }
            } else {
                throw new Error('Không thể tải sản phẩm');
            }
        } catch (error) {
            console.error('❌ Failed to load products:', error);
            
            // Hide loading
            if (productsLoading) productsLoading.style.display = 'none';
            
            // Show empty state with error
            if (productsEmpty) {
                productsEmpty.style.display = 'flex';
                productsEmpty.innerHTML = `
                    <div class="empty-icon">📦</div>
                    <h3>Không thể tải sản phẩm</h3>
                    <p>Có lỗi xảy ra: ${error.message}</p>
                    <button class="btn btn-primary" onclick="location.reload()">
                        🔄 Thử lại
                    </button>
                `;
            }
        }
    }
    
    // Helper functions
    function getStatusText(status) {
        const statusMap = {
            'pending': '⏳ Chờ duyệt',
            'approved': '✅ Đã duyệt',
            'rejected': '❌ Bị từ chối',
            'inactive': '⏸️ Không hoạt động'
        };
        return statusMap[status] || status;
    }
    
    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(price);
    }
    
    // Product actions (placeholder functions)
    window.viewProduct = function(productId) {
        console.log('View product:', productId);
        // TODO: Implement view product
        alert('Xem chi tiết sản phẩm: ' + productId);
    };
    
    window.editProduct = function(productId) {
        console.log('Edit product:', productId);
        // TODO: Implement edit product
        alert('Chỉnh sửa sản phẩm: ' + productId);
    };
    
    window.deleteProduct = async function(productId) {
        if (!confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')) {
            return;
        }
        
        try {
            const response = await api.deleteProduct(productId);
            if (response.success) {
                alert('✅ Đã xóa sản phẩm thành công');
                loadProducts(); // Reload list
            }
        } catch (error) {
            alert('❌ Không thể xóa sản phẩm: ' + error.message);
        }
    };
    
    // Load products on page load
    loadProducts();
    
    // Load categories for the form
    if (typeof api !== 'undefined' && api.getCategories) {
        api.getCategories().then(response => {
            console.log('📂 Categories loaded:', response);
            if (response.success && response.data) {
                // Backend returns data.categories (nested structure)
                const categories = response.data.categories || response.data;
                const categorySelect = document.getElementById('productCategory');
                const categoryFilter = document.getElementById('categoryFilter');
                
                if (categorySelect && Array.isArray(categories)) {
                    categorySelect.innerHTML = '<option value="">Chọn danh mục</option>';
                    categories.forEach(cat => {
                        const option = document.createElement('option');
                        option.value = cat._id;
                        option.textContent = cat.name;
                        categorySelect.appendChild(option);
                    });
                    console.log(`✅ Loaded ${categories.length} categories into select`);
                }
                
                // Also populate filter dropdown
                if (categoryFilter && Array.isArray(categories)) {
                    categoryFilter.innerHTML = '<option value="">Tất cả danh mục</option>';
                    categories.forEach(cat => {
                        const option = document.createElement('option');
                        option.value = cat._id;
                        option.textContent = cat.name;
                        categoryFilter.appendChild(option);
                    });
                }
            }
        }).catch(err => {
            console.error('❌ Failed to load categories:', err);
            // Show error in console for debugging
            console.error('Error details:', err);
            
            // Add fallback placeholder option
            const categorySelect = document.getElementById('productCategory');
            if (categorySelect) {
                categorySelect.innerHTML = '<option value="">Không thể tải danh mục - Vui lòng refresh trang</option>';
            }
        });
    } else {
        console.error('❌ api.getCategories not available');
        console.log('Available api methods:', Object.keys(api || {}));
    }
    
    // Handle form submission
    const form = document.getElementById('addProductForm');
    const saveBtn = document.getElementById('saveProduct');
    
    if (form && saveBtn) {
        form.addEventListener('submit', async function(e) {
            e.preventDefault();
            console.log('📝 Form submitted');
            
            // Show loading state
            const btnText = saveBtn.querySelector('.btn-text');
            const btnLoading = saveBtn.querySelector('.btn-loading');
            btnText.style.display = 'none';
            btnLoading.style.display = 'inline';
            saveBtn.disabled = true;
            
            try {
                const formData = new FormData(form);
                
                // Build product data object
                const productData = {
                    title: formData.get('title'),
                    author: formData.get('author'),
                    description: formData.get('description') || 'Chưa có mô tả chi tiết.',
                    price: parseFloat(formData.get('price')),
                    stock: parseInt(formData.get('stock')),
                    category: formData.get('category'),
                    condition: formData.get('condition') || 'new'
                };
                
                // Add optional fields if they have values
                const optionalFields = {
                    publisher: formData.get('publisher'),
                    isbn: formData.get('isbn'),
                    metaTitle: formData.get('metaTitle'),
                    metaDescription: formData.get('metaDescription')
                };
                
                Object.keys(optionalFields).forEach(key => {
                    if (optionalFields[key]) {
                        productData[key] = optionalFields[key];
                    }
                });
                
                // Note: Language field removed from form to avoid MongoDB text index issues
                
                // Add numeric fields if they have values
                const originalPrice = formData.get('originalPrice');
                if (originalPrice && parseFloat(originalPrice) > 0) {
                    productData.originalPrice = parseFloat(originalPrice);
                }
                
                const publishYear = formData.get('publishYear');
                if (publishYear && parseInt(publishYear) > 0) {
                    productData.publishYear = parseInt(publishYear);
                }
                
                const pages = formData.get('pages');
                if (pages && parseInt(pages) > 0) {
                    productData.pages = parseInt(pages);
                }
                
                // Process tags
                const tagsInput = formData.get('tags');
                if (tagsInput) {
                    productData.tags = tagsInput.split(',').map(tag => tag.trim()).filter(tag => tag.length > 0);
                }
                
                // Process images (for now, add placeholder image)
                productData.images = [{
                    url: 'https://via.placeholder.com/300x400?text=Book+Cover',
                    alt: productData.title,
                    isPrimary: true
                }];
                
                console.log('📦 Product data:', productData);
                
                // Validate required fields
                if (!productData.title || !productData.author || !productData.category) {
                    throw new Error('Vui lòng điền đầy đủ thông tin bắt buộc (Tên sản phẩm, Tác giả, Danh mục)');
                }
                
                if (productData.price <= 0) {
                    throw new Error('Giá bán phải lớn hơn 0');
                }
                
                if (productData.stock < 0) {
                    throw new Error('Số lượng tồn kho không thể âm');
                }
                
                // Call API
                if (typeof api !== 'undefined' && api.createProduct) {
                    const response = await api.createProduct(productData);
                    console.log('✅ Product created:', response);
                    
                    if (response.success) {
                        // Show success message
                        const successEl = document.getElementById('productSuccess');
                        if (successEl) {
                            successEl.textContent = '✅ Sản phẩm đã được thêm thành công! Đang chờ admin phê duyệt.';
                            successEl.style.display = 'block';
                        }
                        
                        // Close modal after 2 seconds
                        setTimeout(() => {
                            modal.style.display = 'none';
                            modal.classList.remove('show');
                            form.reset();
                            if (successEl) successEl.style.display = 'none';
                            
                            // Reload page to show new product
                            location.reload();
                        }, 2000);
                    } else {
                        throw new Error(response.message || 'Không thể thêm sản phẩm');
                    }
                } else {
                    throw new Error('API không khả dụng. Vui lòng refresh trang và thử lại.');
                }
            } catch (error) {
                console.error('❌ Error:', error);
                console.error('❌ Error data:', error.data);
                
                // Show detailed error message
                const errorEl = document.getElementById('productError');
                if (errorEl) {
                    let errorMessage = '❌ ' + error.message;
                    
                    // If error has data with validation errors (from APIError)
                    if (error.data && error.data.errors && Array.isArray(error.data.errors)) {
                        errorMessage += '\n\nChi tiết lỗi:';
                        error.data.errors.forEach(err => {
                            errorMessage += `\n• ${err.field}: ${err.message}`;
                        });
                    }
                    
                    errorEl.textContent = errorMessage;
                    errorEl.style.display = 'block';
                    errorEl.style.whiteSpace = 'pre-line'; // Allow line breaks
                }
                
                // Hide error after 15 seconds
                setTimeout(() => {
                    if (errorEl) errorEl.style.display = 'none';
                }, 15000);
            } finally {
                // Reset button state
                btnText.style.display = 'inline';
                btnLoading.style.display = 'none';
                saveBtn.disabled = false;
            }
        });
    }
    
    // Load user info
    if (typeof window.loadUserInfo === 'function') {
        window.loadUserInfo();
    }
});
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>