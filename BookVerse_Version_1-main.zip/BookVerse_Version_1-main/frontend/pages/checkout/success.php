<?php 
$pageTitle='Đặt hàng thành công'; 
$extraCss=['../../assets/css/main.css', '../../assets/css/checkout.css']; 
$extraJs=['../../assets/js/main.js', '../../assets/js/api.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<main class="checkout-success-page">
    <div class="container">
        <div class="success-content">
            <div class="success-icon">
                <div class="icon-circle">
                    <span class="check-icon">✓</span>
                </div>
            </div>
            
            <h1>Đặt hàng thành công!</h1>
            <p class="success-message">
                Cảm ơn bạn đã đặt hàng. Chúng tôi sẽ xử lý đơn hàng của bạn trong thời gian sớm nhất.
            </p>
            
            <div class="order-info">
                <div class="info-card">
                    <h3>Thông tin đơn hàng</h3>
                    <div class="info-details">
                        <div class="detail-row">
                            <span class="label">Mã đơn hàng:</span>
                            <span class="value" id="orderId">#<?php echo $_GET['orderId'] ?? 'N/A'; ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Ngày đặt:</span>
                            <span class="value" id="orderDate"><?php echo date('d/m/Y H:i'); ?></span>
                        </div>
                        <div class="detail-row">
                            <span class="label">Trạng thái:</span>
                            <span class="value status-pending">Đang xử lý</span>
                        </div>
                    </div>
                </div>
                
                <div class="info-card">
                    <h3>Thông tin giao hàng</h3>
                    <div class="info-details" id="shippingInfo">
                        <!-- Shipping info will be populated here -->
                    </div>
                </div>
                
                <div class="info-card">
                    <h3>Phương thức thanh toán</h3>
                    <div class="info-details" id="paymentInfo">
                        <!-- Payment info will be populated here -->
                    </div>
                </div>
            </div>
            
            <div class="next-steps">
                <h3>Bước tiếp theo</h3>
                <div class="steps-list">
                    <div class="step-item">
                        <div class="step-icon">📧</div>
                        <div class="step-content">
                            <h4>Xác nhận email</h4>
                            <p>Chúng tôi đã gửi email xác nhận đơn hàng đến hộp thư của bạn</p>
                        </div>
                    </div>
                    <div class="step-item">
                        <div class="step-icon">📦</div>
                        <div class="step-content">
                            <h4>Chuẩn bị hàng</h4>
                            <p>Đơn hàng của bạn đang được chuẩn bị và đóng gói</p>
                        </div>
                    </div>
                    <div class="step-item">
                        <div class="step-icon">🚚</div>
                        <div class="step-content">
                            <h4>Giao hàng</h4>
                            <p>Đơn hàng sẽ được giao trong 1-2 ngày làm việc</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="action-buttons">
                <a href="../products/list.php" class="btn btn-primary btn-large">
                    <span class="btn-icon">🛍️</span>
                    <span>Tiếp tục mua sắm</span>
                </a>
                <a href="../account/orders.php" class="btn btn-outline btn-large">
                    <span class="btn-icon">📋</span>
                    <span>Xem đơn hàng</span>
                </a>
                <button class="btn btn-secondary btn-large" id="printOrderBtn">
                    <span class="btn-icon">🖨️</span>
                    <span>In hóa đơn</span>
                </button>
            </div>
            
            <div class="support-info">
                <h3>Cần hỗ trợ?</h3>
                <p>Nếu bạn có bất kỳ câu hỏi nào về đơn hàng, vui lòng liên hệ với chúng tôi:</p>
                <div class="support-contacts">
                    <div class="contact-item">
                        <span class="contact-icon">📞</span>
                        <span>Hotline: <a href="tel:19001234">1900 1234</a></span>
                    </div>
                    <div class="contact-item">
                        <span class="contact-icon">📧</span>
                        <span>Email: <a href="mailto:support@bookverse.vn">support@bookverse.vn</a></span>
                    </div>
                    <div class="contact-item">
                        <span class="contact-icon">💬</span>
                        <span>Chat: <a href="#" onclick="openChat()">Mở chat</a></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<style>
/* Success Page Styles */
.checkout-success-page {
    padding: 3rem 0;
    background: var(--bg-secondary);
    min-height: 100vh;
}

.success-content {
    max-width: 800px;
    margin: 0 auto;
    text-align: center;
    background: var(--bg-primary);
    border-radius: var(--radius-xl);
    box-shadow: var(--shadow-lg);
    padding: 3rem;
}

.success-icon {
    margin-bottom: 2rem;
}

.icon-circle {
    width: 100px;
    height: 100px;
    border-radius: var(--radius-full);
    background: linear-gradient(135deg, var(--success-color), #059669);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto;
    animation: successPulse 2s ease-in-out infinite;
}

.check-icon {
    font-size: 3rem;
    color: white;
    font-weight: bold;
}

@keyframes successPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.05); }
}

.success-content h1 {
    font-size: var(--font-size-4xl);
    font-weight: 800;
    color: var(--text-primary);
    margin-bottom: 1rem;
}

.success-message {
    font-size: var(--font-size-lg);
    color: var(--text-secondary);
    margin-bottom: 3rem;
    line-height: 1.6;
}

.order-info {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 3rem;
    text-align: left;
}

.info-card {
    background: var(--bg-tertiary);
    border-radius: var(--radius-lg);
    padding: 1.5rem;
}

.info-card h3 {
    margin-bottom: 1rem;
    color: var(--text-primary);
    font-size: var(--font-size-lg);
    font-weight: 600;
}

.info-details {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.detail-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid var(--border-color);
}

.detail-row:last-child {
    border-bottom: none;
}

.detail-row .label {
    color: var(--text-secondary);
    font-weight: 500;
}

.detail-row .value {
    color: var(--text-primary);
    font-weight: 600;
}

.status-pending {
    color: var(--warning-color);
    background: rgba(245, 158, 11, 0.1);
    padding: 0.25rem 0.75rem;
    border-radius: var(--radius-full);
    font-size: var(--font-size-sm);
}

.next-steps {
    margin-bottom: 3rem;
    text-align: left;
}

.next-steps h3 {
    text-align: center;
    margin-bottom: 2rem;
    color: var(--text-primary);
    font-size: var(--font-size-xl);
}

.steps-list {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.step-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    background: var(--bg-tertiary);
    border-radius: var(--radius-lg);
}

.step-icon {
    font-size: 2rem;
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--bg-primary);
    border-radius: var(--radius-full);
    flex-shrink: 0;
}

.step-content h4 {
    margin-bottom: 0.5rem;
    color: var(--text-primary);
    font-size: var(--font-size-base);
    font-weight: 600;
}

.step-content p {
    margin: 0;
    color: var(--text-secondary);
    font-size: var(--font-size-sm);
    line-height: 1.5;
}

.action-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
    margin-bottom: 3rem;
    flex-wrap: wrap;
}

.btn-large {
    padding: 1rem 2rem;
    font-size: var(--font-size-base);
    font-weight: 600;
    min-height: 56px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.support-info {
    text-align: left;
    background: var(--bg-tertiary);
    border-radius: var(--radius-lg);
    padding: 2rem;
}

.support-info h3 {
    margin-bottom: 1rem;
    color: var(--text-primary);
    font-size: var(--font-size-lg);
}

.support-info p {
    margin-bottom: 1.5rem;
    color: var(--text-secondary);
    line-height: 1.6;
}

.support-contacts {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
}

.contact-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    color: var(--text-secondary);
}

.contact-icon {
    font-size: 1.2rem;
    width: 24px;
    text-align: center;
}

.contact-item a {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: 500;
}

.contact-item a:hover {
    text-decoration: underline;
}

/* Responsive Design */
@media (max-width: 768px) {
    .success-content {
        padding: 2rem;
    }
    
    .success-content h1 {
        font-size: var(--font-size-3xl);
    }
    
    .order-info {
        grid-template-columns: 1fr;
    }
    
    .action-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .btn-large {
        width: 100%;
        max-width: 300px;
    }
    
    .steps-list {
        gap: 1rem;
    }
    
    .step-item {
        flex-direction: column;
        text-align: center;
    }
    
    .step-icon {
        width: 50px;
        height: 50px;
        font-size: 1.5rem;
    }
}

@media (max-width: 480px) {
    .success-content {
        padding: 1.5rem;
    }
    
    .icon-circle {
        width: 80px;
        height: 80px;
    }
    
    .check-icon {
        font-size: 2.5rem;
    }
    
    .support-contacts {
        gap: 0.5rem;
    }
}
</style>

<script>
// Success page functionality
document.addEventListener('DOMContentLoaded', function() {
    // Print order functionality
    document.getElementById('printOrderBtn')?.addEventListener('click', function() {
        window.print();
    });
    
    // Load order details if orderId is available
    const urlParams = new URLSearchParams(window.location.search);
    const orderId = urlParams.get('orderId');
    
    if (orderId) {
        loadOrderDetails(orderId);
    }
});

function loadOrderDetails(orderId) {
    // This would typically fetch order details from the API
    // For now, we'll just show the order ID
    console.log('Loading order details for:', orderId);
}

function openChat() {
    // Open chat widget or redirect to chat page
    alert('Chat widget sẽ được mở ở đây');
}
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>
