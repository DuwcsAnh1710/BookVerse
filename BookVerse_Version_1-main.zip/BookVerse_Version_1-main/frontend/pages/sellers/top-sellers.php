<?php 
$pageTitle='Người bán hàng đầu'; 
$extraCss=['../../assets/css/main.css', '../../assets/css/responsive.css']; 
$extraJs=['../../assets/js/config.js', '../../assets/js/api.js', '../../assets/js/main.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<!-- Top Sellers Page -->
<main class="main" role="main">
    <!-- Page Header -->
    <section class="page-header">
        <div class="container">
            <div class="header-content">
                <h1 class="page-title">Người bán hàng đầu</h1>
                <p class="page-subtitle">Khám phá những người bán sách uy tín và có doanh thu cao nhất</p>
            </div>
        </div>
    </section>

    <!-- Filters Section -->
    <section class="filters-section">
        <div class="container">
            <div class="filters-container">
                <div class="filters-grid">
                    <div class="filter-group">
                        <label class="filter-label">Tìm kiếm</label>
                        <input type="text" id="searchInput" class="form-input" placeholder="Tìm theo tên, email, tên cửa hàng...">
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Sắp xếp theo</label>
                        <select id="sortBy" class="form-select">
                            <option value="revenue">Doanh thu cao nhất</option>
                            <option value="orders">Số đơn hàng</option>
                            <option value="rating">Đánh giá cao nhất</option>
                            <option value="products">Số sản phẩm</option>
                            <option value="newest">Mới nhất</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Khu vực</label>
                        <select id="locationFilter" class="form-select">
                            <option value="">Tất cả khu vực</option>
                            <option value="hanoi">Hà Nội</option>
                            <option value="hcm">TP. Hồ Chí Minh</option>
                            <option value="danang">Đà Nẵng</option>
                            <option value="cantho">Cần Thơ</option>
                            <option value="other">Khác</option>
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">Danh mục</label>
                        <select id="categoryFilter" class="form-select">
                            <option value="">Tất cả danh mục</option>
                            <option value="fiction">Tiểu thuyết</option>
                            <option value="non-fiction">Phi hư cấu</option>
                            <option value="academic">Học thuật</option>
                            <option value="children">Thiếu nhi</option>
                            <option value="business">Kinh doanh</option>
                        </select>
                    </div>
                </div>
                <div class="filters-actions">
                    <button class="btn btn-outline" onclick="clearFilters()">
                        <span class="btn-icon">🔄</span>
                        Xóa bộ lọc
                    </button>
                    <button class="btn btn-primary" onclick="applyFilters()">
                        <span class="btn-icon">🔍</span>
                        Áp dụng
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Sellers Grid -->
    <section class="sellers-section">
        <div class="container">
            <div class="sellers-header">
                <div class="sellers-info">
                    <h2 class="sellers-title">Danh sách người bán</h2>
                    <p class="sellers-subtitle" id="sellersCount">Đang tải...</p>
                </div>
                <div class="view-toggle">
                    <button class="view-btn active" data-view="grid" onclick="switchView('grid')">
                        <span class="btn-icon">⊞</span>
                        Lưới
                    </button>
                    <button class="view-btn" data-view="list" onclick="switchView('list')">
                        <span class="btn-icon">☰</span>
                        Danh sách
                    </button>
                </div>
            </div>

            <div class="sellers-grid" id="sellersGrid">
                <!-- Sellers will be loaded here -->
            </div>

            <!-- Loading State -->
            <div class="loading-state" id="loadingState">
                <div class="spinner"></div>
                <p class="loading-text">Đang tải danh sách người bán...</p>
            </div>

            <!-- Empty State -->
            <div class="empty-state" id="emptyState" style="display: none;">
                <div class="empty-icon">📚</div>
                <h3 class="empty-title">Không tìm thấy người bán nào</h3>
                <p class="empty-text">Hãy thử thay đổi bộ lọc hoặc từ khóa tìm kiếm</p>
                <button class="btn btn-primary" onclick="clearFilters()">
                    <span class="btn-icon">🔄</span>
                    Xóa bộ lọc
                </button>
            </div>

            <!-- Pagination -->
            <div class="pagination-section" id="paginationSection" style="display: none;">
                <div class="pagination-info">
                    <span id="paginationInfo">Hiển thị 1-10 của 0 người bán</span>
                </div>
                <div class="pagination-controls" id="paginationControls">
                    <!-- Pagination will be loaded here -->
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Seller Detail Modal -->
<div id="sellerDetailModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Thông tin người bán</h3>
            <button class="modal-close" onclick="closeSellerDetail()">&times;</button>
        </div>
        <div class="modal-body" id="sellerDetailContent">
            <!-- Seller details will be loaded here -->
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="closeSellerDetail()">Đóng</button>
            <button class="btn btn-primary" onclick="viewSellerProducts()">Xem sản phẩm</button>
        </div>
    </div>
</div>

<style>
/* Top Sellers Specific Styles */
.page-header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
    padding: 4rem 0 2rem;
    color: white;
    text-align: center;
    position: relative;
    overflow: hidden;
}

.page-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%);
    pointer-events: none;
}

.header-content {
    position: relative;
    z-index: 1;
}

.page-title {
    font-size: 3rem;
    font-weight: 800;
    margin-bottom: 1rem;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.page-subtitle {
    font-size: 1.25rem;
    opacity: 0.9;
    max-width: 600px;
    margin: 0 auto;
}

.filters-section {
    background: #f8fafc;
    padding: 2rem 0;
    border-bottom: 1px solid #e5e7eb;
}

.filters-container {
    background: white;
    border-radius: 12px;
    padding: 2rem;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
}

.filters-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

.filter-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.filter-label {
    font-weight: 600;
    color: #374151;
    font-size: 0.875rem;
}

.form-input,
.form-select {
    padding: 0.75rem;
    border: 1px solid #d1d5db;
    border-radius: 8px;
    font-size: 0.875rem;
    transition: border-color 0.2s ease;
}

.form-input:focus,
.form-select:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.filters-actions {
    display: flex;
    gap: 1rem;
    justify-content: flex-end;
}

.sellers-section {
    padding: 3rem 0;
}

.sellers-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    flex-wrap: wrap;
    gap: 1rem;
}

.sellers-title {
    font-size: 2rem;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 0.5rem;
}

.sellers-subtitle {
    color: #6b7280;
    font-size: 0.875rem;
}

.view-toggle {
    display: flex;
    gap: 0.5rem;
    background: #f3f4f6;
    padding: 0.25rem;
    border-radius: 8px;
}

.view-btn {
    padding: 0.5rem 1rem;
    border: none;
    background: transparent;
    color: #6b7280;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.875rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.view-btn.active {
    background: white;
    color: #3b82f6;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.sellers-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 2rem;
    margin-bottom: 3rem;
}

.sellers-grid.list-view {
    grid-template-columns: 1fr;
    gap: 1rem;
}

.seller-card {
    background: white;
    border-radius: 16px;
    padding: 2rem;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    border: 1px solid #f3f4f6;
    position: relative;
    overflow: hidden;
}

.seller-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #3b82f6, #8b5cf6, #ec4899);
}

.seller-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
}

.seller-card.list-view {
    display: flex;
    align-items: center;
    padding: 1.5rem;
}

.seller-header {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.seller-card.list-view .seller-header {
    margin-bottom: 0;
    flex: 1;
}

.seller-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, #3b82f6, #8b5cf6);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.5rem;
    font-weight: 700;
    flex-shrink: 0;
}

.seller-info {
    flex: 1;
    min-width: 0;
}

.seller-name {
    font-size: 1.25rem;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 0.25rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.seller-business {
    color: #6b7280;
    font-size: 0.875rem;
    margin-bottom: 0.5rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.seller-rating {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.875rem;
    color: #f59e0b;
}

.seller-stats {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.seller-card.list-view .seller-stats {
    display: flex;
    gap: 2rem;
    margin-bottom: 0;
}

.stat-item {
    text-align: center;
    padding: 0.75rem;
    background: #f8fafc;
    border-radius: 8px;
}

.seller-card.list-view .stat-item {
    background: transparent;
    padding: 0;
    text-align: left;
}

.stat-value {
    font-size: 1.25rem;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 0.25rem;
}

.stat-label {
    font-size: 0.75rem;
    color: #6b7280;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.seller-actions {
    display: flex;
    gap: 0.75rem;
}

.action-btn {
    flex: 1;
    padding: 0.75rem;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.875rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
}

.action-btn.primary {
    background: #3b82f6;
    color: white;
}

.action-btn.primary:hover {
    background: #2563eb;
}

.action-btn.secondary {
    background: #f3f4f6;
    color: #374151;
}

.action-btn.secondary:hover {
    background: #e5e7eb;
}

.seller-card.list-view .seller-actions {
    flex-direction: column;
    gap: 0.5rem;
    min-width: 120px;
}

.seller-card.list-view .action-btn {
    padding: 0.5rem 1rem;
}

/* Loading State */
.loading-state {
    text-align: center;
    padding: 4rem 0;
}

.spinner {
    width: 40px;
    height: 40px;
    border: 4px solid #f3f4f6;
    border-top: 4px solid #3b82f6;
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin: 0 auto 1rem;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.loading-text {
    color: #6b7280;
    font-weight: 500;
}

/* Empty State */
.empty-state {
    text-align: center;
    padding: 4rem 0;
}

.empty-icon {
    font-size: 4rem;
    margin-bottom: 1rem;
}

.empty-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 0.5rem;
}

.empty-text {
    color: #6b7280;
    margin-bottom: 2rem;
}

/* Pagination */
.pagination-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 3rem;
    padding-top: 2rem;
    border-top: 1px solid #e5e7eb;
}

.pagination-info {
    color: #6b7280;
    font-size: 0.875rem;
}

.pagination-controls {
    display: flex;
    gap: 0.5rem;
}

.pagination-btn {
    padding: 0.5rem 0.75rem;
    border: 1px solid #d1d5db;
    background: white;
    color: #374151;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.875rem;
}

.pagination-btn:hover:not(:disabled) {
    background: #f3f4f6;
    border-color: #9ca3af;
}

.pagination-btn.active {
    background: #3b82f6;
    color: white;
    border-color: #3b82f6;
}

.pagination-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

/* Responsive Design */
@media (max-width: 768px) {
    .page-title {
        font-size: 2rem;
    }
    
    .filters-grid {
        grid-template-columns: 1fr;
    }
    
    .filters-actions {
        justify-content: center;
    }
    
    .sellers-header {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .sellers-grid {
        grid-template-columns: 1fr;
    }
    
    .seller-card.list-view {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .seller-card.list-view .seller-stats {
        flex-direction: column;
        gap: 1rem;
    }
    
    .seller-card.list-view .seller-actions {
        flex-direction: row;
        width: 100%;
    }
    
    .pagination-section {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
}

@media (max-width: 480px) {
    .page-header {
        padding: 2rem 0 1rem;
    }
    
    .page-title {
        font-size: 1.75rem;
    }
    
    .filters-container {
        padding: 1rem;
    }
    
    .seller-card {
        padding: 1.5rem;
    }
    
    .seller-stats {
        grid-template-columns: 1fr;
        gap: 0.75rem;
    }
}
</style>

<script>
// Top Sellers Management
class TopSellersManager {
    constructor() {
        this.sellers = [];
        this.currentPage = 1;
        this.itemsPerPage = 12;
        this.filters = {};
        this.currentView = 'grid';
        this.initializeEventListeners();
        this.loadSellers();
    }

    initializeEventListeners() {
        // Search and filters
        document.getElementById('searchInput')?.addEventListener('input', (e) => {
            this.filters.search = e.target.value;
            this.debounceSearch();
        });

        document.getElementById('sortBy')?.addEventListener('change', (e) => {
            this.filters.sortBy = e.target.value;
            this.loadSellers();
        });

        document.getElementById('locationFilter')?.addEventListener('change', (e) => {
            this.filters.location = e.target.value;
            this.loadSellers();
        });

        document.getElementById('categoryFilter')?.addEventListener('change', (e) => {
            this.filters.category = e.target.value;
            this.loadSellers();
        });

        // Global functions
        window.clearFilters = () => this.clearFilters();
        window.applyFilters = () => this.applyFilters();
        window.switchView = (view) => this.switchView(view);
        window.viewSellerDetail = (sellerId) => this.viewSellerDetail(sellerId);
        window.closeSellerDetail = () => this.closeSellerDetail();
        window.viewSellerProducts = () => this.viewSellerProducts();
    }

    debounceSearch() {
        clearTimeout(this.searchTimeout);
        this.searchTimeout = setTimeout(() => {
            this.loadSellers();
        }, 500);
    }

    async loadSellers() {
        try {
            this.showLoading();
            
            const params = {
                page: this.currentPage,
                limit: this.itemsPerPage,
                ...this.filters
            };

            // For now, use mock data
            const response = await this.getMockSellers(params);
            this.sellers = response.sellers;
            
            this.displaySellers();
            this.updatePagination(response.pagination);
            this.updateSellersCount(response.pagination);
            
        } catch (error) {
            console.error('Error loading sellers:', error);
            this.showError('Không thể tải danh sách người bán');
        } finally {
            this.hideLoading();
        }
    }

    async getMockSellers(params) {
        // Mock data for development
        const mockSellers = [
            {
                id: 1,
                name: 'Nguyễn Văn A',
                businessName: 'Nhà sách ABC',
                email: 'seller1@example.com',
                avatar: 'NA',
                rating: 4.8,
                totalOrders: 1250,
                totalRevenue: 25000000,
                totalProducts: 150,
                location: 'Hà Nội',
                category: 'fiction',
                joinDate: '2023-01-15',
                description: 'Chuyên bán sách tiểu thuyết và văn học'
            },
            {
                id: 2,
                name: 'Trần Thị B',
                businessName: 'Cửa hàng sách XYZ',
                email: 'seller2@example.com',
                avatar: 'TB',
                rating: 4.9,
                totalOrders: 980,
                totalRevenue: 18000000,
                totalProducts: 120,
                location: 'TP.HCM',
                category: 'non-fiction',
                joinDate: '2023-03-20',
                description: 'Sách kinh tế và phát triển bản thân'
            },
            {
                id: 3,
                name: 'Lê Văn C',
                businessName: 'Bookstore 123',
                email: 'seller3@example.com',
                avatar: 'LC',
                rating: 4.7,
                totalOrders: 750,
                totalRevenue: 15000000,
                totalProducts: 95,
                location: 'Đà Nẵng',
                category: 'academic',
                joinDate: '2023-05-10',
                description: 'Sách học thuật và nghiên cứu'
            },
            {
                id: 4,
                name: 'Phạm Thị D',
                businessName: 'Sách online',
                email: 'seller4@example.com',
                avatar: 'PD',
                rating: 4.6,
                totalOrders: 650,
                totalRevenue: 12000000,
                totalProducts: 80,
                location: 'Cần Thơ',
                category: 'children',
                joinDate: '2023-07-05',
                description: 'Sách thiếu nhi và giáo dục'
            },
            {
                id: 5,
                name: 'Hoàng Văn E',
                businessName: 'Thư viện sách',
                email: 'seller5@example.com',
                avatar: 'HE',
                rating: 4.5,
                totalOrders: 580,
                totalRevenue: 10000000,
                totalProducts: 70,
                location: 'Hà Nội',
                category: 'business',
                joinDate: '2023-09-12',
                description: 'Sách kinh doanh và đầu tư'
            }
        ];

        // Apply filters
        let filteredSellers = mockSellers;
        
        if (params.search) {
            const search = params.search.toLowerCase();
            filteredSellers = filteredSellers.filter(seller => 
                seller.name.toLowerCase().includes(search) ||
                seller.businessName.toLowerCase().includes(search) ||
                seller.email.toLowerCase().includes(search)
            );
        }

        if (params.location) {
            filteredSellers = filteredSellers.filter(seller => 
                seller.location.toLowerCase().includes(params.location.toLowerCase())
            );
        }

        if (params.category) {
            filteredSellers = filteredSellers.filter(seller => 
                seller.category === params.category
            );
        }

        // Apply sorting
        if (params.sortBy) {
            switch (params.sortBy) {
                case 'revenue':
                    filteredSellers.sort((a, b) => b.totalRevenue - a.totalRevenue);
                    break;
                case 'orders':
                    filteredSellers.sort((a, b) => b.totalOrders - a.totalOrders);
                    break;
                case 'rating':
                    filteredSellers.sort((a, b) => b.rating - a.rating);
                    break;
                case 'products':
                    filteredSellers.sort((a, b) => b.totalProducts - a.totalProducts);
                    break;
                case 'newest':
                    filteredSellers.sort((a, b) => new Date(b.joinDate) - new Date(a.joinDate));
                    break;
            }
        }

        // Pagination
        const start = (params.page - 1) * params.limit;
        const end = start + params.limit;
        const paginatedSellers = filteredSellers.slice(start, end);

        return {
            sellers: paginatedSellers,
            pagination: {
                currentPage: params.page,
                totalPages: Math.ceil(filteredSellers.length / params.limit),
                total: filteredSellers.length,
                start: start + 1,
                end: Math.min(end, filteredSellers.length)
            }
        };
    }

    displaySellers() {
        const grid = document.getElementById('sellersGrid');
        if (!grid) return;

        if (this.sellers.length === 0) {
            this.showEmptyState();
            return;
        }

        this.hideEmptyState();
        
        grid.className = `sellers-grid ${this.currentView === 'list' ? 'list-view' : ''}`;
        
        grid.innerHTML = this.sellers.map(seller => `
            <div class="seller-card ${this.currentView === 'list' ? 'list-view' : ''}">
                <div class="seller-header">
                    <div class="seller-avatar">${seller.avatar}</div>
                    <div class="seller-info">
                        <h3 class="seller-name">${this.escapeHtml(seller.name)}</h3>
                        <p class="seller-business">${this.escapeHtml(seller.businessName)}</p>
                        <div class="seller-rating">
                            <span>⭐</span>
                            <span>${seller.rating}</span>
                        </div>
                    </div>
                </div>
                
                <div class="seller-stats">
                    <div class="stat-item">
                        <div class="stat-value">${this.formatNumber(seller.totalOrders)}</div>
                        <div class="stat-label">Đơn hàng</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${this.formatCurrency(seller.totalRevenue)}</div>
                        <div class="stat-label">Doanh thu</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value">${this.formatNumber(seller.totalProducts)}</div>
                        <div class="stat-label">Sản phẩm</div>
                    </div>
                </div>
                
                <div class="seller-actions">
                    <button class="action-btn primary" onclick="viewSellerDetail(${seller.id})">
                        <span class="btn-icon">👁️</span>
                        Xem chi tiết
                    </button>
                    <button class="action-btn secondary" onclick="viewSellerProducts(${seller.id})">
                        <span class="btn-icon">📚</span>
                        Sản phẩm
                    </button>
                </div>
            </div>
        `).join('');
    }

    updatePagination(pagination) {
        const section = document.getElementById('paginationSection');
        const info = document.getElementById('paginationInfo');
        const controls = document.getElementById('paginationControls');
        
        if (pagination.totalPages <= 1) {
            section.style.display = 'none';
            return;
        }
        
        section.style.display = 'flex';
        
        if (info) {
            info.textContent = `Hiển thị ${pagination.start}-${pagination.end} của ${pagination.total} người bán`;
        }

        if (controls) {
            controls.innerHTML = this.generatePaginationHTML(pagination);
        }
    }

    updateSellersCount(pagination) {
        const countEl = document.getElementById('sellersCount');
        if (countEl) {
            countEl.textContent = `Tìm thấy ${pagination.total} người bán`;
        }
    }

    generatePaginationHTML(pagination) {
        let html = '';
        
        // Previous button
        html += `<button class="pagination-btn" ${pagination.currentPage === 1 ? 'disabled' : ''} 
                 onclick="sellersManager.goToPage(${pagination.currentPage - 1})">‹</button>`;
        
        // Page numbers
        for (let i = Math.max(1, pagination.currentPage - 2); i <= Math.min(pagination.totalPages, pagination.currentPage + 2); i++) {
            html += `<button class="pagination-btn ${i === pagination.currentPage ? 'active' : ''}" 
                     onclick="sellersManager.goToPage(${i})">${i}</button>`;
        }
        
        // Next button
        html += `<button class="pagination-btn" ${pagination.currentPage === pagination.totalPages ? 'disabled' : ''} 
                 onclick="sellersManager.goToPage(${pagination.currentPage + 1})">›</button>`;
        
        return html;
    }

    goToPage(page) {
        this.currentPage = page;
        this.loadSellers();
    }

    switchView(view) {
        this.currentView = view;
        
        // Update active button
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-view="${view}"]`).classList.add('active');
        
        this.displaySellers();
    }

    clearFilters() {
        document.getElementById('searchInput').value = '';
        document.getElementById('sortBy').value = 'revenue';
        document.getElementById('locationFilter').value = '';
        document.getElementById('categoryFilter').value = '';
        
        this.filters = {};
        this.currentPage = 1;
        this.loadSellers();
    }

    applyFilters() {
        this.currentPage = 1;
        this.loadSellers();
    }

    async viewSellerDetail(sellerId) {
        try {
            const seller = this.sellers.find(s => s.id === sellerId);
            if (!seller) return;

            this.displaySellerDetail(seller);
            document.getElementById('sellerDetailModal').style.display = 'flex';
        } catch (error) {
            console.error('Error loading seller detail:', error);
            this.showError('Không thể tải thông tin người bán');
        }
    }

    displaySellerDetail(seller) {
        const content = document.getElementById('sellerDetailContent');
        if (!content) return;

        content.innerHTML = `
            <div class="seller-detail">
                <div class="detail-section">
                    <h4>Thông tin cơ bản</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label>Tên:</label>
                            <span>${this.escapeHtml(seller.name)}</span>
                        </div>
                        <div class="detail-item">
                            <label>Cửa hàng:</label>
                            <span>${this.escapeHtml(seller.businessName)}</span>
                        </div>
                        <div class="detail-item">
                            <label>Email:</label>
                            <span>${this.escapeHtml(seller.email)}</span>
                        </div>
                        <div class="detail-item">
                            <label>Khu vực:</label>
                            <span>${this.escapeHtml(seller.location)}</span>
                        </div>
                        <div class="detail-item">
                            <label>Đánh giá:</label>
                            <span>⭐ ${seller.rating}/5</span>
                        </div>
                        <div class="detail-item">
                            <label>Tham gia:</label>
                            <span>${this.formatDate(seller.joinDate)}</span>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h4>Thống kê bán hàng</h4>
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="stat-value">${this.formatNumber(seller.totalOrders)}</div>
                            <div class="stat-label">Tổng đơn hàng</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${this.formatCurrency(seller.totalRevenue)}</div>
                            <div class="stat-label">Tổng doanh thu</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-value">${this.formatNumber(seller.totalProducts)}</div>
                            <div class="stat-label">Sản phẩm</div>
                        </div>
                    </div>
                </div>

                <div class="detail-section">
                    <h4>Mô tả</h4>
                    <p>${this.escapeHtml(seller.description)}</p>
                </div>
            </div>
        `;
    }

    closeSellerDetail() {
        document.getElementById('sellerDetailModal').style.display = 'none';
    }

    viewSellerProducts(sellerId) {
        // Redirect to seller's products page
        window.location.href = `../products/list.php?seller=${sellerId}`;
    }

    showLoading() {
        document.getElementById('loadingState').style.display = 'block';
        document.getElementById('sellersGrid').style.display = 'none';
        document.getElementById('emptyState').style.display = 'none';
    }

    hideLoading() {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('sellersGrid').style.display = 'grid';
    }

    showEmptyState() {
        document.getElementById('emptyState').style.display = 'block';
        document.getElementById('sellersGrid').style.display = 'none';
    }

    hideEmptyState() {
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('sellersGrid').style.display = 'grid';
    }

    // Utility methods
    formatCurrency(amount) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(amount);
    }

    formatNumber(number) {
        return new Intl.NumberFormat('vi-VN').format(number);
    }

    formatDate(date) {
        return new Date(date).toLocaleDateString('vi-VN');
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showError(message) {
        console.error('Sellers Error:', message);
        // You can implement a toast notification here
    }
}

// Initialize sellers manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.sellersManager = new TopSellersManager();
});
</script>
