<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng ký - Bookverse</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../assets/css/notifications.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow-x: hidden;
        }

        /* Background Elements */
        .bg-shapes {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .shape {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: float 6s ease-in-out infinite;
        }

        .shape-1 {
            width: 80px;
            height: 80px;
            top: 20%;
            left: 10%;
            animation-delay: 0s;
        }

        .shape-2 {
            width: 120px;
            height: 120px;
            top: 60%;
            right: 15%;
            animation-delay: 2s;
        }

        .shape-3 {
            width: 60px;
            height: 60px;
            top: 40%;
            left: 80%;
            animation-delay: 4s;
        }

        .shape-4 {
            width: 100px;
            height: 100px;
            bottom: 20%;
            left: 20%;
            animation-delay: 1s;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(180deg); }
        }

        /* Floating Books */
        .floating-books {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            pointer-events: none;
        }

        .book {
            position: absolute;
            font-size: 2rem;
            animation: floatBook 8s ease-in-out infinite;
        }

        .book-1 {
            top: 10%;
            left: 5%;
            animation-delay: 0s;
        }

        .book-2 {
            top: 30%;
            right: 10%;
            animation-delay: 2s;
        }

        .book-3 {
            top: 60%;
            left: 8%;
            animation-delay: 4s;
        }

        .book-4 {
            top: 80%;
            right: 15%;
            animation-delay: 6s;
        }

        .book-5 {
            top: 50%;
            left: 85%;
            animation-delay: 1s;
        }

        @keyframes floatBook {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-30px) rotate(10deg); }
        }

        /* Back to Home */
        .auth-back-home {
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 10;
        }

        .back-link {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            background: rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 25px;
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .back-link:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: translateY(-2px);
        }

        .back-icon {
            font-size: 1.2rem;
        }

        /* Main Container */
        .auth-container {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            padding: 40px;
            width: 100%;
            max-width: 500px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            position: relative;
            z-index: 2;
        }

        h1 {
            text-align: center;
            color: #1f2937;
            font-size: 2.5rem;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .subtitle {
            text-align: center;
            color: #6b7280;
            margin-bottom: 30px;
            font-size: 1rem;
        }


        /* Account Type Selection */
        .account-type-selection {
            margin-bottom: 30px;
        }

        .account-type-selection h3 {
            color: #1f2937;
            font-size: 1.125rem;
            font-weight: 600;
            margin-bottom: 15px;
        }

        .account-types {
            display: flex;
            gap: 15px;
        }

        .account-type-card {
            flex: 1;
            padding: 20px;
            border: 2px solid #e5e7eb;
            border-radius: 12px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            background: white;
        }

        .account-type-card:hover {
            border-color: #3b82f6;
            transform: translateY(-2px);
        }

        .account-type-card.active {
            border-color: #3b82f6;
            background: #eff6ff;
        }

        .account-icon {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .account-type-card h4 {
            color: #1f2937;
            font-size: 1rem;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .account-type-card p {
            color: #6b7280;
            font-size: 0.875rem;
        }

        /* Form Styles */
        .auth-form {
            margin-top: 30px;
        }

        .form-row {
            display: flex;
            gap: 15px;
        }

        .form-group {
            margin-bottom: 20px;
            flex: 1;
        }

        .form-group.full-width {
            flex: none;
        }

        label {
            display: block;
            color: #374151;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 0.875rem;
        }

        input {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e5e7eb;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: white;
        }

        input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }

        input::placeholder {
            color: #9ca3af;
        }

        /* Password Toggle */
        .password-field {
            position: relative;
        }

        .password-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: #6b7280;
            font-size: 1.2rem;
        }

        /* Checkbox */
        .checkbox-group {
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
            margin: 0;
        }

        .checkbox-group label {
            margin: 0;
            font-size: 0.875rem;
            line-height: 1.4;
        }

        .link {
            color: #3b82f6;
            text-decoration: none;
        }

        .link:hover {
            text-decoration: underline;
        }

        /* Submit Button */
        .auth-btn {
            width: 100%;
            padding: 14px 20px;
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 20px;
        }

        .auth-btn:hover {
            background: linear-gradient(135deg, #1d4ed8, #1e40af);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(59, 130, 246, 0.3);
        }

        /* Footer */
        .auth-footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }

        .auth-footer p {
            color: #6b7280;
            font-size: 0.875rem;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .auth-container {
                padding: 30px 20px;
                margin: 10px;
            }

            .form-row {
                flex-direction: column;
                gap: 0;
            }

            .account-types {
                flex-direction: column;
            }

            .auth-socials {
                flex-direction: column;
            }

            h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <!-- Background Elements -->
    <div class="bg-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
    </div>
    
    <!-- Floating Books -->
    <div class="floating-books">
        <div class="book book-1">📚</div>
        <div class="book book-2">📖</div>
        <div class="book book-3">📗</div>
        <div class="book book-4">📘</div>
        <div class="book book-5">📙</div>
    </div>
    
    <!-- Back to Home Link -->
    <div class="auth-back-home">
        <a href="../../index.php" class="back-link">
            <span class="back-icon">←</span>
            <span>Về trang chủ</span>
        </a>
    </div>

    <div class="auth-container">
        <h1>Đăng ký</h1>
        <p class="subtitle">Tham gia cộng đồng Bookverse ngay hôm nay</p>
        
        
        <!-- Account Type Selection -->
        <div class="account-type-selection">
            <h3>Chọn loại tài khoản</h3>
            <div class="account-types">
                <div class="account-type-card active" data-type="buyer">
                    <div class="account-icon">👤</div>
                    <h4>Người mua</h4>
                    <p>Mua sách và quản lý đơn hàng</p>
                </div>
                <div class="account-type-card" data-type="seller">
                    <div class="account-icon">🏪</div>
                    <h4>Người bán</h4>
                    <p>Bán sách và quản lý cửa hàng</p>
                </div>
            </div>
        </div>
        
        <!-- Registration Form -->
        <form id="registerForm" class="auth-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="lastName">Họ</label>
                    <input type="text" id="lastName" name="lastName" placeholder="Nhập họ của bạn" required>
                </div>
                <div class="form-group">
                    <label for="firstName">Tên</label>
                    <input type="text" id="firstName" name="firstName" placeholder="Nhập tên của bạn" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="username">Tên đăng nhập</label>
                <input type="text" id="username" name="username" placeholder="Chọn tên đăng nhập" required>
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" placeholder="Nhập email của bạn" required>
            </div>
            
            <div class="form-group">
                <label for="password">Mật khẩu</label>
                <div class="password-field">
                    <input type="password" id="password" name="password" placeholder="Tạo mật khẩu mạnh" required>
                    <button type="button" class="password-toggle" onclick="togglePassword('password')">👁️</button>
                </div>
            </div>
            
            <div class="form-group">
                <label for="confirmPassword">Xác nhận mật khẩu</label>
                <div class="password-field">
                    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Nhập lại mật khẩu" required>
                    <button type="button" class="password-toggle" onclick="togglePassword('confirmPassword')">👁️</button>
                </div>
            </div>
            
            <div class="form-group checkbox-group">
                <input type="checkbox" id="agreeTerms" name="agreeTerms" required>
                <label for="agreeTerms">Tôi đồng ý với <a href="#" class="link">Điều khoản sử dụng</a> và <a href="#" class="link">Chính sách bảo mật</a></label>
            </div>
            
            <button type="submit" class="auth-btn">
                <span>Đăng ký</span>
            </button>
        </form>
        
        <div class="auth-footer">
            <p>Đã có tài khoản? <a href="login.php" class="link">Đăng nhập ngay</a></p>
        </div>
    </div>

    <!-- Include notification system -->
    <script src="../../assets/js/notifications.js"></script>
    <script src="../../assets/js/config.js"></script>
    <script src="../../assets/js/api.js"></script>
    
    <script>
        // Account type selection
        document.addEventListener('DOMContentLoaded', function() {
            const accountTypeCards = document.querySelectorAll('.account-type-card');
            accountTypeCards.forEach(card => {
                card.addEventListener('click', function() {
                    accountTypeCards.forEach(c => c.classList.remove('active'));
                    this.classList.add('active');
                });
            });
            
            // Form submission
            const form = document.getElementById('registerForm');
            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                // Show loading state
                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<span class="btn-icon">⏳</span> Đang xử lý...';
                submitBtn.disabled = true;
                
                try {
                    // Get form data
                    const formData = new FormData(form);
                    const data = Object.fromEntries(formData);
                    
                    // Basic validation
                    if (!data.firstName || !data.lastName) {
                        showError('⚠️ Vui lòng nhập đầy đủ họ và tên!');
                        return;
                    }
                    
                    if (!data.username || data.username.length < 3) {
                        showError('⚠️ Tên đăng nhập phải có ít nhất 3 ký tự!');
                        return;
                    }
                    
                    if (!data.email || !data.email.includes('@')) {
                        showError('⚠️ Email không hợp lệ!');
                        return;
                    }
                    
                    if (!data.password || data.password.length < 6) {
                        showError('⚠️ Mật khẩu phải có ít nhất 6 ký tự!');
                        return;
                    }
                    
                    if (data.password !== data.confirmPassword) {
                        showError('❌ Mật khẩu xác nhận không khớp!');
                        return;
                    }
                    
                    if (!data.agreeTerms) {
                        showError('⚠️ Vui lòng đồng ý với điều khoản sử dụng!');
                        return;
                    }
                    
                    // Get selected account type
                    const selectedType = document.querySelector('.account-type-card.active')?.dataset.type;
                    if (!selectedType) {
                        showError('Vui lòng chọn loại tài khoản!');
                        return;
                    }
                    
                    // Prepare registration data
                    const registrationData = {
                        username: data.username.trim(),
                        email: data.email.trim(),
                        password: data.password,
                        profile: {
                            firstName: data.firstName.trim(),
                            lastName: data.lastName.trim()
                        },
                        role: selectedType === 'seller' ? 'seller' : 'user'
                    };
                    
                    console.log('📝 Registering with data:', registrationData);
                    
                    // Show loading notification
                    const loadingId = showLoading('Đang tạo tài khoản...');
                    
                    // Call real API
                    const response = await api.register(registrationData);
                    
                    // Close loading notification
                    notificationManager.close(loadingId);
                    
                    console.log('✅ Registration response:', response);
                    
                    // Show success notification
                    const accountTypeText = selectedType === 'buyer' ? 'Người mua' : 'Người bán';
                    let successMessage = `🎉 Đăng ký thành công!\n\nLoại tài khoản: ${accountTypeText}\nEmail: ${data.email}`;
                    
                    if (selectedType === 'seller') {
                        successMessage += '\n\n⚠️ Tài khoản người bán cần được admin phê duyệt trước khi có thể bán hàng.';
                    }
                    
                    successMessage += '\n\nChuyển đến trang đăng nhập...';
                    
                    showAuthSuccess(successMessage, 'login.php');
                    
                } catch (error) {
                    console.error('Registration error:', error);
                    notificationManager.close(loadingId);
                    
                    // Parse error message
                    let errorMessage = 'Có lỗi xảy ra khi đăng ký. Vui lòng thử lại!';
                    
                    if (error.message) {
                        errorMessage = error.message;
                    } else if (error.error) {
                        errorMessage = error.error;
                    }
                    
                    // User-friendly error messages
                    if (errorMessage.includes('Email already registered') || errorMessage.includes('email') && errorMessage.includes('exists')) {
                        errorMessage = '📧 Email này đã được đăng ký. Vui lòng sử dụng email khác hoặc đăng nhập.';
                    } else if (errorMessage.includes('Username already taken') || errorMessage.includes('username') && errorMessage.includes('exists')) {
                        errorMessage = '👤 Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác.';
                    } else if (errorMessage.includes('validation') || errorMessage.includes('invalid')) {
                        errorMessage = '⚠️ Thông tin không hợp lệ. Vui lòng kiểm tra lại.';
                    } else if (errorMessage.includes('network') || errorMessage.includes('fetch')) {
                        errorMessage = '🌐 Không thể kết nối đến server. Vui lòng kiểm tra kết nối mạng.';
                    }
                    
                    showAuthError(errorMessage);
                } finally {
                    // Reset button state
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                }
            });
        });
        
        // Password toggle
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const button = field.nextElementSibling;
            
            if (field.type === 'password') {
                field.type = 'text';
                button.textContent = '🙈';
            } else {
                field.type = 'password';
                button.textContent = '👁️';
            }
        }
        
        // Helper functions for notifications
        function showAuthSuccess(message, redirectUrl) {
            return notificationManager.showAuthSuccess(message, redirectUrl);
        }
        
        function showAuthError(message) {
            return notificationManager.showAuthError(message);
        }
        
    </script>
</body>
</html>
