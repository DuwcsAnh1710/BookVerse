<?php 
$pageTitle='Đặt lại mật khẩu'; 
$extraCss=['../../assets/css/main.css', '../../assets/css/auth.css']; 
$extraJs=['../../assets/js/main.js', '../../assets/js/api.js', '../../assets/js/auth.js'];
include __DIR__.'/../../includes/auth-header.php'; 
?>

<!-- Back to Home Link -->
<div class="auth-back-home">
    <a href="../../index.php" class="back-link">
        <span class="back-icon">←</span>
        <span>Về trang chủ</span>
    </a>
</div>

<!-- Auth Background -->
<div class="auth-background">
    <div class="bg-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
    </div>
    <div class="floating-books">
        <div class="book book-1">📚</div>
        <div class="book book-2">📖</div>
        <div class="book book-3">📕</div>
        <div class="book book-4">📗</div>
        <div class="book book-5">📘</div>
    </div>
</div>

<main>
    <div class="auth-container">
        <h1>Đặt lại mật khẩu</h1>
        <p style="text-align: center; color: #6b7280; margin-bottom: 2rem;">
            Nhập mã OTP và mật khẩu mới để hoàn tất việc đặt lại
        </p>
        
        <form id="resetForm" class="auth-form">
            <div id="resetError" class="error-message" style="display: none;"></div>
            <div id="resetSuccess" class="success-message" style="display: none;"></div>
            
            <label>
                Email
                <input type="email" name="email" required placeholder="Nhập email đã đăng ký" />
            </label>
            
            <label>
                Mã OTP
                <input type="text" name="otp" required placeholder="Nhập mã OTP 6 số" maxlength="6" />
            </label>
            
            <label>
                Mật khẩu mới
                <div class="input-with-icon">
                    <input type="password" name="newPassword" id="newPasswordInput" required placeholder="Tạo mật khẩu mới" />
                    <button type="button" id="toggleNewPwd" class="eye-btn" aria-label="Hiển thị/ẩn mật khẩu">👁️</button>
                </div>
            </label>
            
            <label>
                Xác nhận mật khẩu mới
                <div class="input-with-icon">
                    <input type="password" name="confirmPassword" id="confirmNewPasswordInput" required placeholder="Nhập lại mật khẩu mới" />
                    <button type="button" id="toggleConfirmNewPwd" class="eye-btn" aria-label="Hiển thị/ẩn mật khẩu">👁️</button>
                </div>
            </label>
            
            <button type="submit" class="btn btn-primary btn-block" id="resetBtn">
                <span class="btn-text">Đặt lại mật khẩu</span>
                <span class="btn-loading" style="display: none;">⏳</span>
            </button>
            
            <p class="muted">
                Chưa nhận được mã? 
                <a href="forgot.php">Gửi lại mã OTP</a>
            </p>
        </form>
    </div>
</main>

<?php include __DIR__.'/../../includes/auth-footer.php'; ?>