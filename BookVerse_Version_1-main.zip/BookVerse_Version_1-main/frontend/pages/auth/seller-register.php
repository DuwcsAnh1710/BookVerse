<?php 
$pageTitle='Đăng ký Seller'; 
$extraCss=['../../assets/css/main.css', '../../assets/css/auth.css']; 
$extraJs=['../../assets/js/main.js', '../../assets/js/api.js', '../../assets/js/auth.js'];
include __DIR__.'/../../includes/auth-header.php'; 
?>

<!-- Back to Home Link -->
<div class="auth-back-home">
    <a href="../../index.php" class="back-link">
        <span class="back-icon">←</span>
        <span>Về trang chủ</span>
    </a>
</div>

<!-- Auth Background -->
<div class="auth-background">
    <div class="bg-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
    </div>
    <div class="floating-books">
        <div class="book book-1">🏪</div>
        <div class="book book-2">💰</div>
        <div class="book book-3">📦</div>
        <div class="book book-4">📊</div>
        <div class="book book-5">💼</div>
    </div>
</div>

<main>
    <div class="auth-container seller-register">
        <div class="seller-badge">
            <span class="seller-icon">🏪</span>
            <span>Seller Registration</span>
        </div>
        
        <h1>Đăng ký làm Seller</h1>
        <p style="text-align: center; color: #6b7280; margin-bottom: 2rem;">Bắt đầu bán sách trên Bookverse và kiếm tiền từ đam mê của bạn</p>
        
        <form id="sellerRegisterForm" class="auth-form">
            <div id="sellerRegisterError" class="error-message" style="display: none;"></div>
            
            <!-- Personal Information -->
            <div class="form-section">
                <h3>Thông tin cá nhân</h3>
                <div class="form-row">
                    <label>
                        Họ
                        <input type="text" name="firstName" placeholder="Nhập họ của bạn" />
                    </label>
                    <label>
                        Tên
                        <input type="text" name="lastName" placeholder="Nhập tên của bạn" />
                    </label>
                </div>
                
                <label>
                    Tên đăng nhập
                    <input type="text" name="username" required placeholder="Chọn tên đăng nhập" />
                </label>
                
                <label>
                    Email
                    <input type="email" name="email" required placeholder="Nhập email của bạn" />
                </label>
                
                <label>
                    Số điện thoại
                    <input type="tel" name="phone" placeholder="Nhập số điện thoại" />
                </label>
                
                <label>
                    Mật khẩu
                    <div class="input-with-icon">
                        <input type="password" name="password" id="sellerPasswordInput" required placeholder="Tạo mật khẩu mạnh" />
                        <button type="button" id="toggleSellerPwd" class="eye-btn" aria-label="Hiển thị/ẩn mật khẩu">👁️</button>
                    </div>
                </label>
                
                <label>
                    Xác nhận mật khẩu
                    <div class="input-with-icon">
                        <input type="password" name="confirmPassword" id="sellerConfirmPasswordInput" required placeholder="Nhập lại mật khẩu" />
                        <button type="button" id="toggleSellerConfirmPwd" class="eye-btn" aria-label="Hiển thị/ẩn mật khẩu">👁️</button>
                    </div>
                </label>
            </div>
            
            <!-- Business Information -->
            <div class="form-section">
                <h3>Thông tin kinh doanh</h3>
                
                <label>
                    Tên cửa hàng
                    <input type="text" name="storeName" required placeholder="Nhập tên cửa hàng của bạn" />
                </label>
                
                <label>
                    Mô tả cửa hàng
                    <textarea name="storeDescription" rows="3" placeholder="Mô tả ngắn về cửa hàng của bạn"></textarea>
                </label>
                
                <label>
                    Địa chỉ cửa hàng
                    <input type="text" name="storeAddress" placeholder="Địa chỉ cửa hàng" />
                </label>
                
                <div class="form-row">
                    <label>
                        Thành phố
                        <input type="text" name="city" placeholder="Thành phố" />
                    </label>
                    <label>
                        Quận/Huyện
                        <input type="text" name="district" placeholder="Quận/Huyện" />
                    </label>
                </div>
            </div>
            
            <!-- Business Documents -->
            <div class="form-section">
                <h3>Tài liệu kinh doanh</h3>
                
                <label>
                    Số CMND/CCCD
                    <input type="text" name="idNumber" placeholder="Nhập số CMND/CCCD" />
                </label>
                
                <label>
                    Ngày cấp CMND/CCCD
                    <input type="date" name="idIssueDate" />
                </label>
                
                <label>
                    Nơi cấp CMND/CCCD
                    <input type="text" name="idIssuePlace" placeholder="Nơi cấp CMND/CCCD" />
                </label>
                
                <label>
                    Mã số thuế (nếu có)
                    <input type="text" name="taxCode" placeholder="Mã số thuế" />
                </label>
            </div>
            
            <!-- Terms and Conditions -->
            <div class="form-checkbox">
                <input type="checkbox" id="agreeSellerTerms" name="agreeTerms" required />
                <label for="agreeSellerTerms">
                    Tôi đồng ý với 
                    <a href="#" target="_blank">Điều khoản sử dụng</a> 
                    và 
                    <a href="#" target="_blank">Chính sách bảo mật</a>
                    của Bookverse
                </label>
            </div>
            
            <div class="form-checkbox">
                <input type="checkbox" id="agreeSellerPolicy" name="agreeSellerPolicy" required />
                <label for="agreeSellerPolicy">
                    Tôi cam kết tuân thủ 
                    <a href="#" target="_blank">Chính sách người bán</a>
                    và các quy định của Bookverse
                </label>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block" id="sellerRegisterBtn">
                <span class="btn-text">Đăng ký làm Seller</span>
                <span class="btn-loading" style="display: none;">⏳</span>
            </button>
            
            <p class="muted">
                Đã có tài khoản? 
                <a href="login.php">Đăng nhập ngay</a>
            </p>
        </form>
    </div>
</main>

<style>
.seller-register {
    background: linear-gradient(135deg, #059669 0%, #10b981 100%);
    color: white;
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(5, 150, 105, 0.3);
}

.seller-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 0.75rem 1.5rem;
    border-radius: 50px;
    margin-bottom: 1.5rem;
    font-weight: 600;
    backdrop-filter: blur(10px);
}

.seller-icon {
    font-size: 1.2rem;
}

.seller-register h1 {
    color: white;
    text-align: center;
    margin-bottom: 0.5rem;
}

.seller-register .auth-form {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 12px;
    padding: 2rem;
}

.seller-register .form-section {
    margin-bottom: 2rem;
    padding-bottom: 1.5rem;
    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
}

.seller-register .form-section:last-of-type {
    border-bottom: none;
    margin-bottom: 0;
}

.seller-register .form-section h3 {
    color: white;
    font-size: 1.1rem;
    font-weight: 600;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.seller-register .form-section h3::before {
    content: "📋";
    font-size: 1rem;
}

.seller-register .auth-form label {
    color: white;
}

.seller-register .auth-form input,
.seller-register .auth-form textarea {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
}

.seller-register .auth-form input::placeholder,
.seller-register .auth-form textarea::placeholder {
    color: rgba(255, 255, 255, 0.7);
}

.seller-register .auth-form input:focus,
.seller-register .auth-form textarea:focus {
    background: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.5);
}

.seller-register .btn-primary {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
}

.seller-register .btn-primary:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
}

.seller-register .muted {
    color: rgba(255, 255, 255, 0.8);
}

.seller-register a {
    color: white;
    text-decoration: underline;
}

.seller-register a:hover {
    color: rgba(255, 255, 255, 0.8);
}
</style>

<?php include __DIR__.'/../../includes/auth-footer.php'; ?>
