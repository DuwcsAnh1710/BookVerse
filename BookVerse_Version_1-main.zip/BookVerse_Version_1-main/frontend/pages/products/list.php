<?php 
$pageTitle='Sản phẩm - Bookverse'; 
$extraCss=['assets/css/global.css', 'assets/css/products.css']; 
$extraJs=['assets/js/config.js', 'assets/js/api.js', 'assets/js/main.js', 'assets/js/pages/products-debug.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<main class="products-main">
    <div class="container">
        <!-- Hero Section -->
        <section class="hero-section">
            <div class="hero-content">
                <h1 class="hero-title">Khám phá thế giới sách</h1>
                <p class="hero-subtitle">Hàng nghìn cuốn sách từ các nhà xuất bản uy tín, giá tốt nhất thị trường</p>
                <div class="hero-search">
                    <div class="search-box">
                        <input type="text" id="searchInput" placeholder="Tìm kiếm sách, tác giả, ISBN..." class="search-input">
                        <button class="search-btn" id="searchBtn">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Quick Categories -->
        <section class="quick-categories">
            <div class="section-header">
                <h2>Danh mục nổi bật</h2>
            </div>
            <div class="categories-grid">
                <a href="#" class="category-card" data-category="fiction">
                    <div class="category-icon">📚</div>
                    <h3>Tiểu thuyết</h3>
                    <p>Hơn 2,000 cuốn</p>
                </a>
                <a href="#" class="category-card" data-category="business">
                    <div class="category-icon">💼</div>
                    <h3>Kinh doanh</h3>
                    <p>Hơn 1,500 cuốn</p>
                </a>
                <a href="#" class="category-card" data-category="education">
                    <div class="category-icon">🎓</div>
                    <h3>Giáo dục</h3>
                    <p>Hơn 3,000 cuốn</p>
                </a>
                <a href="#" class="category-card" data-category="children">
                    <div class="category-icon">👶</div>
                    <h3>Thiếu nhi</h3>
                    <p>Hơn 1,200 cuốn</p>
                </a>
                <a href="#" class="category-card" data-category="technology">
                    <div class="category-icon">💻</div>
                    <h3>Công nghệ</h3>
                    <p>Hơn 800 cuốn</p>
                </a>
                <a href="#" class="category-card" data-category="health">
                    <div class="category-icon">🏥</div>
                    <h3>Sức khỏe</h3>
                    <p>Hơn 600 cuốn</p>
                </a>
        </div>
        </section>

        <!-- Main Content -->
        <div class="products-layout">
            <!-- Filters Sidebar -->
            <aside class="filters-sidebar">
                <div class="filters-header">
                    <h3>Bộ lọc</h3>
                    <button class="clear-filters" id="clearFilters">Xóa bộ lọc</button>
                </div>

                <div class="filter-section">
                    <h4>Danh mục</h4>
                    <div class="filter-options">
                        <label class="filter-option">
                            <input type="checkbox" name="category" value="fiction">
                            <span class="checkmark"></span>
                            Tiểu thuyết
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="category" value="business">
                            <span class="checkmark"></span>
                            Kinh doanh
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="category" value="education">
                            <span class="checkmark"></span>
                            Giáo dục
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="category" value="children">
                            <span class="checkmark"></span>
                            Thiếu nhi
                        </label>
                        <label class="filter-option">
                            <input type="checkbox" name="category" value="technology">
                            <span class="checkmark"></span>
                            Công nghệ
                        </label>
                    </div>
                </div>


                <div class="filter-section">
                    <h4>Đánh giá</h4>
                    <div class="rating-options">
                        <label class="rating-option">
                            <input type="checkbox" name="rating" value="5">
                            <span class="stars">★★★★★</span>
                            <span>5 sao</span>
                        </label>
                        <label class="rating-option">
                            <input type="checkbox" name="rating" value="4">
                            <span class="stars">★★★★☆</span>
                            <span>4 sao trở lên</span>
                        </label>
                        <label class="rating-option">
                            <input type="checkbox" name="rating" value="3">
                            <span class="stars">★★★☆☆</span>
                            <span>3 sao trở lên</span>
                        </label>
                    </div>
                </div>

                <div class="filter-section">
                    <h4>Tình trạng</h4>
                    <div class="condition-options">
                        <label class="condition-option">
                            <input type="radio" name="condition" value="new" checked>
                            <span class="radio-mark"></span>
                            Sách mới
                        </label>
                        <label class="condition-option">
                            <input type="radio" name="condition" value="used">
                            <span class="radio-mark"></span>
                            Sách cũ
                        </label>
                        <label class="condition-option">
                            <input type="radio" name="condition" value="all">
                            <span class="radio-mark"></span>
                            Tất cả
                        </label>
                    </div>
                </div>
            </aside>

            <!-- Products Content -->
            <div class="products-content">
                <!-- Products Header -->
                <div class="products-header">
                    <div class="products-info">
                        <h2>Kết quả tìm kiếm</h2>
                        <p class="products-count">Hiển thị <span id="productsCount">1,234</span> sản phẩm</p>
                    </div>
                    <div class="products-controls">
                    <div class="sort-controls">
                            <label for="sortSelect">Sắp xếp:</label>
                            <select id="sortSelect" class="sort-select">
                                <option value="popular">Phổ biến</option>
                                <option value="newest">Mới nhất</option>
                                <option value="price-low">Giá thấp đến cao</option>
                                <option value="price-high">Giá cao đến thấp</option>
                                <option value="rating">Đánh giá cao</option>
			</select>
                        </div>
                        <div class="view-controls">
                            <button class="view-btn active" data-view="grid" title="Lưới">
                                <i class="fas fa-th"></i>
                            </button>
                            <button class="view-btn" data-view="list" title="Danh sách">
                                <i class="fas fa-list"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Products Grid -->
                <div class="products-grid" id="productsGrid" data-managed="manual">
                    <div class="product-card">
                        <div class="product-image">
                            <img src="https://via.placeholder.com/300x400/4a90e2/ffffff?text=Sách+1" alt="Sách 1">
                            <div class="product-badge">Mới</div>
                            <div class="product-actions">
                                <button class="action-btn wishlist" title="Yêu thích">
                                    <i class="far fa-heart"></i>
                                </button>
                                <button class="action-btn quick-view" title="Xem nhanh">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Tên sách dài có thể xuống dòng</h3>
                            <p class="product-author">Tác giả: Nguyễn Văn A</p>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <span class="rating-count">(123)</span>
                            </div>
                            <div class="product-price">
                                <span class="current-price">299,000đ</span>
                                <span class="original-price">399,000đ</span>
                                <span class="discount">-25%</span>
                            </div>
                            <button class="add-to-cart">
                                <i class="fas fa-shopping-cart"></i>
                                Thêm vào giỏ
                            </button>
                        </div>
                    </div>

                    <!-- Product Card 2 -->
                    <div class="product-card">
                        <div class="product-image">
                            <img src="https://via.placeholder.com/300x400/50c878/ffffff?text=Sách+2" alt="Sách 2">
                            <div class="product-badge sale">Giảm giá</div>
                            <div class="product-actions">
                                <button class="action-btn wishlist" title="Yêu thích">
                                    <i class="far fa-heart"></i>
                                </button>
                                <button class="action-btn quick-view" title="Xem nhanh">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Sách kinh doanh hay</h3>
                            <p class="product-author">Tác giả: Trần Thị B</p>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <span class="rating-count">(89)</span>
                            </div>
                            <div class="product-price">
                                <span class="current-price">199,000đ</span>
                                <span class="original-price">299,000đ</span>
                                <span class="discount">-33%</span>
                            </div>
                            <button class="add-to-cart">
                                <i class="fas fa-shopping-cart"></i>
                                Thêm vào giỏ
                            </button>
                        </div>
                    </div>

                    <!-- Product Card 3 -->
                    <div class="product-card">
                        <div class="product-image">
                            <img src="https://via.placeholder.com/300x400/ff6b6b/ffffff?text=Sách+3" alt="Sách 3">
                            <div class="product-actions">
                                <button class="action-btn wishlist" title="Yêu thích">
                                    <i class="far fa-heart"></i>
                                </button>
                                <button class="action-btn quick-view" title="Xem nhanh">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Sách giáo dục</h3>
                            <p class="product-author">Tác giả: Lê Văn C</p>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <span class="rating-count">(67)</span>
                            </div>
                            <div class="product-price">
                                <span class="current-price">149,000đ</span>
                            </div>
                            <button class="add-to-cart">
                                <i class="fas fa-shopping-cart"></i>
                                Thêm vào giỏ
                            </button>
                        </div>
                    </div>

                    <!-- Product Card 4 -->
                    <div class="product-card">
                        <div class="product-image">
                            <img src="https://via.placeholder.com/300x400/9b59b6/ffffff?text=Sách+4" alt="Sách 4">
                            <div class="product-badge">Bán chạy</div>
                            <div class="product-actions">
                                <button class="action-btn wishlist" title="Yêu thích">
                                    <i class="far fa-heart"></i>
                                </button>
                                <button class="action-btn quick-view" title="Xem nhanh">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Sách thiếu nhi</h3>
                            <p class="product-author">Tác giả: Phạm Thị D</p>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <span class="rating-count">(45)</span>
                            </div>
                            <div class="product-price">
                                <span class="current-price">89,000đ</span>
                            </div>
                            <button class="add-to-cart">
                                <i class="fas fa-shopping-cart"></i>
                                Thêm vào giỏ
                            </button>
                        </div>
                    </div>

                    <!-- Product Card 5 -->
                    <div class="product-card">
                        <div class="product-image">
                            <img src="https://via.placeholder.com/300x400/3498db/ffffff?text=Sách+5" alt="Sách 5">
                            <div class="product-actions">
                                <button class="action-btn wishlist" title="Yêu thích">
                                    <i class="far fa-heart"></i>
                                </button>
                                <button class="action-btn quick-view" title="Xem nhanh">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Sách công nghệ</h3>
                            <p class="product-author">Tác giả: Hoàng Văn E</p>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="far fa-star"></i>
                                </div>
                                <span class="rating-count">(23)</span>
                            </div>
                            <div class="product-price">
                                <span class="current-price">399,000đ</span>
                            </div>
                            <button class="add-to-cart">
                                <i class="fas fa-shopping-cart"></i>
                                Thêm vào giỏ
                            </button>
                    </div>
                </div>

                    <!-- Product Card 6 -->
                    <div class="product-card">
                        <div class="product-image">
                            <img src="https://via.placeholder.com/300x400/e74c3c/ffffff?text=Sách+6" alt="Sách 6">
                            <div class="product-badge">Hot</div>
                            <div class="product-actions">
                                <button class="action-btn wishlist" title="Yêu thích">
                                    <i class="far fa-heart"></i>
                                </button>
                                <button class="action-btn quick-view" title="Xem nhanh">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Sách sức khỏe</h3>
                            <p class="product-author">Tác giả: Võ Thị F</p>
                            <div class="product-rating">
                                <div class="stars">
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <span class="rating-count">(156)</span>
                            </div>
                            <div class="product-price">
                                <span class="current-price">179,000đ</span>
                            </div>
                            <button class="add-to-cart">
                                <i class="fas fa-shopping-cart"></i>
                                Thêm vào giỏ
                    </button>
                        </div>
                    </div>
                </div>

                <!-- Pagination -->
                <div class="pagination">
                    <button class="pagination-btn prev" disabled>
                        <i class="fas fa-chevron-left"></i>
                        Trước
                    </button>
                    <div class="pagination-numbers">
                        <button class="pagination-number active">1</button>
                        <button class="pagination-number">2</button>
                        <button class="pagination-number">3</button>
                        <button class="pagination-number">4</button>
                        <button class="pagination-number">5</button>
                    </div>
                    <button class="pagination-btn next">
                        Sau
                        <i class="fas fa-chevron-right"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    
    searchBtn.addEventListener('click', function() {
        const query = searchInput.value.trim();
        if (query) {
            console.log('Searching for:', query);
            // Implement search logic here
        }
    });
    
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            const query = this.value.trim();
            if (query) {
                console.log('Searching for:', query);
                // Implement search logic here
            }
        }
    });
    
    // Category cards
    const categoryCards = document.querySelectorAll('.category-card');
    categoryCards.forEach(card => {
        card.addEventListener('click', function(e) {
            e.preventDefault();
            const category = this.dataset.category;
            console.log('Category selected:', category);
            // Implement category filter logic here
        });
    });
    
    // Filter functionality
    const clearFilters = document.getElementById('clearFilters');
    clearFilters.addEventListener('click', function() {
        // Clear all filters
        document.querySelectorAll('input[type="checkbox"]').forEach(cb => cb.checked = false);
        document.querySelectorAll('input[type="radio"]').forEach(radio => radio.checked = false);
        document.getElementById('minPrice').value = '';
        document.getElementById('maxPrice').value = '';
        document.getElementById('priceRange').value = 500000;
        updateRangeValues();
    });
    
    // Price range slider
    const priceRange = document.getElementById('priceRange');
    const rangeMin = document.getElementById('rangeMin');
    const rangeMax = document.getElementById('rangeMax');
    
    function updateRangeValues() {
        const value = priceRange.value;
        rangeMin.textContent = '0đ';
        rangeMax.textContent = formatPrice(value);
    }
    
    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN').format(price) + 'đ';
    }
    
    priceRange.addEventListener('input', updateRangeValues);
    
    // View controls
    const viewBtns = document.querySelectorAll('.view-btn');
    const productsGrid = document.getElementById('productsGrid');
    
    viewBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            viewBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            const view = this.dataset.view;
            if (view === 'list') {
                productsGrid.classList.add('list-view');
            } else {
                productsGrid.classList.remove('list-view');
            }
        });
    });
    
    // Add to cart functionality
    const addToCartBtns = document.querySelectorAll('.add-to-cart');
    addToCartBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const productCard = this.closest('.product-card');
            const productTitle = productCard.querySelector('.product-title').textContent;
            console.log('Added to cart:', productTitle);
            
            // Show success message
            this.innerHTML = '<i class="fas fa-check"></i> Đã thêm';
            this.classList.add('added');
            
            setTimeout(() => {
                this.innerHTML = '<i class="fas fa-shopping-cart"></i> Thêm vào giỏ';
                this.classList.remove('added');
            }, 2000);
        });
    });
    
    // Wishlist functionality
    const wishlistBtns = document.querySelectorAll('.wishlist');
    wishlistBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const icon = this.querySelector('i');
            if (icon.classList.contains('far')) {
                icon.classList.remove('far');
                icon.classList.add('fas');
                this.style.color = '#e74c3c';
            } else {
                icon.classList.remove('fas');
                icon.classList.add('far');
                this.style.color = '';
            }
        });
    });
    
    // Sort functionality
    const sortSelect = document.getElementById('sortSelect');
    sortSelect.addEventListener('change', function() {
        console.log('Sort by:', this.value);
        // Implement sort logic here
    });
    
    // Pagination
    const paginationNumbers = document.querySelectorAll('.pagination-number');
    paginationNumbers.forEach(number => {
        number.addEventListener('click', function() {
            paginationNumbers.forEach(n => n.classList.remove('active'));
            this.classList.add('active');
            console.log('Page:', this.textContent);
        });
    });
    
    // ========== LOAD PRODUCTS - MOCK DATA ==========
    function loadProducts() {
        console.log('📦 Loading products (mock data)...');
        
        // Mock data - Sách hay nhất Việt Nam
        const mockProducts = [
            {
                _id: 'mock1',
                title: 'Đắc Nhân Tâm',
                author: 'Dale Carnegie',
                price: 86000,
                originalPrice: 108000,
                averageRating: 4.8,
                totalReviews: 15234,
                totalSold: 8765,
                images: [{ url: 'https://picsum.photos/seed/dac-nhan-tam/300/400' }]
            },
            {
                _id: 'mock2',
                title: 'Nhà Giả Kim',
                author: 'Paulo Coelho',
                price: 67150,
                originalPrice: 79000,
                averageRating: 4.7,
                totalReviews: 12456,
                totalSold: 7234,
                images: [{ url: 'https://picsum.photos/seed/nha-gia-kim/300/400' }]
            },
            {
                _id: 'mock3',
                title: 'Sapiens: Lược Sử Loài Người',
                author: 'Yuval Noah Harari',
                price: 188650,
                originalPrice: 269500,
                averageRating: 4.9,
                totalReviews: 9876,
                totalSold: 5432,
                images: [{ url: 'https://picsum.photos/seed/sapiens/300/400' }]
            },
            {
                _id: 'mock4',
                title: 'Atomic Habits - Thay Đổi Tí Hon',
                author: 'James Clear',
                price: 164500,
                originalPrice: 235000,
                averageRating: 4.9,
                totalReviews: 8234,
                totalSold: 4567,
                images: [{ url: 'https://picsum.photos/seed/atomic-habits/300/400' }]
            },
            {
                _id: 'mock5',
                title: 'Tuổi Trẻ Đáng Giá Bao Nhiêu',
                author: 'Rosie Nguyễn',
                price: 66400,
                originalPrice: 80000,
                averageRating: 4.6,
                totalReviews: 11234,
                totalSold: 6789,
                images: [{ url: 'https://picsum.photos/seed/tuoi-tre/300/400' }]
            },
            {
                _id: 'mock6',
                title: 'Cà Phê Cùng Tony',
                author: 'Tony Buổi Sáng',
                price: 59500,
                originalPrice: 70000,
                averageRating: 4.5,
                totalReviews: 8932,
                totalSold: 5678,
                images: [{ url: 'https://picsum.photos/seed/ca-phe-tony/300/400' }]
            },
            {
                _id: 'mock7',
                title: 'Không Diệt Không Sinh Đừng Sợ Hãi',
                author: 'Thích Nhất Hạnh',
                price: 72250,
                originalPrice: 85000,
                averageRating: 4.8,
                totalReviews: 7654,
                totalSold: 4321,
                images: [{ url: 'https://picsum.photos/seed/thich-nhat-hanh/300/400' }]
            },
            {
                _id: 'mock8',
                title: 'Tôi Thấy Hoa Vàng Trên Cỏ Xanh',
                author: 'Nguyễn Nhật Ánh',
                price: 93500,
                originalPrice: 110000,
                averageRating: 4.9,
                totalReviews: 13456,
                totalSold: 9876,
                images: [{ url: 'https://picsum.photos/seed/hoa-vang-co-xanh/300/400' }]
            },
            {
                _id: 'mock9',
                title: 'Cho Tôi Xin Một Vé Đi Tuổi Thơ',
                author: 'Nguyễn Nhật Ánh',
                price: 76500,
                originalPrice: 90000,
                averageRating: 4.8,
                totalReviews: 11234,
                totalSold: 7890,
                images: [{ url: 'https://picsum.photos/seed/ve-di-tuoi-tho/300/400' }]
            },
            {
                _id: 'mock10',
                title: 'Tâm Lý Học Về Tiền',
                author: 'Morgan Housel',
                price: 169150,
                originalPrice: 199000,
                averageRating: 4.7,
                totalReviews: 6543,
                totalSold: 3456,
                images: [{ url: 'https://picsum.photos/seed/tam-ly-tien/300/400' }]
            },
            {
                _id: 'mock11',
                title: 'Nghệ Thuật Bán Hàng Vĩ Đại',
                author: 'Joe Girard',
                price: 127500,
                originalPrice: 150000,
                averageRating: 4.6,
                totalReviews: 5432,
                totalSold: 2987,
                images: [{ url: 'https://picsum.photos/seed/nghe-thuat-ban-hang/300/400' }]
            },
            {
                _id: 'mock12',
                title: 'Đời Ngắn Đừng Ngủ Dài',
                author: 'Robin Sharma',
                price: 67150,
                originalPrice: 79000,
                averageRating: 4.5,
                totalReviews: 9876,
                totalSold: 6543,
                images: [{ url: 'https://picsum.photos/seed/doi-ngan/300/400' }]
            }
        ];
        
        console.log(`📊 Loaded ${mockProducts.length} mock products`);
        displayProducts(mockProducts);
        updateProductCount(mockProducts.length);
    }
    
    function displayProducts(products) {
        const grid = document.getElementById('productsGrid');
        
        grid.innerHTML = products.map(product => {
            const discount = product.originalPrice > product.price ? 
                Math.round((1 - product.price / product.originalPrice) * 100) : 0;
            
            return `
            <div class="product-card" data-product-id="${product._id}" style="position: relative; border-radius: 16px; overflow: hidden; background: linear-gradient(135deg, #1e293b 0%, #334155 100%); box-shadow: 0 10px 30px rgba(0,0,0,0.3); transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1); cursor: pointer;">
                <a href="detail.php?id=${product._id}" class="product-link" style="text-decoration: none; display: block;">
                    <div class="product-image" style="position: relative; width: 100%; padding-top: 133%; overflow: hidden;">
                        <img src="${product.images && product.images[0] && product.images[0].url ? product.images[0].url : 'https://via.placeholder.com/300x400?text=No+Image'}" 
                             alt="${product.title}"
                             onerror="this.src='https://via.placeholder.com/300x400?text=No+Image'"
                             style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s ease;">
                        ${discount > 0 ? `
                            <div style="position: absolute; top: 12px; right: 12px; background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 6px 12px; border-radius: 20px; font-weight: 700; font-size: 13px; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.4);">
                                -${discount}%
                            </div>
                        ` : ''}
                        <div style="position: absolute; bottom: 0; left: 0; right: 0; background: linear-gradient(to top, rgba(0,0,0,0.8) 0%, transparent 100%); padding: 20px 0; opacity: 0; transition: opacity 0.3s ease;" class="image-overlay"></div>
                    </div>
                    <div class="product-info" style="padding: 20px;">
                        <h3 class="product-title" style="color: #f8fafc; font-size: 18px; font-weight: 700; margin: 0 0 8px 0; line-height: 1.4; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; min-height: 50px;">${product.title}</h3>
                        <p class="product-author" style="color: #94a3b8; font-size: 14px; margin: 0 0 12px 0; font-weight: 500;">✍️ ${product.author}</p>
                        <div class="product-rating" style="display: flex; align-items: center; gap: 6px; margin-bottom: 12px;">
                            <div style="color: #fbbf24; font-size: 16px; letter-spacing: 2px;">${generateStars(product.averageRating || 0)}</div>
                            <span class="rating-count" style="color: #64748b; font-size: 13px; font-weight: 500;">(${(product.totalReviews || 0).toLocaleString('vi-VN')})</span>
                        </div>
                        <div class="product-price" style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
                            <span class="current-price" style="color: #ef4444; font-size: 22px; font-weight: 800;">${formatPrice(product.price)}</span>
                            ${product.originalPrice && product.originalPrice > product.price ? 
                                `<span class="original-price" style="color: #64748b; font-size: 15px; text-decoration: line-through; font-weight: 500;">${formatPrice(product.originalPrice)}</span>` 
                                : ''}
                        </div>
                        ${product.totalSold > 0 ? `
                            <div style="display: flex; align-items: center; gap: 6px; padding: 8px 12px; background: rgba(34, 197, 94, 0.1); border-radius: 8px; width: fit-content;">
                                <span style="color: #22c55e; font-size: 14px; font-weight: 600;">🔥 Đã bán: ${product.totalSold.toLocaleString('vi-VN')}</span>
                            </div>
                        ` : ''}
                    </div>
                </a>
            </div>
        `}).join('');
        
        // Add hover effects
        document.querySelectorAll('.product-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-12px) scale(1.02)';
                this.style.boxShadow = '0 20px 50px rgba(0,0,0,0.5)';
                const img = this.querySelector('img');
                if (img) img.style.transform = 'scale(1.1)';
                const overlay = this.querySelector('.image-overlay');
                if (overlay) overlay.style.opacity = '1';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
                this.style.boxShadow = '0 10px 30px rgba(0,0,0,0.3)';
                const img = this.querySelector('img');
                if (img) img.style.transform = 'scale(1)';
                const overlay = this.querySelector('.image-overlay');
                if (overlay) overlay.style.opacity = '0';
            });
        });
        
        console.log('✅ Products displayed successfully');
    }
    
    function generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        let stars = '';
        
        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                stars += '<i class="fas fa-star"></i>';
            } else if (i === fullStars && hasHalfStar) {
                stars += '<i class="fas fa-star-half-alt"></i>';
            } else {
                stars += '<i class="far fa-star"></i>';
            }
        }
        
        return stars;
    }
    
    function formatPrice(price) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(price);
    }
    
    function updateProductCount(count) {
        const countEl = document.getElementById('productsCount');
        if (countEl) {
            countEl.textContent = count.toLocaleString('vi-VN');
        }
    }
    
    function showEmptyState() {
        const grid = document.getElementById('productsGrid');
        grid.innerHTML = `
            <div style="grid-column: 1/-1; text-align: center; padding: 60px 20px;">
                <div style="font-size: 64px; margin-bottom: 20px;">📚</div>
                <h3 style="font-size: 24px; margin-bottom: 10px;">Chưa có sản phẩm nào</h3>
                <p style="color: #666;">Hiện tại chưa có sản phẩm nào để hiển thị. Vui lòng quay lại sau!</p>
            </div>
        `;
    }
    
    window.viewProduct = function(productId) {
        window.location.href = `detail.php?id=${productId}`;
    };
    
    window.addToCart = function(productId) {
        console.log('Add to cart:', productId);
        // TODO: Implement cart functionality
        alert('Đã thêm vào giỏ hàng!');
    };
    
    // Clear any hardcoded products first
    const grid = document.getElementById('productsGrid');
    if (grid) {
        grid.innerHTML = '<div style="text-align: center; padding: 40px; grid-column: 1/-1;">⏳ Đang tải sản phẩm...</div>';
    }
    
    // Load products on page load
    loadProducts();
});
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>