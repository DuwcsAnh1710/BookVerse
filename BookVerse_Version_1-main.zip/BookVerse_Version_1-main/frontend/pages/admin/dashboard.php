<?php 
$pageTitle='Admin Dashboard'; 
$extraCss=['../../assets/css/admin.css']; 
$extraJs=['https://cdn.jsdelivr.net/npm/chart.js', '../../assets/js/config.js', '../../assets/js/api.js', '../../assets/js/admin.js', '../../assets/js/analytics.js'];
include '../../includes/header.php'; 
?>

<!-- Client-side auth check for admin -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<!-- Admin Dashboard -->
<style>
/* Ultra Modern Admin Dashboard - Beautiful & User-Friendly */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
    min-height: 100vh;
    color: #1f2937;
    line-height: 1.6;
    overflow-x: hidden;
}

.admin-main {
    min-height: 100vh;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
    padding: 2rem 0;
    position: relative;
}

.admin-main::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        radial-gradient(circle at 20% 80%, rgba(120, 119, 198, 0.3) 0%, transparent 50%),
        radial-gradient(circle at 80% 20%, rgba(255, 119, 198, 0.3) 0%, transparent 50%),
        radial-gradient(circle at 40% 40%, rgba(120, 219, 255, 0.2) 0%, transparent 50%);
    pointer-events: none;
}

.admin-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 1.5rem;
    position: relative;
    z-index: 1;
}

/* Ultra Modern Header */
.dashboard-header {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(30px);
    border-radius: 24px;
    padding: 3rem;
    margin-bottom: 3rem;
    box-shadow: 
        0 25px 50px -12px rgba(0, 0, 0, 0.25),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.dashboard-header:hover {
    transform: translateY(-2px);
    box-shadow: 
        0 35px 60px -12px rgba(0, 0, 0, 0.3),
        0 0 0 1px rgba(255, 255, 255, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.dashboard-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #6366f1, #f59e0b, #10b981, #ec4899);
    border-radius: 24px 24px 0 0;
}

.dashboard-header::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    animation: rotate 20s linear infinite;
    pointer-events: none;
}

@keyframes rotate {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.header-content h1 {
    font-size: 3rem;
    font-weight: 900;
    background: linear-gradient(135deg, #6366f1, #f59e0b, #ec4899);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    gap: 1.5rem;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    position: relative;
    z-index: 2;
}

.title-icon {
    font-size: 3rem;
    background: linear-gradient(135deg, #6366f1, #f59e0b);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
    animation: pulse 2s ease-in-out infinite alternate;
}

@keyframes pulse {
    0% { transform: scale(1); }
    100% { transform: scale(1.05); }
}

.header-content p {
    color: rgba(255, 255, 255, 0.9);
    font-size: 1.25rem;
    font-weight: 500;
    margin: 0;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    position: relative;
    z-index: 2;
}

.header-actions {
    display: flex;
    gap: 1.5rem;
    align-items: center;
    margin-top: 2rem;
    position: relative;
    z-index: 2;
}

/* Ultra Modern Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 2.5rem;
    margin-bottom: 4rem;
}

.stat-card {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(30px);
    padding: 2.5rem;
    border-radius: 24px;
    box-shadow: 
        0 20px 40px -12px rgba(0, 0, 0, 0.25),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.stat-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #6366f1, #f59e0b);
    border-radius: 24px 24px 0 0;
}

.stat-card::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    animation: rotate 15s linear infinite;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.stat-card:hover::after {
    opacity: 1;
}

.stat-card:hover {
    transform: translateY(-12px) scale(1.03);
    box-shadow: 
        0 30px 60px -12px rgba(0, 0, 0, 0.4),
        0 0 0 1px rgba(255, 255, 255, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.stat-card.stat-blue::before {
    background: linear-gradient(90deg, #3b82f6, #6366f1, #8b5cf6);
}

.stat-card.stat-green::before {
    background: linear-gradient(90deg, #10b981, #059669, #047857);
}

.stat-card.stat-purple::before {
    background: linear-gradient(90deg, #8b5cf6, #7c3aed, #6d28d9);
}

.stat-card.stat-orange::before {
    background: linear-gradient(90deg, #f59e0b, #d97706, #b45309);
}

.stat-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    position: relative;
    z-index: 2;
}

.stat-icon {
    font-size: 3rem;
    opacity: 0.9;
    filter: drop-shadow(0 8px 16px rgba(0, 0, 0, 0.2));
    transition: all 0.3s ease;
}

.stat-card:hover .stat-icon {
    transform: scale(1.1) rotate(5deg);
    filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.3));
}

.stat-change {
    font-size: 0.875rem;
    font-weight: 700;
    padding: 0.75rem 1.25rem;
    border-radius: 16px;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    transition: all 0.3s ease;
}

.stat-change.positive {
    background: linear-gradient(135deg, rgba(16, 185, 129, 0.2), rgba(5, 150, 105, 0.2));
    color: #ffffff;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

.stat-change.negative {
    background: linear-gradient(135deg, rgba(239, 68, 68, 0.2), rgba(220, 38, 38, 0.2));
    color: #ffffff;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
}

.stat-value {
    font-size: 3.5rem;
    font-weight: 900;
    background: linear-gradient(135deg, #ffffff, #f8fafc);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 0.75rem;
    line-height: 1;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    position: relative;
    z-index: 2;
}

.stat-title {
    color: rgba(255, 255, 255, 0.8);
    font-size: 1.125rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    position: relative;
    z-index: 2;
}

/* Ultra Modern Quick Actions */
.quick-actions {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(30px);
    padding: 4rem;
    border-radius: 24px;
    box-shadow: 
        0 25px 50px -12px rgba(0, 0, 0, 0.25),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    margin-bottom: 4rem;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.quick-actions:hover {
    transform: translateY(-2px);
    box-shadow: 
        0 35px 60px -12px rgba(0, 0, 0, 0.3),
        0 0 0 1px rgba(255, 255, 255, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.quick-actions::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #10b981, #3b82f6, #8b5cf6);
    border-radius: 24px 24px 0 0;
}

.quick-actions::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    animation: rotate 25s linear infinite;
    pointer-events: none;
}

.section-title {
    font-size: 2.5rem;
    font-weight: 900;
    background: linear-gradient(135deg, #ffffff, #f8fafc);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
    margin-bottom: 3rem;
    text-align: center;
    text-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    position: relative;
    z-index: 2;
}

.actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2.5rem;
    position: relative;
    z-index: 2;
}

.action-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    padding: 3rem 2rem;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(20px);
    border-radius: 24px;
    text-decoration: none;
    color: inherit;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
    cursor: pointer;
}

.action-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, #6366f1, #f59e0b, #ec4899);
    opacity: 0;
    transition: opacity 0.4s ease;
    z-index: -1;
}

.action-card::after {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: conic-gradient(from 0deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    animation: rotate 20s linear infinite;
    pointer-events: none;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.action-card:hover::after {
    opacity: 1;
}

.action-card:hover {
    transform: translateY(-16px) scale(1.05);
    box-shadow: 
        0 30px 60px -12px rgba(0, 0, 0, 0.4),
        0 0 0 1px rgba(255, 255, 255, 0.3),
        inset 0 1px 0 rgba(255, 255, 255, 0.4);
    border-color: rgba(255, 255, 255, 0.4);
}

.action-card:hover::before {
    opacity: 0.2;
}

.action-card:hover .action-icon {
    transform: scale(1.3) rotate(10deg);
    filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.3));
}

.action-card:hover h3,
.action-card:hover p {
    color: #ffffff;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.action-icon {
    font-size: 4rem;
    margin-bottom: 2rem;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    filter: drop-shadow(0 8px 16px rgba(0, 0, 0, 0.2));
    position: relative;
    z-index: 2;
}

.action-card h3 {
    font-size: 1.5rem;
    font-weight: 800;
    color: rgba(255, 255, 255, 0.9);
    margin-bottom: 1rem;
    transition: all 0.3s ease;
    position: relative;
    z-index: 2;
}

.action-card p {
    color: rgba(255, 255, 255, 0.7);
    font-size: 1rem;
    line-height: 1.6;
    transition: all 0.3s ease;
    font-weight: 500;
    position: relative;
    z-index: 2;
}

/* Ultra Modern Buttons */
.btn {
    display: inline-flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem 2rem;
    border-radius: 16px;
    font-size: 1rem;
    font-weight: 700;
    text-decoration: none;
    border: 1px solid transparent;
    cursor: pointer;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
    overflow: hidden;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    backdrop-filter: blur(10px);
}

.btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.6s ease;
}

.btn:hover::before {
    left: 100%;
}

.btn::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    background: radial-gradient(circle, rgba(255, 255, 255, 0.3) 0%, transparent 70%);
    transition: all 0.4s ease;
    transform: translate(-50%, -50%);
    border-radius: 50%;
}

.btn:hover::after {
    width: 300px;
    height: 300px;
}

.btn-primary {
    background: linear-gradient(135deg, #6366f1, #4f46e5, #3730a3);
    color: #ffffff;
    border-color: rgba(255, 255, 255, 0.2);
    box-shadow: 
        0 8px 16px -4px rgba(99, 102, 241, 0.4),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
}

.btn-primary:hover {
    background: linear-gradient(135deg, #4f46e5, #3730a3, #312e81);
    transform: translateY(-4px) scale(1.02);
    box-shadow: 
        0 16px 32px -8px rgba(99, 102, 241, 0.6),
        0 0 0 1px rgba(255, 255, 255, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.btn-outline {
    background: rgba(255, 255, 255, 0.1);
    color: #ffffff;
    border-color: rgba(255, 255, 255, 0.3);
    backdrop-filter: blur(20px);
}

.btn-outline:hover {
    background: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.5);
    transform: translateY(-4px) scale(1.02);
    box-shadow: 
        0 16px 32px -8px rgba(0, 0, 0, 0.3),
        0 0 0 1px rgba(255, 255, 255, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.btn-icon {
    font-size: 1.25rem;
    transition: all 0.3s ease;
    position: relative;
    z-index: 2;
}

.btn:hover .btn-icon {
    transform: scale(1.2) rotate(5deg);
    filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.2));
}

/* Ultra Responsive Design */
@media (max-width: 1200px) {
    .admin-container {
        padding: 0 1rem;
    }
    
    .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 2rem;
    }
    
    .actions-grid {
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 2rem;
    }
}

@media (max-width: 768px) {
    .admin-container {
        padding: 0 0.75rem;
    }
    
    .dashboard-header {
        padding: 2rem;
        margin-bottom: 2rem;
    }
    
    .header-content h1 {
        font-size: 2.25rem;
        flex-direction: column;
        text-align: center;
        gap: 1rem;
    }
    
    .title-icon {
        font-size: 2.25rem;
    }
    
    .header-actions {
        flex-direction: column;
        gap: 1rem;
        margin-top: 1.5rem;
    }
    
    .stats-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
        margin-bottom: 3rem;
    }
    
    .stat-card {
        padding: 2rem;
    }
    
    .stat-value {
        font-size: 3rem;
    }
    
    .quick-actions {
        padding: 2.5rem;
        margin-bottom: 3rem;
    }
    
    .section-title {
        font-size: 2rem;
        margin-bottom: 2rem;
    }
    
    .actions-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
    
    .action-card {
        padding: 2.5rem 1.5rem;
    }
    
    .action-icon {
        font-size: 3.5rem;
        margin-bottom: 1.5rem;
    }
    
    .action-card h3 {
        font-size: 1.25rem;
    }
    
    .btn {
        padding: 0.875rem 1.5rem;
        font-size: 0.875rem;
    }
}

@media (max-width: 480px) {
    .admin-container {
        padding: 0 0.5rem;
    }
    
    .dashboard-header {
        padding: 1.5rem;
        border-radius: 20px;
    }
    
    .header-content h1 {
        font-size: 1.875rem;
    }
    
    .title-icon {
        font-size: 1.875rem;
    }
    
    .stat-card {
        padding: 1.5rem;
        border-radius: 20px;
    }
    
    .stat-value {
        font-size: 2.5rem;
    }
    
    .quick-actions {
        padding: 2rem;
        border-radius: 20px;
    }
    
    .section-title {
        font-size: 1.75rem;
    }
    
    .action-card {
        padding: 2rem 1rem;
        border-radius: 20px;
    }
    
    .action-icon {
        font-size: 3rem;
        margin-bottom: 1rem;
    }
    
    .btn {
        padding: 0.75rem 1.25rem;
        font-size: 0.8125rem;
        gap: 0.75rem;
    }
}

/* Ultra Modern Charts Section */
.charts-section {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 2.5rem;
    margin-bottom: 4rem;
}

.chart-container {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(30px);
    border-radius: 24px;
    padding: 2.5rem;
    box-shadow: 
        0 25px 50px -12px rgba(0, 0, 0, 0.25),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.chart-container:hover {
    transform: translateY(-4px);
    box-shadow: 
        0 35px 60px -12px rgba(0, 0, 0, 0.3),
        0 0 0 1px rgba(255, 255, 255, 0.2),
        inset 0 1px 0 rgba(255, 255, 255, 0.3);
}

.chart-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #6366f1, #f59e0b, #10b981);
    border-radius: 24px 24px 0 0;
}

.chart-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    position: relative;
    z-index: 2;
}

.chart-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: #ffffff;
    margin: 0;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
}

.chart-controls {
    position: relative;
    z-index: 2;
}

.form-select {
    background: rgba(255, 255, 255, 0.15);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 12px;
    padding: 0.75rem 1rem;
    color: #ffffff;
    font-size: 0.875rem;
    font-weight: 600;
    transition: all 0.3s ease;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.form-select:hover {
    background: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.4);
    color: #ffffff;
}

.form-select:focus {
    outline: none;
    background: rgba(255, 255, 255, 0.25);
    border-color: #6366f1;
    box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
    color: #ffffff;
}

.chart-content {
    position: relative;
    height: 300px;
    z-index: 2;
}

/* Chart.js Custom Styling for Better Contrast */
.chart-content canvas {
    filter: contrast(1.2) brightness(1.1);
}

/* Custom Chart Colors for Better Visibility */
:root {
    --chart-text-color: #ffffff;
    --chart-grid-color: rgba(255, 255, 255, 0.2);
    --chart-tick-color: rgba(255, 255, 255, 0.8);
}

/* Recent Activity Section */
.recent-activity {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(30px);
    border-radius: 24px;
    padding: 2.5rem;
    margin-bottom: 3rem;
    box-shadow: 
        0 25px 50px -12px rgba(0, 0, 0, 0.25),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
}

.recent-activity::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #10b981, #3b82f6, #8b5cf6);
    border-radius: 24px 24px 0 0;
}

.activity-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    position: relative;
    z-index: 2;
}

.activity-list {
    position: relative;
    z-index: 2;
}

.activity-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1.5rem;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 16px;
    margin-bottom: 1rem;
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
}

.activity-item:hover {
    background: rgba(255, 255, 255, 0.1);
    transform: translateX(8px);
    border-color: rgba(255, 255, 255, 0.2);
}

.activity-icon {
    font-size: 1.5rem;
    width: 3rem;
    height: 3rem;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 12px;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.activity-content {
    flex: 1;
}

.activity-text {
    color: #ffffff;
    font-size: 0.95rem;
    font-weight: 600;
    margin-bottom: 0.25rem;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.activity-time {
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.8125rem;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

/* System Health Section */
.system-health {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(30px);
    border-radius: 24px;
    padding: 2.5rem;
    margin-bottom: 3rem;
    box-shadow: 
        0 25px 50px -12px rgba(0, 0, 0, 0.25),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
}

.system-health::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #10b981, #3b82f6, #ec4899);
    border-radius: 24px 24px 0 0;
}

.health-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    position: relative;
    z-index: 2;
}

.health-card {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    padding: 2rem;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 20px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
}

.health-card:hover {
    background: rgba(255, 255, 255, 0.1);
    transform: translateY(-4px);
    border-color: rgba(255, 255, 255, 0.2);
}

.health-icon {
    font-size: 2rem;
    width: 4rem;
    height: 4rem;
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 16px;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.health-info h4 {
    color: #ffffff;
    font-size: 1.125rem;
    font-weight: 700;
    margin-bottom: 0.5rem;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.health-status {
    color: rgba(255, 255, 255, 0.9);
    font-size: 0.875rem;
    font-weight: 600;
    margin-bottom: 0.75rem;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

.health-metrics {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.health-metrics span {
    color: rgba(255, 255, 255, 0.8);
    font-size: 0.8125rem;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

/* Pending Approvals Section */
.pending-approvals {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(30px);
    border-radius: 24px;
    padding: 2.5rem;
    margin-bottom: 3rem;
    box-shadow: 
        0 25px 50px -12px rgba(0, 0, 0, 0.25),
        0 0 0 1px rgba(255, 255, 255, 0.1),
        inset 0 1px 0 rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.2);
    position: relative;
    overflow: hidden;
}

.pending-approvals::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 6px;
    background: linear-gradient(90deg, #f59e0b, #ec4899, #8b5cf6);
    border-radius: 24px 24px 0 0;
}

.approvals-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 2rem;
    position: relative;
    z-index: 2;
}

.approval-card {
    background: rgba(255, 255, 255, 0.05);
    border-radius: 20px;
    padding: 2rem;
    border: 1px solid rgba(255, 255, 255, 0.1);
    transition: all 0.3s ease;
    backdrop-filter: blur(10px);
}

.approval-card:hover {
    background: rgba(255, 255, 255, 0.1);
    transform: translateY(-4px);
    border-color: rgba(255, 255, 255, 0.2);
}

.approval-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.approval-header h4 {
    color: #ffffff;
    font-size: 1.125rem;
    font-weight: 700;
    margin: 0;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.approval-count {
    background: linear-gradient(135deg, #6366f1, #8b5cf6);
    color: #ffffff;
    font-size: 1.5rem;
    font-weight: 800;
    padding: 0.5rem 1rem;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.approval-card p {
    color: rgba(255, 255, 255, 0.9);
    font-size: 0.875rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
    line-height: 1.5;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

/* Responsive for new sections */
@media (max-width: 1024px) {
    .charts-section {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .health-grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1.5rem;
    }
    
    .approvals-grid {
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
    }
}

@media (max-width: 768px) {
    .chart-container,
    .recent-activity,
    .system-health,
    .pending-approvals {
        padding: 2rem;
        margin-bottom: 2rem;
    }
    
    .chart-content {
        height: 250px;
    }
    
    .health-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .approvals-grid {
        grid-template-columns: 1fr;
        gap: 1rem;
    }
    
    .health-card {
        padding: 1.5rem;
    }
    
    .approval-card {
        padding: 1.5rem;
    }
}

@media (max-width: 480px) {
    .chart-container,
    .recent-activity,
    .system-health,
    .pending-approvals {
        padding: 1.5rem;
        border-radius: 20px;
    }
    
    .chart-content {
        height: 200px;
    }
    
    .health-card {
        flex-direction: column;
        text-align: center;
        gap: 1rem;
    }
    
    .approval-header {
        flex-direction: column;
        gap: 0.5rem;
        text-align: center;
    }
}
</style>
<main class="admin-main">
    <div class="admin-container">
        <!-- Dashboard Header -->
        <div class="dashboard-header">
            <div class="header-content">
                <h1 class="dashboard-title">
                    <span class="title-icon">📊</span>
                    Admin Dashboard
                </h1>
                <p class="dashboard-subtitle">Tổng quan hệ thống Bookverse</p>
                </div>
            <div class="header-actions">
                <button class="btn btn-primary" onclick="refreshDashboard()">
                        <span class="btn-icon">🔄</span>
                    Làm mới
                    </button>
                <button class="btn btn-outline" onclick="exportReport()">
                        <span class="btn-icon">📊</span>
                    Xuất báo cáo
                    </button>
                </div>
            </div>

        <!-- Stats Overview -->
        <div class="stats-grid" id="statsGrid">
            <!-- Stats will be loaded here -->
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions">
            <h2 class="section-title">Thao tác nhanh</h2>
            <div class="actions-grid">
                <a href="users.php" class="action-card">
                    <div class="action-icon">👥</div>
                    <h3>Quản lý người dùng</h3>
                    <p>Xem và quản lý tài khoản người dùng</p>
                </a>
                <a href="products.php" class="action-card">
                    <div class="action-icon">📚</div>
                    <h3>Quản lý sản phẩm</h3>
                    <p>Phê duyệt và quản lý sản phẩm</p>
                </a>
                <a href="orders.php" class="action-card">
                    <div class="action-icon">📦</div>
                    <h3>Quản lý đơn hàng</h3>
                    <p>Theo dõi và xử lý đơn hàng</p>
                </a>
                <a href="payments.php" class="action-card">
                    <div class="action-icon">💰</div>
                    <h3>Quản lý thanh toán</h3>
                    <p>Giám sát giao dịch và hoa hồng</p>
                </a>
                <a href="categories.php" class="action-card">
                    <div class="action-icon">📂</div>
                    <h3>Quản lý danh mục</h3>
                    <p>Tạo và chỉnh sửa danh mục sách</p>
                </a>
                <a href="settings.php" class="action-card">
                    <div class="action-icon">⚙️</div>
                    <h3>Cài đặt hệ thống</h3>
                    <p>Cấu hình và tùy chỉnh hệ thống</p>
                </a>
                </div>
            </div>

        <!-- Charts Section -->
        <div class="charts-section">
            <!-- Revenue Chart -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title">Doanh thu theo tháng</h3>
                    <div class="chart-controls">
                        <select id="revenuePeriod" class="form-select">
                            <option value="6">6 tháng gần đây</option>
                            <option value="12">12 tháng gần đây</option>
                            <option value="24">24 tháng gần đây</option>
                        </select>
                    </div>
                </div>
                <div class="chart-content">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>

            <!-- Orders Chart -->
            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title">Đơn hàng theo trạng thái</h3>
                    <div class="chart-controls">
                        <select id="ordersPeriod" class="form-select">
                            <option value="7">7 ngày gần đây</option>
                            <option value="30">30 ngày gần đây</option>
                            <option value="90">90 ngày gần đây</option>
                        </select>
                    </div>
                </div>
                <div class="chart-content">
                    <canvas id="ordersChart"></canvas>
                    </div>
                </div>
            </div>

        <!-- Recent Activity -->
        <div class="recent-activity">
            <div class="activity-header">
                <h2 class="section-title">Hoạt động gần đây</h2>
                <button class="btn btn-outline btn-sm" onclick="loadMoreActivity()">
                    Xem tất cả
                </button>
                    </div>
            <div class="activity-list" id="activityList">
                <!-- Activity items will be loaded here -->
                </div>
            </div>

        <!-- System Health -->
        <div class="system-health">
            <h2 class="section-title">Tình trạng hệ thống</h2>
            <div class="health-grid">
                <div class="health-card">
                    <div class="health-icon">🟢</div>
                    <div class="health-info">
                        <h4>Database</h4>
                        <p class="health-status">Hoạt động bình thường</p>
                        <div class="health-metrics">
                            <span>Response time: 45ms</span>
                            <span>Connections: 12/100</span>
                    </div>
                </div>
            </div>
                <div class="health-card">
                    <div class="health-icon">🟢</div>
                    <div class="health-info">
                        <h4>Redis Cache</h4>
                        <p class="health-status">Hoạt động bình thường</p>
                        <div class="health-metrics">
                            <span>Hit rate: 94.2%</span>
                            <span>Memory: 128MB/512MB</span>
        </div>
                    </div>
                    </div>
                <div class="health-card">
                    <div class="health-icon">🟡</div>
                    <div class="health-info">
                        <h4>API Server</h4>
                        <p class="health-status">Tải trung bình</p>
                        <div class="health-metrics">
                            <span>CPU: 65%</span>
                            <span>Memory: 256MB/512MB</span>
                        </div>
                    </div>
                    </div>
                <div class="health-card">
                    <div class="health-icon">🟢</div>
                    <div class="health-info">
                        <h4>Frontend</h4>
                        <p class="health-status">Hoạt động bình thường</p>
                        <div class="health-metrics">
                            <span>Uptime: 99.9%</span>
                            <span>Response: 120ms</span>
                    </div>
                    </div>
            </div>
                        </div>
                        </div>

        <!-- Pending Approvals -->
        <div class="pending-approvals">
            <h2 class="section-title">Chờ phê duyệt</h2>
            <div class="approvals-grid">
                <div class="approval-card">
                    <div class="approval-header">
                        <h4>Người bán mới</h4>
                        <span class="approval-count" id="pendingSellers">0</span>
                        </div>
                    <p>Đang chờ phê duyệt tài khoản người bán</p>
                    <a href="users.php?filter=pending_sellers" class="btn btn-outline btn-sm">
                        Xem chi tiết
                    </a>
                    </div>
                <div class="approval-card">
                    <div class="approval-header">
                        <h4>Sản phẩm mới</h4>
                        <span class="approval-count" id="pendingProducts">0</span>
                    </div>
                    <p>Đang chờ phê duyệt sản phẩm</p>
                    <a href="products.php?filter=pending" class="btn btn-outline btn-sm">
                        Xem chi tiết
                    </a>
                    </div>
                <div class="approval-card">
                    <div class="approval-header">
                        <h4>Đánh giá mới</h4>
                        <span class="approval-count" id="pendingReviews">0</span>
                    </div>
                    <p>Đang chờ kiểm duyệt đánh giá</p>
                    <a href="reviews.php?filter=pending" class="btn btn-outline btn-sm">
                        Xem chi tiết
                        </a>
                    </div>
            </div>
        </div>
    </div>
</main>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="loading-overlay" style="display: none;">
    <div class="loading-content">
        <div class="spinner"></div>
        <p>Đang tải dữ liệu...</p>
        </div>
        </div>

<!-- Toast Container -->
<div id="toastContainer" class="toast-container"></div>

<script>
// Dashboard initialization
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
});

// Initialize dashboard
async function initializeDashboard() {
    try {
        showLoading();
        
        // Load dashboard data in parallel
        await Promise.all([
            loadStats(),
            loadCharts(),
            loadRecentActivity(),
            loadPendingApprovals(),
            loadSystemHealth()
        ]);
        
        hideLoading();
        
        // Start auto-refresh for real-time updates (every 30 seconds)
        startAutoRefresh();
    } catch (error) {
        console.error('Dashboard initialization failed:', error);
        showToast('Không thể tải dashboard', 'error');
        hideLoading();
    }
}

// Auto-refresh real-time data
let refreshInterval = null;

function startAutoRefresh() {
    // Clear existing interval if any
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    
    // Refresh every 30 seconds
    refreshInterval = setInterval(async () => {
        try {
            // Refresh only real-time sections (not charts to avoid disruption)
            await Promise.all([
                refreshRecentActivity(),
                refreshPendingApprovals(),
                refreshSystemHealth(),
                refreshStats()
            ]);
            
            // Show subtle indicator that data was updated
            showUpdateIndicator();
        } catch (error) {
            console.error('Auto-refresh failed:', error);
        }
    }, 30000); // 30 seconds
}

function stopAutoRefresh() {
    if (refreshInterval) {
        clearInterval(refreshInterval);
        refreshInterval = null;
    }
}

function showUpdateIndicator() {
    const indicator = document.createElement('div');
    indicator.className = 'update-indicator';
    indicator.innerHTML = '🟢 Đã cập nhật';
    indicator.style.cssText = `
        position: fixed;
        top: 80px;
        right: 20px;
        background: #10b981;
        color: white;
        padding: 8px 16px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.3s ease;
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
    `;
    
    document.body.appendChild(indicator);
    
    setTimeout(() => indicator.style.opacity = '1', 100);
    
    setTimeout(() => {
        indicator.style.opacity = '0';
        setTimeout(() => indicator.remove(), 300);
    }, 2000);
}

// Refresh functions for real-time sections
async function refreshStats() {
    await loadStats();
}

async function refreshRecentActivity() {
    await loadRecentActivity();
}

async function refreshPendingApprovals() {
    await loadPendingApprovals();
}

async function refreshSystemHealth() {
    await loadSystemHealth();
}

// Stop auto-refresh when page is hidden
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        stopAutoRefresh();
    } else {
        startAutoRefresh();
    }
});

// Load statistics
async function loadStats() {
    try {
        const response = await adminAPI.getDashboardStats();
        if (response.success) {
            displayStats(response.data);
        }
    } catch (error) {
        console.error('Failed to load stats:', error);
        showStatsError();
    }
}

// Display statistics with smooth animation
function displayStats(data) {
    const statsGrid = document.getElementById('statsGrid');
    const stats = [
        {
            title: 'Tổng người dùng',
            value: data.totalUsers || 0,
            change: data.usersChange || 0,
            icon: '👥',
            color: 'blue',
            id: 'totalUsers'
        },
        {
            title: 'Người bán',
            value: data.totalSellers || 0,
            change: data.sellersChange || 0,
            icon: '🏪',
            color: 'green',
            id: 'totalSellers'
        },
        {
            title: 'Sản phẩm',
            value: data.totalProducts || 0,
            change: data.productsChange || 0,
            icon: '📚',
            color: 'purple',
            id: 'totalProducts'
        },
        {
            title: 'Đơn hàng',
            value: data.totalOrders || 0,
            change: data.ordersChange || 0,
            icon: '📦',
            color: 'orange',
            id: 'totalOrders'
        },
        {
            title: 'Doanh thu tháng',
            value: data.monthlyRevenue || 0,
            displayValue: formatCurrency(data.monthlyRevenue || 0),
            change: data.revenueChange || 0,
            icon: '💰',
            color: 'green',
            id: 'monthlyRevenue'
        },
        {
            title: 'Tỷ lệ chuyển đổi',
            value: data.conversionRate || 0,
            displayValue: (data.conversionRate || 0) + '%',
            change: data.conversionChange || 0,
            icon: '📈',
            color: 'blue',
            id: 'conversionRate'
        }
    ];

    // Check if this is an update (grid already has content)
    const isUpdate = statsGrid.children.length > 0;

    if (isUpdate) {
        // Update existing cards with animation
        stats.forEach(stat => {
            const card = document.querySelector(`[data-stat-id="${stat.id}"]`);
            if (card) {
                const valueEl = card.querySelector('.stat-value');
                const changeEl = card.querySelector('.stat-change');
                
                if (valueEl) {
                    // Animate value change
                    const oldValue = parseInt(valueEl.textContent.replace(/[^0-9]/g, '')) || 0;
                    const newValue = stat.value;
                    
                    if (oldValue !== newValue) {
                        valueEl.style.transform = 'scale(1.1)';
                        valueEl.style.color = '#10b981';
                        
                        animateNumber(valueEl, oldValue, newValue, 1000, stat.displayValue);
                        
                        setTimeout(() => {
                            valueEl.style.transform = 'scale(1)';
                            valueEl.style.color = '';
                        }, 1000);
                    }
                }
                
                if (changeEl) {
                    changeEl.className = `stat-change ${stat.change >= 0 ? 'positive' : 'negative'}`;
                    changeEl.innerHTML = `${stat.change >= 0 ? '↗' : '↘'} ${Math.abs(stat.change)}%`;
                }
            }
        });
    } else {
        // Initial render
        statsGrid.innerHTML = stats.map(stat => `
            <div class="stat-card stat-${stat.color}" data-stat-id="${stat.id}">
                <div class="stat-header">
                    <div class="stat-icon">${stat.icon}</div>
                    <div class="stat-change ${stat.change >= 0 ? 'positive' : 'negative'}">
                        ${stat.change >= 0 ? '↗' : '↘'} ${Math.abs(stat.change)}%
                    </div>
                </div>
                <div class="stat-value">${stat.displayValue || stat.value}</div>
                <div class="stat-title">${stat.title}</div>
            </div>
        `).join('');
    }
}

// Animate number changes
function animateNumber(element, start, end, duration, displayFormat) {
    const startTime = performance.now();
    const isRevenue = displayFormat && displayFormat.includes('₫');
    const isPercentage = displayFormat && displayFormat.includes('%');
    
    function update(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Ease out animation
        const easeProgress = 1 - Math.pow(1 - progress, 3);
        const current = Math.round(start + (end - start) * easeProgress);
        
        if (isRevenue) {
            element.textContent = formatCurrency(current);
        } else if (isPercentage) {
            element.textContent = current + '%';
        } else {
            element.textContent = current.toLocaleString('vi-VN');
        }
        
        if (progress < 1) {
            requestAnimationFrame(update);
        } else {
            if (displayFormat) {
                element.textContent = displayFormat;
            }
        }
    }
    
    requestAnimationFrame(update);
}

// Original display logic (keeping for backwards compatibility)
function displayStatsOriginal(data) {
    const statsGrid = document.getElementById('statsGrid');
    const stats = [
        {
            title: 'Tổng người dùng',
            value: data.totalUsers || 0,
            change: data.usersChange || 0,
            icon: '👥',
            color: 'blue'
        },
        {
            title: 'Người bán',
            value: data.totalSellers || 0,
            change: data.sellersChange || 0,
            icon: '🏪',
            color: 'green'
        },
        {
            title: 'Sản phẩm',
            value: data.totalProducts || 0,
            change: data.productsChange || 0,
            icon: '📚',
            color: 'purple'
        },
        {
            title: 'Đơn hàng',
            value: data.totalOrders || 0,
            change: data.ordersChange || 0,
            icon: '📦',
            color: 'orange'
        },
        {
            title: 'Doanh thu tháng',
            value: formatCurrency(data.monthlyRevenue || 0),
            change: data.revenueChange || 0,
            icon: '💰',
            color: 'green'
        },
        {
            title: 'Tỷ lệ chuyển đổi',
            value: (data.conversionRate || 0) + '%',
            change: data.conversionChange || 0,
            icon: '📈',
            color: 'blue'
        }
    ];

    statsGrid.innerHTML = stats.map(stat => `
        <div class="stat-card stat-${stat.color}">
            <div class="stat-header">
                <div class="stat-icon">${stat.icon}</div>
                <div class="stat-change ${stat.change >= 0 ? 'positive' : 'negative'}">
                    ${stat.change >= 0 ? '↗' : '↘'} ${Math.abs(stat.change)}%
                </div>
            </div>
            <div class="stat-content">
                <h3 class="stat-value">${stat.value}</h3>
                <p class="stat-title">${stat.title}</p>
</div>
        </div>
    `).join('');
}

// Load charts
async function loadCharts() {
    try {
        // Mock revenue chart data
        const revenueData = {
            labels: ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4', 'Tháng 5', 'Tháng 6'],
            values: [85000000, 92000000, 78000000, 105000000, 98000000, 125000000]
        };
        createRevenueChart(revenueData);

        // Mock orders chart data
        const ordersData = {
            labels: ['Đã giao', 'Đang xử lý', 'Đã hủy', 'Chờ thanh toán', 'Hoàn trả'],
            values: [456, 123, 45, 89, 23]
        };
        createOrdersChart(ordersData);
    } catch (error) {
        console.error('Failed to load charts:', error);
    }
}

// Create revenue chart
function createRevenueChart(data) {
    const ctx = document.getElementById('revenueChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: data.labels || [],
            datasets: [{
                label: 'Doanh thu (VNĐ)',
                data: data.values || [],
                borderColor: '#3B82F6',
                backgroundColor: 'rgba(59, 130, 246, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#ffffff',
                        font: {
                            size: 12,
                            weight: '600'
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: '#ffffff',
                        font: {
                            size: 12,
                            weight: '600'
                        },
                        callback: function(value) {
                            return formatCurrency(value);
                        }
                    },
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            }
        }
    });
}

// Create orders chart
function createOrdersChart(data) {
    const ctx = document.getElementById('ordersChart').getContext('2d');
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: data.labels || [],
            datasets: [{
                data: data.values || [],
                backgroundColor: [
                    '#3B82F6',
                    '#10B981',
                    '#F59E0B',
                    '#EF4444',
                    '#8B5CF6'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#ffffff',
                        font: {
                            size: 12,
                            weight: '600'
                        },
                        padding: 20,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                }
            }
        }
    });
}

// Load recent activity
async function loadRecentActivity() {
    try {
        // Mock activity data
        const activityData = [
            {
                type: 'user_register',
                description: 'Người dùng mới đăng ký: Nguyễn Văn A',
                createdAt: new Date(Date.now() - 5 * 60 * 1000)
            },
            {
                type: 'order_create',
                description: 'Đơn hàng mới #ORD-001 được tạo',
                createdAt: new Date(Date.now() - 15 * 60 * 1000)
            },
            {
                type: 'product_add',
                description: 'Sản phẩm "Harry Potter" được thêm bởi người bán',
                createdAt: new Date(Date.now() - 30 * 60 * 1000)
            },
            {
                type: 'seller_approve',
                description: 'Người bán "Cửa hàng ABC" được phê duyệt',
                createdAt: new Date(Date.now() - 45 * 60 * 1000)
            },
            {
                type: 'payment_received',
                description: 'Thanh toán 500,000 VNĐ được xử lý',
                createdAt: new Date(Date.now() - 60 * 60 * 1000)
            }
        ];
        
        displayRecentActivity(activityData);
    } catch (error) {
        console.error('Failed to load recent activity:', error);
    }
}

// Display recent activity
function displayRecentActivity(activities) {
    const activityList = document.getElementById('activityList');
    
    activityList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon">${getActivityIcon(activity.type)}</div>
            <div class="activity-content">
                <p class="activity-text">${activity.description}</p>
                <span class="activity-time">${formatTimeAgo(activity.createdAt)}</span>
        </div>
        </div>
    `).join('');
}

// Load pending approvals
async function loadPendingApprovals() {
    try {
        // Mock pending data
        const pendingData = {
            pendingSellers: 12,
            pendingProducts: 45,
            pendingReviews: 8
        };
        
        document.getElementById('pendingSellers').textContent = pendingData.pendingSellers;
        document.getElementById('pendingProducts').textContent = pendingData.pendingProducts;
        document.getElementById('pendingReviews').textContent = pendingData.pendingReviews;
    } catch (error) {
        console.error('Failed to load pending approvals:', error);
    }
}

// Load system health
async function loadSystemHealth() {
    try {
        const response = await adminAPI.getDashboardHealth();
        if (response.success) {
            updateSystemHealth(response.data);
        }
    } catch (error) {
        console.error('Failed to load system health:', error);
    }
}

// Update system health display
function updateSystemHealth(health) {
    // Update health cards with real data
    const healthCards = document.querySelectorAll('.health-card');
    healthCards.forEach((card, index) => {
        const service = ['database', 'redis', 'api', 'frontend'][index];
        if (health[service]) {
            const status = health[service].status;
            const icon = card.querySelector('.health-icon');
            const statusText = card.querySelector('.health-status');
            
            icon.textContent = status === 'healthy' ? '🟢' : status === 'warning' ? '🟡' : '🔴';
            statusText.textContent = health[service].message;
        }
    });
}

// Utility functions
function getActivityIcon(type) {
    const icons = {
        'user_register': '👤',
        'seller_approve': '✅',
        'product_add': '📚',
        'order_create': '📦',
        'payment_received': '💰',
        'review_add': '⭐'
    };
    return icons[type] || '📝';
}

function formatTimeAgo(date) {
    const now = new Date();
    const activityDate = new Date(date);
    const diffInSeconds = Math.floor((now - activityDate) / 1000);
    
    if (diffInSeconds < 60) return 'Vừa xong';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} phút trước`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} giờ trước`;
    return `${Math.floor(diffInSeconds / 86400)} ngày trước`;
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

function refreshDashboard() {
    initializeDashboard();
    showToast('Dashboard đã được làm mới', 'success');
}

function exportReport() {
    showToast('Tính năng xuất báo cáo đang được phát triển', 'info');
}

function loadMoreActivity() {
    window.location.href = 'activity.php';
}

function showLoading() {
    document.getElementById('loadingOverlay').style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loadingOverlay').style.display = 'none';
}

function showStatsError() {
    const statsGrid = document.getElementById('statsGrid');
    statsGrid.innerHTML = `
        <div class="error-state">
            <div class="error-icon">⚠️</div>
            <p>Không thể tải thống kê</p>
            <button class="btn btn-outline" onclick="loadStats()">Thử lại</button>
        </div>
    `;
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${getToastIcon(type)}</span>
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button>
    </div>
    `;
    
    document.getElementById('toastContainer').appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function getToastIcon(type) {
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    return icons[type] || icons.info;
}
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>