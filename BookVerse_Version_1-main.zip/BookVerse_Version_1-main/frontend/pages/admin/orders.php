<?php 
$pageTitle='Quản lý đơn hàng'; 
// $extraCss=['assets/css/admin.css']; 
// $extraJs=['assets/js/config.js', 'assets/js/admin.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<!-- Client-side auth check -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<style>
<?php include __DIR__ . '/../../assets/css/admin-improved.css'; ?>
</style>

<script>
<?php include __DIR__ . '/../../assets/js/config.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/admin.js'; ?>
</script>

<!-- Orders Management -->
<main class="admin-main">
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <h1 class="page-title">
                    <span class="title-icon">📦</span>
                    Quản lý đơn hàng
                </h1>
                <p class="page-subtitle">Theo dõi và quản lý tất cả đơn hàng trên hệ thống</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-outline" onclick="exportOrders()">
                    <span class="btn-icon">📊</span>
                    Xuất Excel
                </button>
                <button class="btn btn-primary" onclick="showBulkActions()">
                    <span class="btn-icon">⚡</span>
                    Thao tác hàng loạt
                </button>
            </div>
        </div>

        <!-- Order Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon pending">⏳</div>
                <div class="stat-content">
                    <div class="stat-value" id="pendingOrders">0</div>
                    <div class="stat-label">Chờ xử lý</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon processing">🔄</div>
                <div class="stat-content">
                    <div class="stat-value" id="processingOrders">0</div>
                    <div class="stat-label">Đang xử lý</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon shipped">🚚</div>
                <div class="stat-content">
                    <div class="stat-value" id="shippedOrders">0</div>
                    <div class="stat-label">Đã giao</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon completed">✅</div>
                <div class="stat-content">
                    <div class="stat-value" id="completedOrders">0</div>
                    <div class="stat-label">Hoàn thành</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon cancelled">❌</div>
                <div class="stat-content">
                    <div class="stat-value" id="cancelledOrders">0</div>
                    <div class="stat-label">Đã hủy</div>
                </div>
            </div>
        </div>

        <!-- Filters and Search -->
        <div class="filters-section">
            <div class="filters-grid">
                <div class="filter-group">
                    <label class="filter-label">Tìm kiếm</label>
                    <input type="text" id="searchInput" class="form-input" placeholder="Tìm theo mã đơn hàng, tên khách hàng...">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Trạng thái</label>
                    <select id="statusFilter" class="form-select">
                        <option value="">Tất cả trạng thái</option>
                        <option value="pending">Chờ xử lý</option>
                        <option value="processing">Đang xử lý</option>
                        <option value="shipped">Đã giao</option>
                        <option value="delivered">Đã nhận</option>
                        <option value="cancelled">Đã hủy</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Phương thức thanh toán</label>
                    <select id="paymentFilter" class="form-select">
                        <option value="">Tất cả phương thức</option>
                        <option value="cod">Thanh toán khi nhận hàng</option>
                        <option value="bank">Chuyển khoản</option>
                        <option value="momo">MoMo</option>
                        <option value="zalopay">ZaloPay</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Khoảng thời gian</label>
                    <select id="dateFilter" class="form-select">
                        <option value="">Tất cả thời gian</option>
                        <option value="today">Hôm nay</option>
                        <option value="week">Tuần này</option>
                        <option value="month">Tháng này</option>
                        <option value="quarter">Quý này</option>
                    </select>
                </div>
            </div>
            <div class="filters-actions">
                <button class="btn btn-outline" onclick="clearFilters()">
                    <span class="btn-icon">🔄</span>
                    Xóa bộ lọc
                </button>
                <button class="btn btn-primary" onclick="applyFilters()">
                    <span class="btn-icon">🔍</span>
                    Áp dụng bộ lọc
                </button>
            </div>
        </div>

        <!-- Orders Table -->
        <div class="table-section">
            <div class="table-header">
                <div class="table-info">
                    <span id="ordersCount">0 đơn hàng</span>
                    <span class="table-subtitle">Hiển thị 1-10 của 0</span>
                </div>
                <div class="table-actions">
                    <button class="btn btn-sm btn-outline" onclick="refreshOrders()">
                        <span class="btn-icon">🔄</span>
                        Làm mới
                    </button>
                </div>
            </div>

            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                            </th>
                            <th>Mã đơn hàng</th>
                            <th>Khách hàng</th>
                            <th>Sản phẩm</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody id="ordersTableBody">
                        <!-- Orders will be loaded here -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="pagination-section">
                <div class="pagination-info">
                    <span id="paginationInfo">Hiển thị 1-10 của 0 đơn hàng</span>
                </div>
                <div class="pagination-controls" id="paginationControls">
                    <!-- Pagination will be loaded here -->
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Order Detail Modal -->
<div id="orderDetailModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Chi tiết đơn hàng</h3>
            <button class="modal-close" onclick="closeOrderDetail()">&times;</button>
        </div>
        <div class="modal-body" id="orderDetailContent">
            <!-- Order details will be loaded here -->
        </div>
        <div class="modal-footer">
            <button class="btn btn-outline" onclick="closeOrderDetail()">Đóng</button>
            <button class="btn btn-primary" onclick="updateOrderStatus()">Cập nhật trạng thái</button>
        </div>
    </div>
</div>

<!-- Bulk Actions Modal -->
<div id="bulkActionsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Thao tác hàng loạt</h3>
            <button class="modal-close" onclick="closeBulkActions()">&times;</button>
        </div>
        <div class="modal-body">
            <div class="bulk-actions-grid">
                <button class="bulk-action-btn" onclick="bulkUpdateStatus('processing')">
                    <span class="action-icon">🔄</span>
                    <span class="action-text">Chuyển sang "Đang xử lý"</span>
                </button>
                <button class="bulk-action-btn" onclick="bulkUpdateStatus('shipped')">
                    <span class="action-icon">🚚</span>
                    <span class="action-text">Chuyển sang "Đã giao"</span>
                </button>
                <button class="bulk-action-btn" onclick="bulkUpdateStatus('delivered')">
                    <span class="action-icon">✅</span>
                    <span class="action-text">Chuyển sang "Hoàn thành"</span>
                </button>
                <button class="bulk-action-btn" onclick="bulkUpdateStatus('cancelled')">
                    <span class="action-icon">❌</span>
                    <span class="action-text">Hủy đơn hàng</span>
                </button>
            </div>
        </div>
    </div>
</div>

<style>
/* Orders Specific Styles */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 12px;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease;
}

.stat-card:hover {
    transform: translateY(-2px);
}

.stat-icon {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
}

.stat-icon.pending {
    background: linear-gradient(135deg, #fbbf24, #f59e0b);
}

.stat-icon.processing {
    background: linear-gradient(135deg, #3b82f6, #1d4ed8);
}

.stat-icon.shipped {
    background: linear-gradient(135deg, #8b5cf6, #7c3aed);
}

.stat-icon.completed {
    background: linear-gradient(135deg, #10b981, #059669);
}

.stat-icon.cancelled {
    background: linear-gradient(135deg, #ef4444, #dc2626);
}

.stat-content {
    flex: 1;
}

.stat-value {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 0.25rem;
}

.stat-label {
    font-size: 0.875rem;
    color: #6b7280;
    font-weight: 500;
}

.filters-actions {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
    justify-content: flex-end;
}

.table-section {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 16px;
    padding: 1.5rem;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
    backdrop-filter: blur(10px);
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #e5e7eb;
}

.table-info {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.table-subtitle {
    font-size: 0.875rem;
    color: #6b7280;
}

.table-container {
    overflow-x: auto;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
}

.data-table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

.data-table th {
    background: #f9fafb;
    padding: 1rem;
    text-align: left;
    font-weight: 600;
    color: #374151;
    border-bottom: 1px solid #e5e7eb;
}

.data-table td {
    padding: 1rem;
    border-bottom: 1px solid #f3f4f6;
    vertical-align: middle;
}

.data-table tr:hover {
    background: #f9fafb;
}

.order-number {
    font-weight: 600;
    color: #3b82f6;
    text-decoration: none;
}

.order-number:hover {
    text-decoration: underline;
}

.customer-info {
    display: flex;
    flex-direction: column;
    gap: 0.25rem;
}

.customer-name {
    font-weight: 500;
    color: #1f2937;
}

.customer-email {
    font-size: 0.875rem;
    color: #6b7280;
}

.products-preview {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.product-item {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.875rem;
}

.product-quantity {
    background: #e5e7eb;
    color: #374151;
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
}

.order-total {
    font-weight: 600;
    color: #059669;
}

.status-badge {
    padding: 0.375rem 0.75rem;
    border-radius: 6px;
    font-size: 0.75rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.status-pending {
    background: #fef3c7;
    color: #92400e;
}

.status-processing {
    background: #dbeafe;
    color: #1e40af;
}

.status-shipped {
    background: #e0e7ff;
    color: #5b21b6;
}

.status-delivered {
    background: #d1fae5;
    color: #065f46;
}

.status-cancelled {
    background: #fee2e2;
    color: #991b1b;
}

.action-buttons {
    display: flex;
    gap: 0.5rem;
}

.action-btn {
    padding: 0.375rem;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.875rem;
}

.action-btn.view {
    background: #dbeafe;
    color: #1e40af;
}

.action-btn.edit {
    background: #fef3c7;
    color: #92400e;
}

.action-btn.delete {
    background: #fee2e2;
    color: #991b1b;
}

.action-btn:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.pagination-section {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 1.5rem;
    padding-top: 1rem;
    border-top: 1px solid #e5e7eb;
}

.pagination-info {
    color: #6b7280;
    font-size: 0.875rem;
}

.pagination-controls {
    display: flex;
    gap: 0.5rem;
}

.pagination-btn {
    padding: 0.5rem 0.75rem;
    border: 1px solid #d1d5db;
    background: white;
    color: #374151;
    border-radius: 6px;
    cursor: pointer;
    transition: all 0.2s ease;
    font-size: 0.875rem;
}

.pagination-btn:hover:not(:disabled) {
    background: #f3f4f6;
    border-color: #9ca3af;
}

.pagination-btn.active {
    background: #3b82f6;
    color: white;
    border-color: #3b82f6;
}

.pagination-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.bulk-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.bulk-action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.75rem;
    padding: 1.5rem;
    border: 2px solid #e5e7eb;
    border-radius: 12px;
    background: white;
    cursor: pointer;
    transition: all 0.2s ease;
    text-align: center;
}

.bulk-action-btn:hover {
    border-color: #3b82f6;
    background: #f8fafc;
    transform: translateY(-2px);
}

.action-icon {
    font-size: 2rem;
}

.action-text {
    font-weight: 500;
    color: #374151;
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr;
    }
    
    .filters-grid {
        grid-template-columns: 1fr;
    }
    
    .table-header {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
    
    .pagination-section {
        flex-direction: column;
        gap: 1rem;
        align-items: flex-start;
    }
}
</style>
