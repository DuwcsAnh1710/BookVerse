<?php 
$pageTitle='Analytics Dashboard'; 
// $extraCss=['assets/css/admin.css', 'assets/css/analytics.css']; 
// $extraJs=['https://cdn.jsdelivr.net/npm/chart.js', 'assets/js/config.js', 'assets/js/admin.js', 'assets/js/analytics.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<!-- Client-side auth check -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<style>
<?php include __DIR__ . '/../../assets/css/admin-improved.css'; ?>
<?php include __DIR__ . '/../../assets/css/analytics.css'; ?>
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
<?php include __DIR__ . '/../../assets/js/config.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/admin.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/analytics.js'; ?>
</script>

<!-- Analytics Dashboard -->
<main class="admin-main">
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <h1 class="page-title">
                    <span class="title-icon">📊</span>
                    Analytics Dashboard
                </h1>
                <p class="page-subtitle">Phân tích dữ liệu và hiệu suất hệ thống</p>
            </div>
            <div class="header-actions">
                <select id="timeRange" class="form-select">
                    <option value="7d">7 ngày qua</option>
                    <option value="30d" selected>30 ngày qua</option>
                    <option value="90d">90 ngày qua</option>
                    <option value="1y">1 năm qua</option>
                </select>
                <button class="btn btn-outline" onclick="exportAnalytics()">
                    <span class="btn-icon">📈</span>
                    Xuất báo cáo
                </button>
            </div>
        </div>

        <!-- Key Metrics -->
        <div class="metrics-grid">
            <div class="metric-card">
                <div class="metric-header">
                    <h3 class="metric-title">Tổng doanh thu</h3>
                    <span class="metric-trend positive">+12.5%</span>
                </div>
                <div class="metric-value" id="totalRevenue">₫0</div>
                <div class="metric-subtitle">So với tháng trước</div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <h3 class="metric-title">Đơn hàng</h3>
                    <span class="metric-trend positive">+8.2%</span>
                </div>
                <div class="metric-value" id="totalOrders">0</div>
                <div class="metric-subtitle">Đơn hàng mới</div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <h3 class="metric-title">Người dùng</h3>
                    <span class="metric-trend positive">+15.3%</span>
                </div>
                <div class="metric-value" id="totalUsers">0</div>
                <div class="metric-subtitle">Người dùng mới</div>
            </div>

            <div class="metric-card">
                <div class="metric-header">
                    <h3 class="metric-title">Sản phẩm</h3>
                    <span class="metric-trend positive">+5.7%</span>
                </div>
                <div class="metric-value" id="totalProducts">0</div>
                <div class="metric-subtitle">Sản phẩm mới</div>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="charts-section">
            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title">Doanh thu theo thời gian</h3>
                    <div class="chart-controls">
                        <button class="chart-btn active" data-type="revenue">Doanh thu</button>
                        <button class="chart-btn" data-type="orders">Đơn hàng</button>
                        <button class="chart-btn" data-type="users">Người dùng</button>
                    </div>
                </div>
                <div class="chart-content">
                    <canvas id="revenueChart"></canvas>
                </div>
            </div>

            <div class="chart-container">
                <div class="chart-header">
                    <h3 class="chart-title">Phân bố đơn hàng theo trạng thái</h3>
                </div>
                <div class="chart-content">
                    <canvas id="ordersStatusChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Detailed Analytics -->
        <div class="analytics-grid">
            <!-- Top Products -->
            <div class="analytics-card">
                <div class="card-header">
                    <h3 class="card-title">Sản phẩm bán chạy</h3>
                    <button class="btn btn-sm btn-outline" onclick="viewAllProducts()">Xem tất cả</button>
                </div>
                <div class="card-content">
                    <div class="top-products-list" id="topProductsList">
                        <!-- Top products will be loaded here -->
                    </div>
                </div>
            </div>

            <!-- Top Sellers -->
            <div class="analytics-card">
                <div class="card-header">
                    <h3 class="card-title">Người bán hàng đầu</h3>
                    <button class="btn btn-sm btn-outline" onclick="viewAllSellers()">Xem tất cả</button>
                </div>
                <div class="card-content">
                    <div class="top-sellers-list" id="topSellersList">
                        <!-- Top sellers will be loaded here -->
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="analytics-card">
                <div class="card-header">
                    <h3 class="card-title">Hoạt động gần đây</h3>
                </div>
                <div class="card-content">
                    <div class="activity-list" id="recentActivityList">
                        <!-- Recent activity will be loaded here -->
                    </div>
                </div>
            </div>

            <!-- System Health -->
            <div class="analytics-card">
                <div class="card-header">
                    <h3 class="card-title">Tình trạng hệ thống</h3>
                </div>
                <div class="card-content">
                    <div class="health-metrics" id="systemHealth">
                        <!-- System health will be loaded here -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Geographic Analytics -->
        <div class="analytics-section">
            <div class="section-header">
                <h2 class="section-title">Phân tích địa lý</h2>
                <p class="section-subtitle">Dữ liệu đơn hàng theo khu vực</p>
            </div>
            <div class="geographic-grid">
                <div class="geo-card">
                    <h4 class="geo-title">Top thành phố</h4>
                    <div class="geo-list" id="topCitiesList">
                        <!-- Top cities will be loaded here -->
                    </div>
                </div>
                <div class="geo-card">
                    <h4 class="geo-title">Phân bố khu vực</h4>
                    <div class="geo-chart">
                        <canvas id="geographicChart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="loading-overlay">
    <div class="loading-content">
        <div class="spinner"></div>
        <p class="loading-text">Đang tải dữ liệu analytics...</p>
    </div>
</div>

<style>
/* Analytics Specific Styles */
.analytics-section {
    margin-top: 2rem;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 16px;
    padding: 2rem;
    backdrop-filter: blur(10px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.section-header {
    text-align: center;
    margin-bottom: 2rem;
}

.section-title {
    font-size: 1.5rem;
    font-weight: 700;
    color: #1f2937;
    margin-bottom: 0.5rem;
}

.section-subtitle {
    color: #6b7280;
    font-size: 0.875rem;
}

.analytics-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
    margin-top: 2rem;
}

.analytics-card {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
    transition: transform 0.2s ease;
}

.analytics-card:hover {
    transform: translateY(-2px);
}

.card-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 0.75rem;
    border-bottom: 1px solid #e5e7eb;
}

.card-title {
    font-size: 1.125rem;
    font-weight: 600;
    color: #1f2937;
}

.top-products-list,
.top-sellers-list,
.activity-list {
    space-y: 0.75rem;
}

.top-product-item,
.top-seller-item,
.activity-item {
    display: flex;
    align-items: center;
    padding: 0.75rem;
    background: rgba(255, 255, 255, 0.5);
    border-radius: 8px;
    margin-bottom: 0.5rem;
    transition: background 0.2s ease;
}

.top-product-item:hover,
.top-seller-item:hover,
.activity-item:hover {
    background: rgba(255, 255, 255, 0.8);
}

.item-rank {
    width: 24px;
    height: 24px;
    border-radius: 50%;
    background: #3b82f6;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.75rem;
    font-weight: 600;
    margin-right: 0.75rem;
}

.item-info {
    flex: 1;
}

.item-name {
    font-weight: 500;
    color: #1f2937;
    margin-bottom: 0.25rem;
}

.item-meta {
    font-size: 0.75rem;
    color: #6b7280;
}

.item-value {
    font-weight: 600;
    color: #059669;
}

.health-metrics {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 1rem;
}

.health-metric {
    text-align: center;
    padding: 1rem;
    background: rgba(255, 255, 255, 0.5);
    border-radius: 8px;
}

.health-status {
    width: 12px;
    height: 12px;
    border-radius: 50%;
    margin: 0 auto 0.5rem;
}

.health-status.healthy {
    background: #10b981;
}

.health-status.warning {
    background: #f59e0b;
}

.health-status.error {
    background: #ef4444;
}

.geographic-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
    margin-top: 1.5rem;
}

.geo-card {
    background: rgba(255, 255, 255, 0.9);
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.1);
}

.geo-title {
    font-size: 1.125rem;
    font-weight: 600;
    color: #1f2937;
    margin-bottom: 1rem;
}

.geo-list {
    space-y: 0.5rem;
}

.geo-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.5rem 0;
    border-bottom: 1px solid #f3f4f6;
}

.geo-item:last-child {
    border-bottom: none;
}

.geo-name {
    font-weight: 500;
    color: #1f2937;
}

.geo-value {
    font-weight: 600;
    color: #059669;
}

.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    display: none;
    align-items: center;
    justify-content: center;
    z-index: 10000;
}

.loading-content {
    background: white;
    padding: 2rem;
    border-radius: 12px;
    text-align: center;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
}

.loading-text {
    margin-top: 1rem;
    color: #6b7280;
    font-weight: 500;
}

@media (max-width: 768px) {
    .analytics-grid {
        grid-template-columns: 1fr;
    }
    
    .geographic-grid {
        grid-template-columns: 1fr;
    }
    
    .health-metrics {
        grid-template-columns: repeat(2, 1fr);
    }
}
</style>
