<?php 
$pageTitle='Quản lý thanh toán'; 
// $extraCss=['assets/css/admin.css']; 
// $extraJs=['assets/js/config.js', 'assets/js/api.js', 'assets/js/admin.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<!-- Client-side auth check -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<style>
<?php include __DIR__ . '/../../assets/css/admin-improved.css'; ?>
</style>

<script>
<?php include __DIR__ . '/../../assets/js/config.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/api.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/admin.js'; ?>
</script>

<!-- Payments Management -->
<main class="admin-main">
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <h1 class="page-title">
                    <span class="title-icon">💳</span>
                    Quản lý thanh toán
                </h1>
                <p class="page-subtitle">Theo dõi giao dịch và thanh toán</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-outline" onclick="exportPayments()">
                    <span class="btn-icon">📊</span>
                    Xuất báo cáo
                </button>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));">
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-content">
                    <h3 id="totalRevenue">0₫</h3>
                    <p>Tổng doanh thu</p>
                </div>
                <div class="stat-trend positive">
                    <span>↗️ +15%</span>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-content">
                    <h3 id="successPayments">0</h3>
                    <p>Thành công</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">⏳</div>
                <div class="stat-content">
                    <h3 id="pendingPayments">0</h3>
                    <p>Đang xử lý</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">❌</div>
                <div class="stat-content">
                    <h3 id="failedPayments">0</h3>
                    <p>Thất bại</p>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="filters-section">
            <div class="filters-grid">
                <div class="filter-group">
                    <label class="filter-label">Tìm kiếm</label>
                    <input type="text" id="searchQuery" class="form-input" placeholder="Mã GD, khách hàng, email..." onkeyup="loadPayments()">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Trạng thái</label>
                    <select id="statusFilter" class="form-select" onchange="loadPayments()">
                        <option value="">Tất cả trạng thái</option>
                        <option value="completed">✅ Thành công</option>
                        <option value="pending">⏳ Đang xử lý</option>
                        <option value="failed">❌ Thất bại</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Phương thức</label>
                    <select id="methodFilter" class="form-select" onchange="loadPayments()">
                        <option value="">Tất cả phương thức</option>
                        <option value="cod">💵 COD</option>
                        <option value="vnpay">💳 VNPay</option>
                        <option value="momo">📱 MoMo</option>
                        <option value="bank_transfer">🏦 Chuyển khoản</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Từ ngày</label>
                    <input type="date" id="fromDate" class="form-input" onchange="loadPayments()">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Đến ngày</label>
                    <input type="date" id="toDate" class="form-input" onchange="loadPayments()">
                </div>
                <div class="filter-actions">
                    <button class="btn btn-outline" onclick="clearFilters()">
                        <span class="btn-icon">🔄</span>
                        Xóa bộ lọc
                    </button>
                </div>
            </div>
        </div>

        <!-- Payments Table -->
        <div class="table-section">
            <div class="table-header">
                <div class="table-info">
                    <h3>Danh sách giao dịch</h3>
                    <span class="table-count" id="paymentCount">0 giao dịch</span>
                </div>
            </div>
            
            <div class="table-container">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Mã GD</th>
                            <th>Khách hàng</th>
                            <th>Số tiền</th>
                            <th>Phương thức</th>
                            <th>Trạng thái</th>
                            <th>Thời gian</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody id="paymentsTableBody">
                        <tr>
                            <td colspan="7" style="text-align: center; padding: 40px;">
                                <div style="font-size: 48px; margin-bottom: 16px;">💳</div>
                                <h3>Đang tải dữ liệu...</h3>
                                <p>Vui lòng chờ trong giây lát</p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        <div id="pagination" class="pagination"></div>
    </div>
</main>

<!-- Payment Detail Modal -->
<div id="paymentDetailModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Chi tiết thanh toán</h3>
            <button class="modal-close" onclick="closePaymentDetailModal()">&times;</button>
        </div>
        <div id="paymentDetails" class="modal-body">
            <!-- Details will be loaded here -->
        </div>
    </div>
</div>

<script>
// Payments management
let payments = [];
let currentPage = 1;
const pageSize = 20;

// Load payments
async function loadPayments() {
    try {
        const status = document.getElementById('statusFilter').value;
        const method = document.getElementById('methodFilter').value;
        const search = document.getElementById('searchQuery').value;
        
        // TODO: Call API with filters
        // Mock data for now
        payments = [];
        
        renderPaymentsTable();
        updateStats();
    } catch (error) {
        console.error('Error loading payments:', error);
    }
}

// Clear filters
function clearFilters() {
    document.getElementById('searchQuery').value = '';
    document.getElementById('statusFilter').value = '';
    document.getElementById('methodFilter').value = '';
    document.getElementById('fromDate').value = '';
    document.getElementById('toDate').value = '';
    loadPayments();
}

// Render table
function renderPaymentsTable() {
    const tbody = document.getElementById('paymentsTableBody');
    const countEl = document.getElementById('paymentCount');
    
    if (!payments || payments.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 40px;">
                    <div style="font-size: 48px; margin-bottom: 16px;">💳</div>
                    <h3>Chưa có giao dịch nào</h3>
                    <p>Không tìm thấy giao dịch phù hợp với bộ lọc</p>
                </td>
            </tr>
        `;
        if (countEl) countEl.textContent = '0 giao dịch';
        return;
    }
    
    if (countEl) countEl.textContent = `${payments.length} giao dịch`;
    
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;
    const pagePayments = payments.slice(start, end);
    
    tbody.innerHTML = pagePayments.map(payment => `
        <tr>
            <td><strong style="color: var(--primary-color);">#${payment.transactionId}</strong></td>
            <td>
                <div class="customer-info">
                    <div class="customer-name" style="font-weight: 500;">${payment.customerName}</div>
                    <div class="customer-email" style="color: var(--text-tertiary); font-size: 0.875rem;">${payment.customerEmail || ''}</div>
                </div>
            </td>
            <td><span class="price-value" style="font-weight: 600; color: var(--success-color);">${formatPrice(payment.amount)}</span></td>
            <td>${getMethodBadge(payment.method)}</td>
            <td>${getStatusBadge(payment.status)}</td>
            <td style="color: var(--text-tertiary); font-size: 0.9375rem;">${new Date(payment.createdAt).toLocaleString('vi-VN')}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="viewPaymentDetails('${payment._id}')" title="Xem chi tiết">
                    👁️
                </button>
            </td>
        </tr>
    `).join('');
}

// Update stats
function updateStats() {
    const total = payments.reduce((sum, p) => sum + (p.status === 'completed' ? p.amount : 0), 0);
    const success = payments.filter(p => p.status === 'completed').length;
    const pending = payments.filter(p => p.status === 'pending').length;
    const failed = payments.filter(p => p.status === 'failed').length;
    
    document.getElementById('totalRevenue').textContent = formatPrice(total);
    document.getElementById('successPayments').textContent = success;
    document.getElementById('pendingPayments').textContent = pending;
    document.getElementById('failedPayments').textContent = failed;
}

// Format price
function formatPrice(price) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
}

// Get method badge
function getMethodBadge(method) {
    const badges = {
        'cod': '<span class="status-badge" style="background: #fef3c7; color: #d97706; font-weight: 600;">💵 COD</span>',
        'vnpay': '<span class="status-badge" style="background: #dbeafe; color: #2563eb; font-weight: 600;">💳 VNPay</span>',
        'momo': '<span class="status-badge" style="background: #fce7f3; color: #db2777; font-weight: 600;">📱 MoMo</span>',
        'bank_transfer': '<span class="status-badge" style="background: #d1fae5; color: #059669; font-weight: 600;">🏦 Chuyển khoản</span>'
    };
    return badges[method] || `<span class="status-badge">${method}</span>`;
}

// Get status badge
function getStatusBadge(status) {
    const badges = {
        'completed': '<span class="status-badge status-approved" style="background: #d1fae5; color: #059669; font-weight: 600;">✅ Thành công</span>',
        'pending': '<span class="status-badge status-pending" style="background: #fef3c7; color: #d97706; font-weight: 600;">⏳ Đang xử lý</span>',
        'failed': '<span class="status-badge status-rejected" style="background: #fee2e2; color: #dc2626; font-weight: 600;">❌ Thất bại</span>'
    };
    return badges[status] || `<span class="status-badge">${status}</span>`;
}

// View payment details
function viewPaymentDetails(id) {
    const payment = payments.find(p => p._id === id);
    if (!payment) return;
    
    document.getElementById('paymentDetails').innerHTML = `
        <div class="detail-row">
            <strong>Mã giao dịch:</strong>
            <span>${payment.transactionId}</span>
        </div>
        <div class="detail-row">
            <strong>Khách hàng:</strong>
            <span>${payment.customerName}</span>
        </div>
        <div class="detail-row">
            <strong>Số tiền:</strong>
            <span>${formatPrice(payment.amount)}</span>
        </div>
        <div class="detail-row">
            <strong>Phương thức:</strong>
            <span>${payment.method}</span>
        </div>
        <div class="detail-row">
            <strong>Trạng thái:</strong>
            ${getStatusBadge(payment.status)}
        </div>
    `;
    
    document.getElementById('paymentDetailModal').style.display = 'flex';
}

// Close modal
function closePaymentDetailModal() {
    document.getElementById('paymentDetailModal').style.display = 'none';
}

// Export payments
function exportPayments() {
    alert('Tính năng xuất báo cáo đang phát triển');
}

// Auto-refresh every 30 seconds
setInterval(loadPayments, 30000);

// Initial load
document.addEventListener('DOMContentLoaded', loadPayments);
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>

