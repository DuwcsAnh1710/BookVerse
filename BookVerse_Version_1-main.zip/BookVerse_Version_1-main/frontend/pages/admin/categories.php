<?php 
$pageTitle='Quản lý danh mục'; 
// $extraCss=['assets/css/admin.css']; 
// $extraJs=['assets/js/config.js', 'assets/js/api.js', 'assets/js/admin.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<!-- Client-side auth check -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<style>
<?php include __DIR__ . '/../../assets/css/admin-improved.css'; ?>
</style>

<script>
<?php include __DIR__ . '/../../assets/js/config.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/api.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/admin.js'; ?>
</script>

<!-- Categories Management -->
<main class="admin-main">
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <h1 class="page-title">
                    <span class="title-icon">📂</span>
                    Quản lý danh mục
                </h1>
                <p class="page-subtitle">Quản lý danh mục sản phẩm</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-primary" onclick="showAddCategoryModal()">
                    <span class="btn-icon">➕</span>
                    Thêm danh mục
                </button>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">📂</div>
                <div class="stat-content">
                    <h3 id="totalCategories">0</h3>
                    <p>Tổng danh mục</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">✅</div>
                <div class="stat-content">
                    <h3 id="activeCategories">0</h3>
                    <p>Đang hoạt động</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📦</div>
                <div class="stat-content">
                    <h3 id="totalProducts">0</h3>
                    <p>Tổng sản phẩm</p>
                </div>
            </div>
        </div>

        <!-- Categories Table -->
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Tên danh mục</th>
                        <th>Slug</th>
                        <th>Số sản phẩm</th>
                        <th>Trạng thái</th>
                        <th>Ngày tạo</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody id="categoriesTableBody">
                    <tr>
                        <td colspan="6" class="text-center">
                            <div class="loading">Đang tải dữ liệu...</div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</main>

<!-- Add/Edit Category Modal -->
<div id="categoryModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Thêm danh mục mới</h3>
            <button class="modal-close" onclick="closeCategoryModal()">&times;</button>
        </div>
        <form id="categoryForm" class="modal-body">
            <input type="hidden" id="categoryId">
            <div class="form-group">
                <label for="categoryName">Tên danh mục *</label>
                <input type="text" id="categoryName" required>
            </div>
            <div class="form-group">
                <label for="categorySlug">Slug</label>
                <input type="text" id="categorySlug">
            </div>
            <div class="form-group">
                <label for="categoryDescription">Mô tả</label>
                <textarea id="categoryDescription" rows="3"></textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" onclick="closeCategoryModal()">Hủy</button>
                <button type="submit" class="btn btn-primary">Lưu</button>
            </div>
        </form>
    </div>
</div>

<script>
// Category management
let categories = [];

// Load categories
async function loadCategories() {
    try {
        const response = await api.getCategories();
        if (response.success) {
            categories = response.data;
            renderCategoriesTable();
            updateStats();
        }
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// Render table
function renderCategoriesTable() {
    const tbody = document.getElementById('categoriesTableBody');
    if (!categories || categories.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">Chưa có danh mục nào</td></tr>';
        return;
    }
    
    tbody.innerHTML = categories.map(cat => `
        <tr>
            <td>${cat.name}</td>
            <td>${cat.slug || '-'}</td>
            <td>${cat.productCount || 0}</td>
            <td><span class="badge badge-success">Hoạt động</span></td>
            <td>${new Date(cat.createdAt).toLocaleDateString('vi-VN')}</td>
            <td>
                <button class="btn btn-sm btn-outline" onclick="editCategory('${cat._id}')">Sửa</button>
                <button class="btn btn-sm btn-danger" onclick="deleteCategory('${cat._id}')">Xóa</button>
            </td>
        </tr>
    `).join('');
}

// Update stats
function updateStats() {
    document.getElementById('totalCategories').textContent = categories.length;
    document.getElementById('activeCategories').textContent = categories.length;
    const totalProducts = categories.reduce((sum, cat) => sum + (cat.productCount || 0), 0);
    document.getElementById('totalProducts').textContent = totalProducts;
}

// Show add modal
function showAddCategoryModal() {
    document.getElementById('modalTitle').textContent = 'Thêm danh mục mới';
    document.getElementById('categoryForm').reset();
    document.getElementById('categoryId').value = '';
    document.getElementById('categoryModal').style.display = 'flex';
}

// Close modal
function closeCategoryModal() {
    document.getElementById('categoryModal').style.display = 'none';
}

// Edit category
function editCategory(id) {
    const cat = categories.find(c => c._id === id);
    if (!cat) return;
    
    document.getElementById('modalTitle').textContent = 'Sửa danh mục';
    document.getElementById('categoryId').value = cat._id;
    document.getElementById('categoryName').value = cat.name;
    document.getElementById('categorySlug').value = cat.slug || '';
    document.getElementById('categoryDescription').value = cat.description || '';
    document.getElementById('categoryModal').style.display = 'flex';
}

// Delete category
async function deleteCategory(id) {
    if (!confirm('Bạn có chắc muốn xóa danh mục này?')) return;
    
    try {
        // TODO: Call delete API
        alert('Tính năng đang phát triển');
        loadCategories();
    } catch (error) {
        console.error('Error deleting category:', error);
    }
}

// Handle form submit
document.getElementById('categoryForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const id = document.getElementById('categoryId').value;
    const data = {
        name: document.getElementById('categoryName').value,
        slug: document.getElementById('categorySlug').value,
        description: document.getElementById('categoryDescription').value
    };
    
    try {
        // TODO: Call create/update API
        alert(id ? 'Cập nhật thành công!' : 'Thêm mới thành công!');
        closeCategoryModal();
        loadCategories();
    } catch (error) {
        console.error('Error saving category:', error);
    }
});

// Auto-refresh every 30 seconds
setInterval(loadCategories, 30000);

// Initial load
document.addEventListener('DOMContentLoaded', loadCategories);
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>

