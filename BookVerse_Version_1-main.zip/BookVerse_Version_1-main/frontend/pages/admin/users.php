<?php 
$pageTitle='Quản lý người dùng'; 
// $extraCss=['assets/css/admin.css']; 
// $extraJs=['assets/js/admin.js'];
include '../../includes/header.php'; 
?>

<!-- Client-side auth check -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<style>
<?php include __DIR__ . '/../../assets/css/admin-improved.css'; ?>
</style>

<script>
<?php include __DIR__ . '/../../assets/js/config.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/api.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/admin.js'; ?>
</script>

<!-- Users Management -->
<main class="admin-main">
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <h1 class="page-title">
                    <span class="title-icon">👥</span>
                    Quản lý người dùng
                </h1>
                <p class="page-subtitle">Quản lý tài khoản người dùng và người bán</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-outline" onclick="exportUsers()">
                    <span class="btn-icon">📊</span>
                    Xuất Excel
                </button>
                <button class="btn btn-primary" onclick="showAddUserModal()">
                    <span class="btn-icon">➕</span>
                    Thêm người dùng
                </button>
            </div>
        </div>

        <!-- Filters and Search -->
        <div class="filters-section">
            <div class="filters-grid">
                <div class="filter-group">
                    <label class="filter-label">Tìm kiếm</label>
                    <input type="text" id="searchInput" class="form-input" placeholder="Tìm theo tên, email, username...">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Vai trò</label>
                    <select id="roleFilter" class="form-select">
                        <option value="">Tất cả vai trò</option>
                        <option value="user">Người dùng</option>
                        <option value="seller">Người bán</option>
                        <option value="admin">Quản trị viên</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Trạng thái</label>
                    <select id="statusFilter" class="form-select">
                        <option value="">Tất cả trạng thái</option>
                        <option value="active">Hoạt động</option>
                        <option value="inactive">Không hoạt động</option>
                        <option value="pending">Chờ phê duyệt</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Ngày đăng ký</label>
                    <input type="date" id="dateFrom" class="form-input">
                    <input type="date" id="dateTo" class="form-input">
                </div>
                <div class="filter-actions">
                    <button class="btn btn-primary" onclick="applyFilters()">
                        <span class="btn-icon">🔍</span>
                        Lọc
                    </button>
                    <button class="btn btn-outline" onclick="clearFilters()">
                        <span class="btn-icon">🔄</span>
                        Xóa bộ lọc
                    </button>
                </div>
            </div>
        </div>

        <!-- Users Table -->
        <div class="table-section">
            <div class="table-header">
                <div class="table-info">
                    <h3>Danh sách người dùng</h3>
                    <span class="table-count" id="userCount">0 người dùng</span>
                </div>
                <div class="table-actions">
                    <div class="bulk-actions">
                        <select id="bulkAction" class="form-select">
                            <option value="">Thao tác hàng loạt</option>
                            <option value="activate">Kích hoạt</option>
                            <option value="deactivate">Vô hiệu hóa</option>
                            <option value="delete">Xóa</option>
                        </select>
                        <button class="btn btn-outline" onclick="applyBulkAction()">
                            Áp dụng
                        </button>
                    </div>
                </div>
            </div>

            <div class="table-container">
                <table class="admin-table" id="usersTable">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                            </th>
                            <th>Người dùng</th>
                            <th>Vai trò</th>
                            <th>Trạng thái</th>
                            <th>Ngày đăng ký</th>
                            <th>Hoạt động cuối</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody id="usersTableBody">
                        <!-- Users will be loaded here -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="pagination" id="pagination">
                <!-- Pagination will be loaded here -->
            </div>
        </div>
    </div>
</main>

<!-- Add User Modal -->
<div id="addUserModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Thêm người dùng mới</h3>
            <button class="modal-close" onclick="closeAddUserModal()">&times;</button>
        </div>
        <form id="addUserForm" class="modal-body">
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Tên đăng nhập *</label>
                    <input type="text" name="username" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-input" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Họ *</label>
                    <input type="text" name="firstName" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Tên *</label>
                    <input type="text" name="lastName" class="form-input" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Mật khẩu *</label>
                    <input type="password" name="password" class="form-input" required>
                </div>
                <div class="form-group">
                    <label class="form-label">Vai trò *</label>
                    <select name="role" class="form-select" required>
                        <option value="user">Người dùng</option>
                        <option value="seller">Người bán</option>
                        <option value="admin">Quản trị viên</option>
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label">Số điện thoại</label>
                <input type="tel" name="phone" class="form-input">
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-outline" onclick="closeAddUserModal()">
                    Hủy
                </button>
                <button type="submit" class="btn btn-primary">
                    <span class="btn-text">Thêm người dùng</span>
                    <span class="btn-loading" style="display: none;">⏳</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- User Detail Modal -->
<div id="userDetailModal" class="modal" style="display: none;">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h3>Chi tiết người dùng</h3>
            <button class="modal-close" onclick="closeUserDetailModal()">&times;</button>
        </div>
        <div class="modal-body" id="userDetailContent">
            <!-- User details will be loaded here -->
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="loading-overlay" style="display: none;">
    <div class="loading-content">
        <div class="spinner"></div>
        <p>Đang tải dữ liệu...</p>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer" class="toast-container"></div>

<script>
// Users management variables
let currentPage = 1;
let currentFilters = {};
let selectedUsers = new Set();

// Initialize users management
document.addEventListener('DOMContentLoaded', function() {
    initializeUsersManagement();
});

// Initialize users management
async function initializeUsersManagement() {
    try {
        showLoading();
        await loadUsers();
        setupEventListeners();
        hideLoading();
    } catch (error) {
        console.error('Users management initialization failed:', error);
        showToast('Không thể tải danh sách người dùng', 'error');
        hideLoading();
    }
}

// Setup event listeners
function setupEventListeners() {
    // Search input
    const searchInput = document.getElementById('searchInput');
    let searchTimeout;
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            applyFilters();
        }, 500);
    });

    // Filter changes
    document.getElementById('roleFilter').addEventListener('change', applyFilters);
    document.getElementById('statusFilter').addEventListener('change', applyFilters);
    document.getElementById('dateFrom').addEventListener('change', applyFilters);
    document.getElementById('dateTo').addEventListener('change', applyFilters);

    // Add user form
    document.getElementById('addUserForm').addEventListener('submit', handleAddUser);
}

// Load users
async function loadUsers() {
    try {
        const params = {
            page: currentPage,
            limit: 20,
            ...currentFilters
        };

        const response = await adminAPI.getUsers(params);
        if (response.success) {
            displayUsers(response.data.users);
            updatePagination(response.data.pagination);
            updateUserCount(response.data.pagination.total);
        }
    } catch (error) {
        console.error('Failed to load users:', error);
        showUsersError();
    }
}

// Display users
function displayUsers(users) {
    const tbody = document.getElementById('usersTableBody');
    
    tbody.innerHTML = users.map(user => `
        <tr data-user-id="${user._id}">
            <td>
                <input type="checkbox" class="user-checkbox" value="${user._id}" 
                       onchange="toggleUserSelection('${user._id}')">
            </td>
            <td>
                <div class="user-info">
                    <div class="user-avatar">
                        <img src="${user.profile?.avatar || '../../assets/images/default-avatar.svg'}" 
                             alt="${user.username}" 
                             onerror="this.src='../../assets/images/default-avatar.svg'">
                    </div>
                    <div class="user-details">
                        <h4 class="user-name">${user.profile?.firstName || ''} ${user.profile?.lastName || ''}</h4>
                        <p class="user-username">@${user.username}</p>
                        <p class="user-email">${user.email}</p>
                    </div>
                </div>
            </td>
            <td>
                <span class="role-badge role-${user.role}">
                    ${getRoleLabel(user.role)}
                </span>
            </td>
            <td>
                <span class="status-badge status-${user.isActive ? 'active' : 'inactive'}">
                    ${user.isActive ? 'Hoạt động' : 'Không hoạt động'}
                </span>
                ${user.sellerProfile?.isApproved === false ? '<span class="status-badge status-pending">Chờ phê duyệt</span>' : ''}
            </td>
            <td>${formatDate(user.createdAt)}</td>
            <td>${user.lastLogin ? formatTimeAgo(user.lastLogin) : 'Chưa đăng nhập'}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-sm btn-outline" onclick="viewUserDetail('${user._id}')" title="Xem chi tiết">
                        👁️
                    </button>
                    ${user.role === 'seller' && user.sellerProfile?.isApproved === false ? `
                        <button class="btn btn-sm btn-success" onclick="approveSeller('${user._id}')" title="Phê duyệt seller">
                            ✅
                        </button>
                    ` : ''}
                    <button class="btn btn-sm btn-outline" onclick="editUser('${user._id}')" title="Chỉnh sửa">
                        ✏️
                    </button>
                    <button class="btn btn-sm ${user.isActive ? 'btn-warning' : 'btn-success'}" 
                            onclick="toggleUserStatus('${user._id}', ${user.isActive})" 
                            title="${user.isActive ? 'Vô hiệu hóa' : 'Kích hoạt'}">
                        ${user.isActive ? '⏸️' : '▶️'}
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteUser('${user._id}')" title="Xóa">
                        🗑️
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Apply filters
function applyFilters() {
    currentFilters = {
        search: document.getElementById('searchInput').value,
        role: document.getElementById('roleFilter').value,
        status: document.getElementById('statusFilter').value,
        dateFrom: document.getElementById('dateFrom').value,
        dateTo: document.getElementById('dateTo').value
    };

    // Remove empty filters
    Object.keys(currentFilters).forEach(key => {
        if (!currentFilters[key]) {
            delete currentFilters[key];
        }
    });

    currentPage = 1;
    loadUsers();
}

// Clear filters
function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('roleFilter').value = '';
    document.getElementById('statusFilter').value = '';
    document.getElementById('dateFrom').value = '';
    document.getElementById('dateTo').value = '';
    
    currentFilters = {};
    currentPage = 1;
    loadUsers();
}

// Toggle select all
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.user-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        if (selectAll.checked) {
            selectedUsers.add(checkbox.value);
        } else {
            selectedUsers.delete(checkbox.value);
        }
    });
}

// Toggle user selection
function toggleUserSelection(userId) {
    const checkbox = document.querySelector(`input[value="${userId}"]`);
    if (checkbox.checked) {
        selectedUsers.add(userId);
    } else {
        selectedUsers.delete(userId);
    }
    
    // Update select all checkbox
    const totalCheckboxes = document.querySelectorAll('.user-checkbox').length;
    const checkedCheckboxes = document.querySelectorAll('.user-checkbox:checked').length;
    document.getElementById('selectAll').checked = totalCheckboxes === checkedCheckboxes;
}

// View user detail
async function viewUserDetail(userId) {
    try {
        showLoading();
        const response = await adminAPI.getUser(userId);
        if (response.success) {
            displayUserDetail(response.data.user);
            document.getElementById('userDetailModal').style.display = 'flex';
        }
    } catch (error) {
        console.error('Failed to load user detail:', error);
        showToast('Không thể tải chi tiết người dùng', 'error');
    } finally {
        hideLoading();
    }
}

// Display user detail
function displayUserDetail(user) {
    const content = document.getElementById('userDetailContent');
    content.innerHTML = `
        <div class="user-detail-grid">
            <div class="detail-section">
                <h4>Thông tin cơ bản</h4>
                <div class="detail-info">
                    <div class="info-row">
                        <span class="info-label">Tên đăng nhập:</span>
                        <span class="info-value">${user.username}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Email:</span>
                        <span class="info-value">${user.email}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Họ tên:</span>
                        <span class="info-value">${user.profile?.firstName || ''} ${user.profile?.lastName || ''}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Số điện thoại:</span>
                        <span class="info-value">${user.profile?.phone || 'Chưa cập nhật'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Vai trò:</span>
                        <span class="role-badge role-${user.role}">${getRoleLabel(user.role)}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Trạng thái:</span>
                        <span class="status-badge status-${user.isActive ? 'active' : 'inactive'}">
                            ${user.isActive ? 'Hoạt động' : 'Không hoạt động'}
                        </span>
                    </div>
                </div>
            </div>
            
            ${user.sellerProfile ? `
            <div class="detail-section">
                <h4>Thông tin người bán</h4>
                <div class="detail-info">
                    <div class="info-row">
                        <span class="info-label">Tên doanh nghiệp:</span>
                        <span class="info-value">${user.sellerProfile.businessName || 'Chưa cập nhật'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Loại hình:</span>
                        <span class="info-value">${user.sellerProfile.businessType === 'individual' ? 'Cá nhân' : 'Doanh nghiệp'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Trạng thái phê duyệt:</span>
                        <span class="status-badge status-${user.sellerProfile.isApproved ? 'active' : 'pending'}">
                            ${user.sellerProfile.isApproved ? 'Đã phê duyệt' : 'Chờ phê duyệt'}
                        </span>
                    </div>
                    ${!user.sellerProfile.isApproved ? `
                    <div class="info-row">
                        <button class="btn btn-success" onclick="approveSeller('${user._id}'); closeUserDetailModal();">
                            ✅ Phê duyệt seller
                        </button>
                    </div>
                    ` : ''}
                    <div class="info-row">
                        <span class="info-label">Mô tả:</span>
                        <span class="info-value">${user.sellerProfile.description || 'Chưa cập nhật'}</span>
                    </div>
                </div>
            </div>
            ` : ''}
            
            <div class="detail-section">
                <h4>Thống kê hoạt động</h4>
                <div class="detail-info">
                    <div class="info-row">
                        <span class="info-label">Ngày đăng ký:</span>
                        <span class="info-value">${formatDate(user.createdAt)}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Đăng nhập cuối:</span>
                        <span class="info-value">${user.lastLogin ? formatTimeAgo(user.lastLogin) : 'Chưa đăng nhập'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Xác thực email:</span>
                        <span class="status-badge status-${user.isEmailVerified ? 'active' : 'inactive'}">
                            ${user.isEmailVerified ? 'Đã xác thực' : 'Chưa xác thực'}
                        </span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Edit user
function editUser(userId) {
    // Implement edit user functionality
    showToast('Tính năng chỉnh sửa đang được phát triển', 'info');
}

// Toggle user status
async function toggleUserStatus(userId, currentStatus) {
    try {
        const response = currentStatus 
            ? await adminAPI.deactivateUser(userId)
            : await adminAPI.activateUser(userId);
        
        if (response.success) {
            showToast(`Đã ${currentStatus ? 'vô hiệu hóa' : 'kích hoạt'} người dùng`, 'success');
            loadUsers();
        }
    } catch (error) {
        console.error('Failed to toggle user status:', error);
        showToast('Không thể thay đổi trạng thái người dùng', 'error');
    }
}

// Delete user
async function deleteUser(userId) {
    if (!confirm('Bạn có chắc chắn muốn xóa người dùng này?')) {
        return;
    }
    
    try {
        const response = await adminAPI.deleteUser(userId);
        
        if (response.success) {
            showToast('Đã xóa người dùng', 'success');
            loadUsers();
        }
    } catch (error) {
        console.error('Failed to delete user:', error);
        showToast('Không thể xóa người dùng', 'error');
    }
}

// Approve seller
async function approveSeller(userId) {
    if (!confirm('Bạn có chắc chắn muốn phê duyệt seller này?')) {
        return;
    }
    
    try {
        const response = await adminAPI.approveSeller(userId, true);
        
        if (response.success) {
            showToast('Đã phê duyệt seller thành công', 'success');
            loadUsers();
        }
    } catch (error) {
        console.error('Failed to approve seller:', error);
        showToast('Không thể phê duyệt seller', 'error');
    }
}

// Show add user modal
function showAddUserModal() {
    document.getElementById('addUserModal').style.display = 'flex';
}

// Close add user modal
function closeAddUserModal() {
    document.getElementById('addUserModal').style.display = 'none';
    document.getElementById('addUserForm').reset();
}

// Close user detail modal
function closeUserDetailModal() {
    document.getElementById('userDetailModal').style.display = 'none';
}

// Handle add user
async function handleAddUser(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const userData = Object.fromEntries(formData.entries());
    
    const submitBtn = form.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoading = submitBtn.querySelector('.btn-loading');
    
    try {
        btnText.style.display = 'none';
        btnLoading.style.display = 'inline';
        submitBtn.disabled = true;
        
        const response = await adminAPI.createUser(userData);
        
        if (response.success) {
            showToast('Đã thêm người dùng thành công', 'success');
            closeAddUserModal();
            loadUsers();
        }
    } catch (error) {
        console.error('Failed to add user:', error);
        showToast('Không thể thêm người dùng', 'error');
    } finally {
        btnText.style.display = 'inline';
        btnLoading.style.display = 'none';
        submitBtn.disabled = false;
    }
}

// Apply bulk action
async function applyBulkAction() {
    const action = document.getElementById('bulkAction').value;
    if (!action || selectedUsers.size === 0) {
        showToast('Vui lòng chọn thao tác và người dùng', 'warning');
        return;
    }
    
    if (!confirm(`Bạn có chắc chắn muốn ${action} ${selectedUsers.size} người dùng?`)) {
        return;
    }
    
    try {
        const response = await adminAPI.bulkUserAction(action, Array.from(selectedUsers));
        
        if (response.success) {
            showToast(`Đã ${action} ${selectedUsers.size} người dùng`, 'success');
            selectedUsers.clear();
            document.getElementById('selectAll').checked = false;
            loadUsers();
        }
    } catch (error) {
        console.error('Failed to apply bulk action:', error);
        showToast('Không thể thực hiện thao tác hàng loạt', 'error');
    }
}

// Export users
function exportUsers() {
    showToast('Tính năng xuất Excel đang được phát triển', 'info');
}

// Update pagination
function updatePagination(pagination) {
    const paginationContainer = document.getElementById('pagination');
    
    if (pagination.pages <= 1) {
        paginationContainer.innerHTML = '';
        return;
    }
    
    let paginationHTML = '<div class="pagination-content">';
    
    // Previous button
    if (pagination.page > 1) {
        paginationHTML += `<button class="pagination-btn" onclick="changePage(${pagination.page - 1})">‹</button>`;
    }
    
    // Page numbers
    const startPage = Math.max(1, pagination.page - 2);
    const endPage = Math.min(pagination.pages, pagination.page + 2);
    
    for (let i = startPage; i <= endPage; i++) {
        paginationHTML += `<button class="pagination-btn ${i === pagination.page ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
    }
    
    // Next button
    if (pagination.page < pagination.pages) {
        paginationHTML += `<button class="pagination-btn" onclick="changePage(${pagination.page + 1})">›</button>`;
    }
    
    paginationHTML += '</div>';
    paginationContainer.innerHTML = paginationHTML;
}

// Change page
function changePage(page) {
    currentPage = page;
    loadUsers();
}

// Update user count
function updateUserCount(total) {
    document.getElementById('userCount').textContent = `${total} người dùng`;
}

// Show users error
function showUsersError() {
    const tbody = document.getElementById('usersTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="7" class="error-state">
                <div class="error-icon">⚠️</div>
                <p>Không thể tải danh sách người dùng</p>
                <button class="btn btn-outline" onclick="loadUsers()">Thử lại</button>
            </td>
        </tr>
    `;
}

// Utility functions
function getRoleLabel(role) {
    const labels = {
        'user': 'Người dùng',
        'seller': 'Người bán',
        'admin': 'Quản trị viên'
    };
    return labels[role] || role;
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('vi-VN');
}

function formatTimeAgo(date) {
    const now = new Date();
    const activityDate = new Date(date);
    const diffInSeconds = Math.floor((now - activityDate) / 1000);
    
    if (diffInSeconds < 60) return 'Vừa xong';
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} phút trước`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} giờ trước`;
    return `${Math.floor(diffInSeconds / 86400)} ngày trước`;
}

function showLoading() {
    document.getElementById('loadingOverlay').style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loadingOverlay').style.display = 'none';
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${getToastIcon(type)}</span>
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    document.getElementById('toastContainer').appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function getToastIcon(type) {
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    return icons[type] || icons.info;
}
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>
