<?php 
$pageTitle='Admin Login'; 
$extraCss=['../../assets/css/main.css', '../../assets/css/auth.css']; 
$extraJs=['../../assets/js/main.js', '../../assets/js/api.js', '../../assets/js/admin-auth.js'];
include __DIR__.'/../../includes/auth-header.php'; 
?>

<!-- Back to Home Link -->
<div class="auth-back-home">
    <a href="../../index.php" class="back-link">
        <span class="back-icon">←</span>
        <span>Về trang chủ</span>
    </a>
</div>

<!-- Auth Background -->
<div class="auth-background">
    <div class="bg-shapes">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
    </div>
    <div class="floating-books">
        <div class="book book-1">👑</div>
        <div class="book book-2">⚙️</div>
        <div class="book book-3">📊</div>
        <div class="book book-4">🔧</div>
        <div class="book book-5">🛡️</div>
    </div>
</div>

<main>
    <div class="auth-container admin-login">
        <div class="admin-badge">
            <span class="admin-icon">👑</span>
            <span>Admin Portal</span>
        </div>
        
        <h1>Đăng nhập Admin</h1>
        <p style="text-align: center; color: #6b7280; margin-bottom: 2rem;">Truy cập vào hệ thống quản trị Bookverse</p>
        
        <form id="adminLoginForm" class="auth-form">
            <div id="adminLoginError" class="error-message" style="display: none;"></div>
            
            <label>
                Email Admin
                <input type="email" name="email" required placeholder="Nhập email admin" />
            </label>
            
            <label>
                Mật khẩu
                <div class="input-with-icon">
                    <input type="password" name="password" id="adminPasswordInput" required placeholder="Nhập mật khẩu admin" />
                    <button type="button" id="toggleAdminPwd" class="eye-btn" aria-label="Hiển thị/ẩn mật khẩu">👁️</button>
                </div>
            </label>
            
            <div class="auth-row">
                <div class="form-checkbox">
                    <input type="checkbox" id="rememberAdmin" name="remember" />
                    <label for="rememberAdmin">Ghi nhớ đăng nhập</label>
                </div>
            </div>
            
            <button type="submit" class="btn btn-primary btn-block" id="adminLoginBtn">
                <span class="btn-text">Đăng nhập Admin</span>
                <span class="btn-loading" style="display: none;">⏳</span>
            </button>
            
            <div class="admin-links">
                <p class="muted">
                    <a href="../auth/login.php">Đăng nhập User</a> | 
                    <a href="../auth/register.php">Đăng ký Seller</a>
                </p>
            </div>
        </form>
    </div>
</main>

<style>
.admin-login {
    background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%);
    color: white;
    border-radius: 16px;
    box-shadow: 0 20px 60px rgba(30, 64, 175, 0.3);
}

.admin-badge {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    background: rgba(255, 255, 255, 0.1);
    padding: 0.75rem 1.5rem;
    border-radius: 50px;
    margin-bottom: 1.5rem;
    font-weight: 600;
    backdrop-filter: blur(10px);
}

.admin-icon {
    font-size: 1.2rem;
}

.admin-login h1 {
    color: white;
    text-align: center;
    margin-bottom: 0.5rem;
}

.admin-login .auth-form {
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 12px;
    padding: 2rem;
}

.admin-login .auth-form label {
    color: white;
}

.admin-login .auth-form input {
    background: rgba(255, 255, 255, 0.1);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
}

.admin-login .auth-form input::placeholder {
    color: rgba(255, 255, 255, 0.7);
}

.admin-login .auth-form input:focus {
    background: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.5);
}

.admin-login .btn-primary {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    color: white;
}

.admin-login .btn-primary:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
}

.admin-links {
    margin-top: 1.5rem;
    text-align: center;
}

.admin-links .muted {
    color: rgba(255, 255, 255, 0.8);
}

.admin-links a {
    color: white;
    text-decoration: underline;
}

.admin-links a:hover {
    color: rgba(255, 255, 255, 0.8);
}
</style>

<?php include __DIR__.'/../../includes/auth-footer.php'; ?>
