<?php 
$pageTitle='Quản lý sản phẩm'; 
// $extraCss=['assets/css/admin.css']; 
// $extraJs=['assets/js/admin.js'];
include __DIR__.'/../../includes/header.php'; 
?>

<!-- Client-side auth check -->
<script>
if (!localStorage.getItem('bookverse_token')) {
    window.location.href = '../../pages/auth/login.php';
}
</script>

<style>
<?php include __DIR__ . '/../../assets/css/admin-improved.css'; ?>
</style>

<script>
<?php include __DIR__ . '/../../assets/js/config.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/api.js'; ?>
</script>
<script>
<?php include __DIR__ . '/../../assets/js/admin.js'; ?>
</script>

<!-- Products Management -->
<main class="admin-main">
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <div class="header-content">
                <h1 class="page-title">
                    <span class="title-icon">📚</span>
                    Quản lý sản phẩm
                </h1>
                <p class="page-subtitle">Phê duyệt và quản lý sản phẩm trên hệ thống</p>
            </div>
            <div class="header-actions">
                <button class="btn btn-outline" onclick="exportProducts()">
                    <span class="btn-icon">📊</span>
                    Xuất Excel
                </button>
                <button class="btn btn-primary" onclick="showBulkActions()">
                    <span class="btn-icon">⚡</span>
                    Thao tác hàng loạt
                </button>
            </div>
        </div>

        <!-- Filters and Search -->
        <div class="filters-section">
            <div class="filters-grid">
                <div class="filter-group">
                    <label class="filter-label">Tìm kiếm</label>
                    <input type="text" id="searchInput" class="form-input" placeholder="Tìm theo tên sách, tác giả, ISBN...">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Danh mục</label>
                    <select id="categoryFilter" class="form-select">
                        <option value="">Tất cả danh mục</option>
                        <!-- Categories will be loaded here -->
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Trạng thái</label>
                    <select id="statusFilter" class="form-select">
                        <option value="">Tất cả trạng thái</option>
                        <option value="pending">Chờ phê duyệt</option>
                        <option value="approved">Đã phê duyệt</option>
                        <option value="rejected">Đã từ chối</option>
                        <option value="active">Đang bán</option>
                        <option value="inactive">Ngừng bán</option>
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Người bán</label>
                    <select id="sellerFilter" class="form-select">
                        <option value="">Tất cả người bán</option>
                        <!-- Sellers will be loaded here -->
                    </select>
                </div>
                <div class="filter-group">
                    <label class="filter-label">Giá từ</label>
                    <input type="number" id="priceFrom" class="form-input" placeholder="0">
                </div>
                <div class="filter-group">
                    <label class="filter-label">Giá đến</label>
                    <input type="number" id="priceTo" class="form-input" placeholder="1000000">
                </div>
                <div class="filter-actions">
                    <button class="btn btn-primary" onclick="applyFilters()">
                        <span class="btn-icon">🔍</span>
                        Lọc
                    </button>
                    <button class="btn btn-outline" onclick="clearFilters()">
                        <span class="btn-icon">🔄</span>
                        Xóa bộ lọc
                    </button>
                </div>
            </div>
        </div>

        <!-- Products Table -->
        <div class="table-section">
            <div class="table-header">
                <div class="table-info">
                    <h3>Danh sách sản phẩm</h3>
                    <span class="table-count" id="productCount">0 sản phẩm</span>
                </div>
                <div class="table-actions">
                    <div class="bulk-actions">
                        <select id="bulkAction" class="form-select">
                            <option value="">Thao tác hàng loạt</option>
                            <option value="approve">Phê duyệt</option>
                            <option value="reject">Từ chối</option>
                            <option value="activate">Kích hoạt</option>
                            <option value="deactivate">Vô hiệu hóa</option>
                            <option value="delete">Xóa</option>
                        </select>
                        <button class="btn btn-outline" onclick="applyBulkAction()">
                            Áp dụng
                        </button>
                    </div>
                </div>
            </div>

            <div class="table-container">
                <table class="admin-table" id="productsTable">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                            </th>
                            <th>Sản phẩm</th>
                            <th>Người bán</th>
                            <th>Danh mục</th>
                            <th>Giá</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody id="productsTableBody">
                        <!-- Products will be loaded here -->
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="pagination" id="pagination">
                <!-- Pagination will be loaded here -->
            </div>
        </div>
    </div>
</main>

<!-- Product Detail Modal -->
<div id="productDetailModal" class="modal" style="display: none;">
    <div class="modal-content modal-large">
        <div class="modal-header">
            <h3>Chi tiết sản phẩm</h3>
            <button class="modal-close" onclick="closeProductDetailModal()">&times;</button>
        </div>
        <div class="modal-body" id="productDetailContent">
            <!-- Product details will be loaded here -->
        </div>
    </div>
</div>

<!-- Approve/Reject Modal -->
<div id="approvalModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="approvalModalTitle">Phê duyệt sản phẩm</h3>
            <button class="modal-close" onclick="closeApprovalModal()">&times;</button>
        </div>
        <form id="approvalForm" class="modal-body">
            <input type="hidden" id="approvalProductId">
            <input type="hidden" id="approvalAction">
            
            <div class="form-group">
                <label class="form-label">Lý do (tùy chọn)</label>
                <textarea id="approvalReason" class="form-input" rows="4" 
                          placeholder="Nhập lý do phê duyệt hoặc từ chối..."></textarea>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-outline" onclick="closeApprovalModal()">
                    Hủy
                </button>
                <button type="submit" class="btn btn-primary">
                    <span class="btn-text">Xác nhận</span>
                    <span class="btn-loading" style="display: none;">⏳</span>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Bulk Actions Modal -->
<div id="bulkActionsModal" class="modal" style="display: none;">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Thao tác hàng loạt</h3>
            <button class="modal-close" onclick="closeBulkActionsModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label class="form-label">Chọn thao tác</label>
                <select id="bulkActionSelect" class="form-select">
                    <option value="">Chọn thao tác...</option>
                    <option value="approve">Phê duyệt tất cả</option>
                    <option value="reject">Từ chối tất cả</option>
                    <option value="activate">Kích hoạt tất cả</option>
                    <option value="deactivate">Vô hiệu hóa tất cả</option>
                    <option value="delete">Xóa tất cả</option>
                </select>
            </div>
            
            <div class="form-group">
                <label class="form-label">Lý do (tùy chọn)</label>
                <textarea id="bulkReason" class="form-input" rows="3" 
                          placeholder="Nhập lý do thao tác..."></textarea>
            </div>
            
            <div class="form-actions">
                <button type="button" class="btn btn-outline" onclick="closeBulkActionsModal()">
                    Hủy
                </button>
                <button type="button" class="btn btn-primary" onclick="executeBulkAction()">
                    <span class="btn-text">Thực hiện</span>
                    <span class="btn-loading" style="display: none;">⏳</span>
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Loading Overlay -->
<div id="loadingOverlay" class="loading-overlay" style="display: none;">
    <div class="loading-content">
        <div class="spinner"></div>
        <p>Đang tải dữ liệu...</p>
    </div>
</div>

<!-- Toast Container -->
<div id="toastContainer" class="toast-container"></div>

<script>
// Products management variables
let currentPage = 1;
let currentFilters = {};
let selectedProducts = new Set();
let categories = [];
let sellers = [];

// Initialize products management
document.addEventListener('DOMContentLoaded', function() {
    initializeProductsManagement();
});

// Initialize products management
async function initializeProductsManagement() {
    try {
        showLoading();
        await Promise.all([
            loadProducts(),
            loadCategories(),
            loadSellers()
        ]);
        setupEventListeners();
        hideLoading();
    } catch (error) {
        console.error('Products management initialization failed:', error);
        showToast('Không thể tải danh sách sản phẩm', 'error');
        hideLoading();
    }
}

// Setup event listeners
function setupEventListeners() {
    // Search input
    const searchInput = document.getElementById('searchInput');
    let searchTimeout;
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            applyFilters();
        }, 500);
    });

    // Filter changes
    document.getElementById('categoryFilter').addEventListener('change', applyFilters);
    document.getElementById('statusFilter').addEventListener('change', applyFilters);
    document.getElementById('sellerFilter').addEventListener('change', applyFilters);
    document.getElementById('priceFrom').addEventListener('change', applyFilters);
    document.getElementById('priceTo').addEventListener('change', applyFilters);

    // Approval form
    document.getElementById('approvalForm').addEventListener('submit', handleApproval);
}

// Load products
async function loadProducts() {
    try {
        const params = new URLSearchParams({
            page: currentPage,
            limit: 20,
            ...currentFilters
        });

        console.log('📦 Loading products with params:', params.toString());
        const response = await adminAPI.getProducts(params);
        console.log('✅ Products response:', response);
        
        if (response.success) {
            console.log('📊 Products data:', response.data);
            console.log('📋 Products array:', response.data.products);
            console.log('📈 Product count:', response.data.products?.length);
            
            if (response.data.products && response.data.products.length > 0) {
                displayProducts(response.data.products);
                updatePagination(response.data.pagination);
                updateProductCount(response.data.pagination.total);
            } else {
                console.warn('⚠️ No products found');
                const tbody = document.getElementById('productsTableBody');
                tbody.innerHTML = `
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px;">
                            <div style="font-size: 48px; margin-bottom: 16px;">📦</div>
                            <h3>Không có sản phẩm nào</h3>
                            <p>Chưa có sản phẩm nào trong hệ thống</p>
                        </td>
                    </tr>
                `;
            }
        }
    } catch (error) {
        console.error('❌ Failed to load products:', error);
        console.error('Error details:', error);
        showProductsError();
    }
}

// Load categories
async function loadCategories() {
    try {
        const response = await adminAPI.request('/categories');
        if (response.success) {
            categories = response.data.categories;
            populateCategoryFilter();
        }
    } catch (error) {
        console.error('Failed to load categories:', error);
    }
}

// Load sellers
async function loadSellers() {
    try {
        const response = await adminAPI.request('/users?seller=true');
        if (response.success) {
            sellers = response.data.users;
            populateSellerFilter();
        }
    } catch (error) {
        console.error('Failed to load sellers:', error);
    }
}

// Populate category filter
function populateCategoryFilter() {
    const select = document.getElementById('categoryFilter');
    select.innerHTML = '<option value="">Tất cả danh mục</option>';
    
    categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category._id;
        option.textContent = category.name;
        select.appendChild(option);
    });
}

// Populate seller filter
function populateSellerFilter() {
    const select = document.getElementById('sellerFilter');
    select.innerHTML = '<option value="">Tất cả người bán</option>';
    
    sellers.forEach(seller => {
        const option = document.createElement('option');
        option.value = seller._id;
        option.textContent = seller.profile?.firstName + ' ' + seller.profile?.lastName;
        select.appendChild(option);
    });
}

// Display products
function displayProducts(products) {
    const tbody = document.getElementById('productsTableBody');
    
    tbody.innerHTML = products.map(product => `
        <tr data-product-id="${product._id}">
            <td>
                <input type="checkbox" class="product-checkbox" value="${product._id}" 
                       onchange="toggleProductSelection('${product._id}')">
            </td>
            <td>
                <div class="product-info">
                    <div class="product-image">
                        <img src="${product.images && product.images[0] && product.images[0].url ? product.images[0].url : 'https://via.placeholder.com/80x100?text=No+Image'}" 
                             alt="${product.title}" 
                             onerror="this.src='https://via.placeholder.com/80x100?text=No+Image'">
                    </div>
                    <div class="product-details">
                        <h4 class="product-title">${product.title}</h4>
                        <p class="product-author">${product.author}</p>
                        <p class="product-isbn">ISBN: ${product.isbn || 'N/A'}</p>
                    </div>
                </div>
            </td>
            <td>
                <div class="seller-info">
                    <h5 class="seller-name">${product.seller?.profile?.firstName || ''} ${product.seller?.profile?.lastName || ''}</h5>
                    <p class="seller-username">@${product.seller?.username || ''}</p>
                </div>
            </td>
            <td>
                <span class="category-badge">${product.category?.name || 'Chưa phân loại'}</span>
            </td>
            <td>
                <span class="price-value">${formatCurrency(product.price)}</span>
                ${product.originalPrice && product.originalPrice > product.price ? 
                    `<span class="original-price">${formatCurrency(product.originalPrice)}</span>` : ''}
            </td>
            <td>
                <span class="status-badge status-${product.status}">
                    ${getStatusLabel(product.status)}
                </span>
                ${product.isActive ? '' : '<span class="status-badge status-inactive">Không hoạt động</span>'}
            </td>
            <td>${formatDate(product.createdAt)}</td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-sm btn-outline" onclick="viewProductDetail('${product._id}')" title="Xem chi tiết">
                        👁️
                    </button>
                    ${product.status === 'pending' ? `
                        <button class="btn btn-sm btn-success" onclick="showApprovalModal('${product._id}', 'approve')" title="Phê duyệt">
                            ✅
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="showApprovalModal('${product._id}', 'reject')" title="Từ chối">
                            ❌
                        </button>
                    ` : ''}
                    <button class="btn btn-sm ${product.isActive ? 'btn-warning' : 'btn-success'}" 
                            onclick="toggleProductStatus('${product._id}', ${product.isActive})" 
                            title="${product.isActive ? 'Vô hiệu hóa' : 'Kích hoạt'}">
                        ${product.isActive ? '⏸️' : '▶️'}
                    </button>
                    <button class="btn btn-sm btn-danger" onclick="deleteProduct('${product._id}')" title="Xóa">
                        🗑️
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Apply filters
function applyFilters() {
    currentFilters = {
        search: document.getElementById('searchInput').value,
        category: document.getElementById('categoryFilter').value,
        status: document.getElementById('statusFilter').value,
        seller: document.getElementById('sellerFilter').value,
        priceFrom: document.getElementById('priceFrom').value,
        priceTo: document.getElementById('priceTo').value
    };

    // Remove empty filters
    Object.keys(currentFilters).forEach(key => {
        if (!currentFilters[key]) {
            delete currentFilters[key];
        }
    });

    currentPage = 1;
    loadProducts();
}

// Clear filters
function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('categoryFilter').value = '';
    document.getElementById('statusFilter').value = '';
    document.getElementById('sellerFilter').value = '';
    document.getElementById('priceFrom').value = '';
    document.getElementById('priceTo').value = '';
    
    currentFilters = {};
    currentPage = 1;
    loadProducts();
}

// Toggle select all
function toggleSelectAll() {
    const selectAll = document.getElementById('selectAll');
    const checkboxes = document.querySelectorAll('.product-checkbox');
    
    checkboxes.forEach(checkbox => {
        checkbox.checked = selectAll.checked;
        if (selectAll.checked) {
            selectedProducts.add(checkbox.value);
        } else {
            selectedProducts.delete(checkbox.value);
        }
    });
}

// Toggle product selection
function toggleProductSelection(productId) {
    const checkbox = document.querySelector(`input[value="${productId}"]`);
    if (checkbox.checked) {
        selectedProducts.add(productId);
    } else {
        selectedProducts.delete(productId);
    }
    
    // Update select all checkbox
    const totalCheckboxes = document.querySelectorAll('.product-checkbox').length;
    const checkedCheckboxes = document.querySelectorAll('.product-checkbox:checked').length;
    document.getElementById('selectAll').checked = totalCheckboxes === checkedCheckboxes;
}

// View product detail
async function viewProductDetail(productId) {
    try {
        showLoading();
        const response = await adminAPI.request(`/products/${productId}`);
        if (response.success) {
            displayProductDetail(response.data.product);
            document.getElementById('productDetailModal').style.display = 'flex';
        }
    } catch (error) {
        console.error('Failed to load product detail:', error);
        showToast('Không thể tải chi tiết sản phẩm', 'error');
    } finally {
        hideLoading();
    }
}

// Display product detail
function displayProductDetail(product) {
    const content = document.getElementById('productDetailContent');
    content.innerHTML = `
        <div class="product-detail-grid">
            <div class="detail-section">
                <h4>Thông tin cơ bản</h4>
                <div class="product-images">
                    ${product.images?.map(img => `
                        <img src="${img}" alt="${product.title}" class="product-detail-image">
                    `).join('') || '<p>Không có hình ảnh</p>'}
                </div>
                <div class="detail-info">
                    <div class="info-row">
                        <span class="info-label">Tên sách:</span>
                        <span class="info-value">${product.title}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Tác giả:</span>
                        <span class="info-value">${product.author}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">ISBN:</span>
                        <span class="info-value">${product.isbn || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Nhà xuất bản:</span>
                        <span class="info-value">${product.publisher || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Năm xuất bản:</span>
                        <span class="info-value">${product.publishYear || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Số trang:</span>
                        <span class="info-value">${product.pages || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Ngôn ngữ:</span>
                        <span class="info-value">${product.language || 'N/A'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Tình trạng:</span>
                        <span class="info-value">${product.condition || 'N/A'}</span>
                    </div>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Thông tin bán hàng</h4>
                <div class="detail-info">
                    <div class="info-row">
                        <span class="info-label">Giá:</span>
                        <span class="info-value price-value">${formatCurrency(product.price)}</span>
                    </div>
                    ${product.originalPrice ? `
                    <div class="info-row">
                        <span class="info-label">Giá gốc:</span>
                        <span class="info-value original-price">${formatCurrency(product.originalPrice)}</span>
                    </div>
                    ` : ''}
                    <div class="info-row">
                        <span class="info-label">Số lượng:</span>
                        <span class="info-value">${product.stock || 0}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Danh mục:</span>
                        <span class="info-value">${product.category?.name || 'Chưa phân loại'}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Trạng thái:</span>
                        <span class="status-badge status-${product.status}">${getStatusLabel(product.status)}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Người bán:</span>
                        <span class="info-value">${product.seller?.profile?.firstName || ''} ${product.seller?.profile?.lastName || ''}</span>
                    </div>
                </div>
            </div>
            
            <div class="detail-section">
                <h4>Mô tả sản phẩm</h4>
                <div class="product-description">
                    ${product.description || 'Không có mô tả'}
                </div>
            </div>
        </div>
    `;
}

// Show approval modal
function showApprovalModal(productId, action) {
    document.getElementById('approvalProductId').value = productId;
    document.getElementById('approvalAction').value = action;
    document.getElementById('approvalModalTitle').textContent = 
        action === 'approve' ? 'Phê duyệt sản phẩm' : 'Từ chối sản phẩm';
    document.getElementById('approvalModal').style.display = 'flex';
}

// Close approval modal
function closeApprovalModal() {
    document.getElementById('approvalModal').style.display = 'none';
    document.getElementById('approvalForm').reset();
}

// Handle approval
async function handleApproval(e) {
    e.preventDefault();
    
    const productId = document.getElementById('approvalProductId').value;
    const action = document.getElementById('approvalAction').value;
    const reason = document.getElementById('approvalReason').value;
    
    const submitBtn = e.target.querySelector('button[type="submit"]');
    const btnText = submitBtn.querySelector('.btn-text');
    const btnLoading = submitBtn.querySelector('.btn-loading');
    
    try {
        btnText.style.display = 'none';
        btnLoading.style.display = 'inline';
        submitBtn.disabled = true;
        
        let response;
        if (action === 'approve') {
            response = await adminAPI.approveProduct(productId);
        } else {
            response = await adminAPI.rejectProduct(productId, reason);
        }
        
        if (response.success) {
            showToast(`Đã ${action === 'approve' ? 'phê duyệt' : 'từ chối'} sản phẩm`, 'success');
            closeApprovalModal();
            loadProducts();
        }
    } catch (error) {
        console.error('Failed to handle approval:', error);
        showToast('Không thể thực hiện thao tác', 'error');
    } finally {
        btnText.style.display = 'inline';
        btnLoading.style.display = 'none';
        submitBtn.disabled = false;
    }
}

// Toggle product status
async function toggleProductStatus(productId, currentStatus) {
    try {
        const status = currentStatus ? 'inactive' : 'active';
        const response = await adminAPI.updateProductStatus(productId, status);
        
        if (response.success) {
            showToast(`Đã ${currentStatus ? 'vô hiệu hóa' : 'kích hoạt'} sản phẩm`, 'success');
            loadProducts();
        }
    } catch (error) {
        console.error('Failed to toggle product status:', error);
        showToast('Không thể thay đổi trạng thái sản phẩm', 'error');
    }
}

// Delete product
async function deleteProduct(productId) {
    if (!confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')) {
        return;
    }
    
    try {
        const response = await adminAPI.request(`/products/${productId}`, {
            method: 'DELETE'
        });
        
        if (response.success) {
            showToast('Đã xóa sản phẩm', 'success');
            loadProducts();
        }
    } catch (error) {
        console.error('Failed to delete product:', error);
        showToast('Không thể xóa sản phẩm', 'error');
    }
}

// Show bulk actions modal
function showBulkActions() {
    if (selectedProducts.size === 0) {
        showToast('Vui lòng chọn sản phẩm để thực hiện thao tác', 'warning');
        return;
    }
    
    document.getElementById('bulkActionsModal').style.display = 'flex';
}

// Close bulk actions modal
function closeBulkActionsModal() {
    document.getElementById('bulkActionsModal').style.display = 'none';
    document.getElementById('bulkActionSelect').value = '';
    document.getElementById('bulkReason').value = '';
}

// Execute bulk action
async function executeBulkAction() {
    const action = document.getElementById('bulkActionSelect').value;
    const reason = document.getElementById('bulkReason').value;
    
    if (!action) {
        showToast('Vui lòng chọn thao tác', 'warning');
        return;
    }
    
    if (!confirm(`Bạn có chắc chắn muốn ${action} ${selectedProducts.size} sản phẩm?`)) {
        return;
    }
    
    try {
        const response = await adminAPI.request('/products/bulk', {
            method: 'PUT',
            body: JSON.stringify({
                action: action,
                productIds: Array.from(selectedProducts),
                reason: reason
            })
        });
        
        if (response.success) {
            showToast(`Đã ${action} ${selectedProducts.size} sản phẩm`, 'success');
            selectedProducts.clear();
            document.getElementById('selectAll').checked = false;
            closeBulkActionsModal();
            loadProducts();
        }
    } catch (error) {
        console.error('Failed to execute bulk action:', error);
        showToast('Không thể thực hiện thao tác hàng loạt', 'error');
    }
}

// Apply bulk action (from table)
async function applyBulkAction() {
    const action = document.getElementById('bulkAction').value;
    if (!action || selectedProducts.size === 0) {
        showToast('Vui lòng chọn thao tác và sản phẩm', 'warning');
        return;
    }
    
    if (!confirm(`Bạn có chắc chắn muốn ${action} ${selectedProducts.size} sản phẩm?`)) {
        return;
    }
    
    try {
        const response = await adminAPI.request('/products/bulk', {
            method: 'PUT',
            body: JSON.stringify({
                action: action,
                productIds: Array.from(selectedProducts)
            })
        });
        
        if (response.success) {
            showToast(`Đã ${action} ${selectedProducts.size} sản phẩm`, 'success');
            selectedProducts.clear();
            document.getElementById('selectAll').checked = false;
            loadProducts();
        }
    } catch (error) {
        console.error('Failed to apply bulk action:', error);
        showToast('Không thể thực hiện thao tác hàng loạt', 'error');
    }
}

// Export products
function exportProducts() {
    showToast('Tính năng xuất Excel đang được phát triển', 'info');
}

// Update pagination
function updatePagination(pagination) {
    const paginationContainer = document.getElementById('pagination');
    
    if (pagination.pages <= 1) {
        paginationContainer.innerHTML = '';
        return;
    }
    
    let paginationHTML = '<div class="pagination-content">';
    
    // Previous button
    if (pagination.page > 1) {
        paginationHTML += `<button class="pagination-btn" onclick="changePage(${pagination.page - 1})">‹</button>`;
    }
    
    // Page numbers
    const startPage = Math.max(1, pagination.page - 2);
    const endPage = Math.min(pagination.pages, pagination.page + 2);
    
    for (let i = startPage; i <= endPage; i++) {
        paginationHTML += `<button class="pagination-btn ${i === pagination.page ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
    }
    
    // Next button
    if (pagination.page < pagination.pages) {
        paginationHTML += `<button class="pagination-btn" onclick="changePage(${pagination.page + 1})">›</button>`;
    }
    
    paginationHTML += '</div>';
    paginationContainer.innerHTML = paginationHTML;
}

// Change page
function changePage(page) {
    currentPage = page;
    loadProducts();
}

// Update product count
function updateProductCount(total) {
    document.getElementById('productCount').textContent = `${total} sản phẩm`;
}

// Show products error
function showProductsError() {
    const tbody = document.getElementById('productsTableBody');
    tbody.innerHTML = `
        <tr>
            <td colspan="8" class="error-state">
                <div class="error-icon">⚠️</div>
                <p>Không thể tải danh sách sản phẩm</p>
                <button class="btn btn-outline" onclick="loadProducts()">Thử lại</button>
            </td>
        </tr>
    `;
}

// Close product detail modal
function closeProductDetailModal() {
    document.getElementById('productDetailModal').style.display = 'none';
}

// Utility functions
function getStatusLabel(status) {
    const labels = {
        'pending': 'Chờ phê duyệt',
        'approved': 'Đã phê duyệt',
        'rejected': 'Đã từ chối',
        'active': 'Đang bán',
        'inactive': 'Ngừng bán'
    };
    return labels[status] || status;
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('vi-VN');
}

function showLoading() {
    document.getElementById('loadingOverlay').style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loadingOverlay').style.display = 'none';
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
        <div class="toast-content">
            <span class="toast-icon">${getToastIcon(type)}</span>
            <span class="toast-message">${message}</span>
            <button class="toast-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    document.getElementById('toastContainer').appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

function getToastIcon(type) {
    const icons = {
        success: '✅',
        error: '❌',
        warning: '⚠️',
        info: 'ℹ️'
    };
    return icons[type] || icons.info;
}
</script>

<?php include __DIR__.'/../../includes/footer.php'; ?>


