<?php 
$pageTitle='Trợ giúp'; 
$extraCss=['assets/css/main.css', 'assets/css/responsive.css']; 
$extraJs=['assets/js/main.js', 'assets/js/api.js'];
include 'includes/header.php'; 
?>

<main class="main" role="main">
    <!-- Hero Section -->
    <section class="hero hero-small" aria-labelledby="help-hero-title">
        <div class="container">
            <div class="hero-content">
                <h1 id="help-hero-title" class="hero-title">Trung tâm trợ giúp</h1>
                <p class="hero-subtitle">Tìm câu trả lời cho các câu hỏi thường gặp và hướng dẫn sử dụng</p>
            </div>
        </div>
    </section>

    <!-- Search Help -->
    <section class="help-search" aria-labelledby="help-search-title">
        <div class="container">
            <h2 id="help-search-title" class="section-title">Tìm kiếm trợ giúp</h2>
            <div class="search-wrapper">
                <form class="help-search-form" action="help.php" method="GET">
                    <div class="search-input-group">
                        <input type="text" name="q" placeholder="Nhập từ khóa tìm kiếm..." 
                               class="search-input" value="<?php echo htmlspecialchars($_GET['q'] ?? ''); ?>">
                        <button type="submit" class="search-btn">
                            <span class="search-icon">🔍</span>
                            Tìm kiếm
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>

    <!-- Quick Links -->
    <section class="quick-links-section" aria-labelledby="quick-links-title">
        <div class="container">
            <h2 id="quick-links-title" class="section-title">Liên kết nhanh</h2>
            <div class="quick-links-grid">
                <a href="#faq" class="quick-link-card">
                    <div class="quick-link-icon">❓</div>
                    <h3>Câu hỏi thường gặp</h3>
                    <p>Tìm câu trả lời cho các câu hỏi phổ biến</p>
                </a>
                
                <a href="#shipping" class="quick-link-card">
                    <div class="quick-link-icon">🚚</div>
                    <h3>Vận chuyển</h3>
                    <p>Thông tin về phí ship và thời gian giao hàng</p>
                </a>
                
                <a href="#returns" class="quick-link-card">
                    <div class="quick-link-icon">↩️</div>
                    <h3>Đổi trả</h3>
                    <p>Chính sách đổi trả và hoàn tiền</p>
                </a>
                
                <a href="#payment" class="quick-link-card">
                    <div class="quick-link-icon">💳</div>
                    <h3>Thanh toán</h3>
                    <p>Các phương thức thanh toán được chấp nhận</p>
                </a>
                
                <a href="#account" class="quick-link-card">
                    <div class="quick-link-icon">👤</div>
                    <h3>Tài khoản</h3>
                    <p>Quản lý tài khoản và thông tin cá nhân</p>
                </a>
                
                <a href="#seller" class="quick-link-card">
                    <div class="quick-link-icon">🏪</div>
                    <h3>Người bán</h3>
                    <p>Hướng dẫn cho người bán trên nền tảng</p>
                </a>
            </div>
        </div>
    </section>

    <!-- FAQ Section -->
    <section id="faq" class="faq-section" aria-labelledby="faq-title">
        <div class="container">
            <h2 id="faq-title" class="section-title">Câu hỏi thường gặp</h2>
            <div class="faq-categories">
                <button class="faq-category-btn active" data-category="general">Chung</button>
                <button class="faq-category-btn" data-category="ordering">Đặt hàng</button>
                <button class="faq-category-btn" data-category="shipping">Vận chuyển</button>
                <button class="faq-category-btn" data-category="returns">Đổi trả</button>
                <button class="faq-category-btn" data-category="payment">Thanh toán</button>
            </div>
            
            <div class="faq-list">
                <!-- General FAQ -->
                <div class="faq-category" data-category="general">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Bookverse là gì?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Bookverse là nền tảng thương mại điện tử chuyên về sách, nơi bạn có thể mua bán sách mới và cũ với giá cả hợp lý. Chúng tôi kết nối người mua và người bán sách trên toàn quốc.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Làm thế nào để đăng ký tài khoản?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Bạn có thể đăng ký tài khoản bằng cách:</p>
                            <ol>
                                <li>Nhấn nút "Đăng ký" ở góc trên bên phải</li>
                                <li>Điền thông tin cá nhân</li>
                                <li>Xác nhận email</li>
                                <li>Hoàn tất đăng ký</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Tôi có thể bán sách trên Bookverse không?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Có, bạn hoàn toàn có thể bán sách trên Bookverse. Chỉ cần đăng ký tài khoản người bán, cung cấp thông tin kinh doanh và bắt đầu đăng sản phẩm.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Ordering FAQ -->
                <div class="faq-category" data-category="ordering" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Làm thế nào để đặt hàng?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Quy trình đặt hàng rất đơn giản:</p>
                            <ol>
                                <li>Tìm kiếm sản phẩm mong muốn</li>
                                <li>Xem chi tiết sản phẩm</li>
                                <li>Thêm vào giỏ hàng</li>
                                <li>Kiểm tra giỏ hàng</li>
                                <li>Nhập thông tin giao hàng</li>
                                <li>Chọn phương thức thanh toán</li>
                                <li>Xác nhận đơn hàng</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Tôi có thể hủy đơn hàng không?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Bạn có thể hủy đơn hàng trong các trường hợp:</p>
                            <ul>
                                <li>Đơn hàng chưa được xác nhận</li>
                                <li>Đơn hàng chưa được đóng gói</li>
                                <li>Trong vòng 2 giờ kể từ khi đặt hàng</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Shipping FAQ -->
                <div class="faq-category" data-category="shipping" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Thời gian giao hàng là bao lâu?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Thời gian giao hàng tùy thuộc vào địa điểm:</p>
                            <ul>
                                <li><strong>Nội thành TP Hồ Chí Minh:</strong> 1-2 ngày làm việc</li>
                                <li><strong>Các tỉnh thành khác:</strong> 3-5 ngày làm việc</li>
                                <li><strong>Vùng sâu vùng xa:</strong> 5-7 ngày làm việc</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Phí vận chuyển được tính như thế nào?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Phí vận chuyển được tính dựa trên:</p>
                            <ul>
                                <li>Khoảng cách địa lý</li>
                                <li>Trọng lượng và kích thước sản phẩm</li>
                                <li>Phương thức vận chuyển</li>
                                <li>Đơn hàng từ 500.000đ được miễn phí ship</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Returns FAQ -->
                <div class="faq-category" data-category="returns" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Chính sách đổi trả như thế nào?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Bạn có thể đổi trả sản phẩm trong vòng 7 ngày kể từ khi nhận hàng với các điều kiện:</p>
                            <ul>
                                <li>Sản phẩm còn nguyên vẹn, không bị hư hỏng</li>
                                <li>Còn đầy đủ bao bì, tem mác</li>
                                <li>Có hóa đơn mua hàng</li>
                                <li>Không phải sản phẩm đặc biệt (sách ký tên, bản giới hạn)</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Làm thế nào để yêu cầu đổi trả?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Để yêu cầu đổi trả:</p>
                            <ol>
                                <li>Đăng nhập tài khoản</li>
                                <li>Vào "Đơn hàng của tôi"</li>
                                <li>Chọn đơn hàng cần đổi trả</li>
                                <li>Nhấn "Yêu cầu đổi trả"</li>
                                <li>Điền lý do và mô tả chi tiết</li>
                                <li>Chờ xác nhận từ hệ thống</li>
                            </ol>
                        </div>
                    </div>
                </div>
                
                <!-- Payment FAQ -->
                <div class="faq-category" data-category="payment" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Những phương thức thanh toán nào được chấp nhận?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Chúng tôi chấp nhận các phương thức thanh toán:</p>
                            <ul>
                                <li><strong>COD:</strong> Thanh toán khi nhận hàng</li>
                                <li><strong>Chuyển khoản:</strong> Qua ngân hàng</li>
                                <li><strong>Thẻ tín dụng/ghi nợ:</strong> Visa, Mastercard</li>
                                <li><strong>Ví điện tử:</strong> MoMo, ZaloPay, ViettelPay</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Thanh toán có an toàn không?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Chúng tôi đảm bảo an toàn tuyệt đối cho giao dịch:</p>
                            <ul>
                                <li>Mã hóa SSL 256-bit</li>
                                <li>Không lưu trữ thông tin thẻ</li>
                                <li>Tuân thủ chuẩn PCI DSS</li>
                                <li>Bảo vệ thông tin cá nhân</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Support -->
    <section class="contact-support" aria-labelledby="contact-support-title">
        <div class="container">
            <h2 id="contact-support-title" class="section-title">Vẫn chưa tìm thấy câu trả lời?</h2>
            <p class="section-subtitle">Liên hệ với đội ngũ hỗ trợ của chúng tôi</p>
            
            <div class="support-options">
                <div class="support-option">
                    <div class="support-icon">📧</div>
                    <h3>Email hỗ trợ</h3>
                    <p>Gửi email cho chúng tôi</p>
                    <a href="mailto:support@bookverse.vn" class="support-link">support@bookverse.vn</a>
                </div>
                
                <div class="support-option">
                    <div class="support-icon">📞</div>
                    <h3>Hotline</h3>
                    <p>Gọi trực tiếp cho chúng tôi</p>
                    <a href="tel:19001234" class="support-link">1900 1234</a>
                </div>
                
                <div class="support-option">
                    <div class="support-icon">💬</div>
                    <h3>Chat trực tuyến</h3>
                    <p>Chat với nhân viên hỗ trợ</p>
                    <button class="support-link chat-btn">Bắt đầu chat</button>
                </div>
            </div>
        </div>
    </section>
</main>

<style>
/* Help Page Styles */
.hero-small {
    background: linear-gradient(135deg, var(--primary) 0%, var(--accent-color) 100%);
    color: white;
    padding: 4rem 0 2rem;
    text-align: center;
}

.hero-small .hero-title {
    font-size: var(--text-3xl);
    margin-bottom: 1rem;
}

.hero-small .hero-subtitle {
    font-size: var(--text-lg);
    opacity: 0.9;
}

.help-search {
    padding: 3rem 0;
    background: var(--bg-secondary);
}

.search-wrapper {
    max-width: 600px;
    margin: 0 auto;
}

.help-search-form {
    position: relative;
}

.search-input-group {
    display: flex;
    background: white;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-md);
    overflow: hidden;
}

.search-input {
    flex: 1;
    padding: 1rem 1.5rem;
    border: none;
    font-size: var(--text-lg);
    outline: none;
    color: #1a1a1a;
    font-weight: 500;
}

.search-input::placeholder {
    color: #9ca3af;
    font-weight: 400;
}

.search-btn {
    padding: 1rem 2rem;
    background: var(--primary);
    color: white;
    border: none;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 500;
    transition: var(--transition-fast);
}

.search-btn:hover {
    background: var(--primary-hover);
}

.quick-links-section {
    padding: 4rem 0;
}

.quick-links-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.quick-link-card {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    text-decoration: none;
    color: inherit;
    transition: var(--transition-normal);
    text-align: center;
}

.quick-link-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
    color: inherit;
}

.quick-link-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.quick-link-card h3 {
    font-size: var(--text-xl);
    margin-bottom: 0.5rem;
    color: #1a1a1a;
    font-weight: 600;
}

.quick-link-card p {
    color: #4a4a4a;
    line-height: 1.6;
}

.faq-section {
    padding: 4rem 0;
    background: var(--bg-secondary);
}

.faq-categories {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin: 2rem 0;
    flex-wrap: wrap;
}

.faq-category-btn {
    padding: 0.75rem 1.5rem;
    border: 2px solid var(--border-color);
    background: white;
    border-radius: var(--radius-full);
    cursor: pointer;
    transition: var(--transition-fast);
    font-weight: 500;
}

.faq-category-btn.active,
.faq-category-btn:hover {
    border-color: var(--primary);
    background: var(--primary);
    color: white;
}

.faq-list {
    max-width: 800px;
    margin: 0 auto;
}

.faq-item {
    background: white;
    margin-bottom: 1rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
}

.faq-question {
    width: 100%;
    padding: 1.5rem;
    background: none;
    border: none;
    text-align: left;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: var(--text-lg);
    font-weight: 600;
    color: #1a1a1a;
    transition: var(--transition-fast);
}

.faq-question:hover {
    background: var(--bg-tertiary);
}

.faq-icon {
    font-size: 1.5rem;
    transition: var(--transition-fast);
}

.faq-question[aria-expanded="true"] .faq-icon {
    transform: rotate(45deg);
}

.faq-answer {
    padding: 0 1.5rem 1.5rem;
    color: #4a4a4a;
    line-height: 1.6;
    display: none;
}

.faq-answer.show {
    display: block;
}

.faq-answer ol,
.faq-answer ul {
    margin: 1rem 0;
    padding-left: 1.5rem;
}

.faq-answer li {
    margin-bottom: 0.5rem;
}

.contact-support {
    padding: 4rem 0;
}

.support-options {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.support-option {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    text-align: center;
    transition: var(--transition-normal);
}

.support-option:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.support-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.support-option h3 {
    font-size: var(--text-xl);
    margin-bottom: 0.5rem;
    color: #1a1a1a;
    font-weight: 600;
}

.support-option p {
    color: #4a4a4a;
    margin-bottom: 1rem;
}

.support-link {
    color: #1a1a1a;
    text-decoration: none;
    font-weight: 600;
    font-size: var(--text-lg);
    background: var(--primary);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: var(--radius-md);
    display: inline-block;
    transition: all 0.3s ease;
}

.support-link:hover {
    background: var(--primary-hover);
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    text-decoration: none;
}

.chat-btn {
    background: var(--primary);
    color: white;
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-weight: 500;
    transition: var(--transition-fast);
}

.chat-btn:hover {
    background: var(--primary-hover);
    text-decoration: none;
}

/* Enhanced readability */
.quick-link-card h3,
.faq-question,
.support-option h3 {
    text-shadow: 0 1px 1px rgba(0,0,0,0.1);
}

/* Better search styling */
.search-input {
    font-weight: 500;
    background: white;
}

.search-btn {
    font-weight: 600;
    background: var(--primary);
    color: white;
}

.search-btn:hover {
    background: var(--primary-hover);
    color: white;
}

/* Enhanced category buttons */
.faq-category-btn {
    font-weight: 600;
    transition: all 0.3s ease;
    color: #4a4a4a;
    background: white;
    border: 2px solid #e5e7eb;
}

.faq-category-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    border-color: var(--primary);
    color: var(--primary);
}

.faq-category-btn.active {
    background: var(--primary);
    border-color: var(--primary);
    color: white;
}

/* Responsive Design */
@media (max-width: 768px) {
    .faq-categories {
        flex-direction: column;
        align-items: center;
    }
    
    .faq-category-btn {
        width: 200px;
    }
    
    .search-input-group {
        flex-direction: column;
    }
    
    .search-btn {
        border-radius: 0;
    }
    
    .quick-links-grid {
        grid-template-columns: 1fr;
    }
    
    .support-options {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // FAQ functionality
    const faqQuestions = document.querySelectorAll('.faq-question');
    const faqCategoryBtns = document.querySelectorAll('.faq-category-btn');
    const faqCategories = document.querySelectorAll('.faq-category');
    
    // Toggle FAQ answers
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            const answer = this.nextElementSibling;
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            
            // Close all other FAQs
            faqQuestions.forEach(q => {
                q.setAttribute('aria-expanded', 'false');
                q.nextElementSibling.classList.remove('show');
            });
            
            // Toggle current FAQ
            if (!isExpanded) {
                this.setAttribute('aria-expanded', 'true');
                answer.classList.add('show');
            }
        });
    });
    
    // FAQ category switching
    faqCategoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.dataset.category;
            
            // Update active button
            faqCategoryBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Show/hide categories
            faqCategories.forEach(cat => {
                if (cat.dataset.category === category) {
                    cat.style.display = 'block';
                } else {
                    cat.style.display = 'none';
                }
            });
        });
    });
    
    // Chat button functionality
    const chatBtn = document.querySelector('.chat-btn');
    if (chatBtn) {
        chatBtn.addEventListener('click', function() {
            alert('Tính năng chat trực tuyến sẽ được triển khai sớm!');
        });
    }
    
    // Search functionality
    const searchForm = document.querySelector('.help-search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            const query = this.querySelector('input[name="q"]').value.trim();
            if (!query) {
                e.preventDefault();
                alert('Vui lòng nhập từ khóa tìm kiếm');
            }
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>
