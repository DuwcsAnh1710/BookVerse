<?php 
$pageTitle='Hỗ trợ người bán'; 
$extraCss=['assets/css/main.css', 'assets/css/responsive.css', 'assets/css/seller.css']; 
$extraJs=['assets/js/main.js', 'assets/js/api.js'];
include 'includes/header.php'; 
?>

<main class="main" role="main">
    <!-- Hero Section -->
    <section class="hero hero-small seller-hero" aria-labelledby="seller-support-hero-title">
        <div class="container">
            <div class="hero-content">
                <h1 id="seller-support-hero-title" class="hero-title">Hỗ trợ người bán</h1>
                <p class="hero-subtitle">Tài nguyên và hướng dẫn dành riêng cho người bán trên Bookverse</p>
                <div class="hero-stats">
                    <div class="stat-item">
                        <span class="stat-number">5,000+</span>
                        <span class="stat-label">Người bán</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">50,000+</span>
                        <span class="stat-label">Sản phẩm</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">99%</span>
                        <span class="stat-label">Hài lòng</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Actions -->
    <section class="quick-actions" aria-labelledby="quick-actions-title">
        <div class="container">
            <h2 id="quick-actions-title" class="section-title">Hành động nhanh</h2>
            <div class="actions-grid">
                <a href="pages/seller/dashboard.php" class="action-card">
                    <div class="action-icon">📊</div>
                    <h3>Dashboard</h3>
                    <p>Xem thống kê bán hàng và doanh thu</p>
                </a>
                
                <a href="pages/seller/products.php" class="action-card">
                    <div class="action-icon">📚</div>
                    <h3>Quản lý sản phẩm</h3>
                    <p>Thêm, sửa, xóa sản phẩm</p>
                </a>
                
                <a href="pages/seller/orders.php" class="action-card">
                    <div class="action-icon">📦</div>
                    <h3>Đơn hàng</h3>
                    <p>Xử lý và theo dõi đơn hàng</p>
                </a>
                
                <a href="pages/seller/bank-account.php" class="action-card">
                    <div class="action-icon">🏦</div>
                    <h3>Tài khoản ngân hàng</h3>
                    <p>Cài đặt thông tin thanh toán</p>
                </a>
            </div>
        </div>
    </section>

    <!-- Getting Started -->
    <section class="getting-started" aria-labelledby="getting-started-title">
        <div class="container">
            <h2 id="getting-started-title" class="section-title">Bắt đầu bán hàng</h2>
            <div class="steps-wrapper">
                <div class="steps-timeline">
                    <div class="step-item">
                        <div class="step-number">1</div>
                        <div class="step-content">
                            <h3>Đăng ký tài khoản người bán</h3>
                            <p>Cung cấp thông tin kinh doanh và xác minh danh tính để trở thành người bán chính thức trên Bookverse.</p>
                            <a href="pages/auth/seller-register.php" class="btn btn-primary">Đăng ký ngay</a>
                        </div>
                    </div>
                    
                    <div class="step-item">
                        <div class="step-number">2</div>
                        <div class="step-content">
                            <h3>Thiết lập tài khoản ngân hàng</h3>
                            <p>Liên kết tài khoản ngân hàng để nhận thanh toán từ các giao dịch bán hàng.</p>
                            <a href="pages/seller/bank-account.php" class="btn btn-outline">Thiết lập</a>
                        </div>
                    </div>
                    
                    <div class="step-item">
                        <div class="step-number">3</div>
                        <div class="step-content">
                            <h3>Đăng sản phẩm đầu tiên</h3>
                            <p>Tạo danh sách sản phẩm với thông tin chi tiết, hình ảnh chất lượng cao và giá cả cạnh tranh.</p>
                            <a href="pages/seller/products.php" class="btn btn-outline">Đăng sản phẩm</a>
                        </div>
                    </div>
                    
                    <div class="step-item">
                        <div class="step-number">4</div>
                        <div class="step-content">
                            <h3>Bắt đầu bán hàng</h3>
                            <p>Xử lý đơn hàng, giao hàng và nhận thanh toán. Theo dõi hiệu suất bán hàng trên dashboard.</p>
                            <a href="pages/seller/dashboard.php" class="btn btn-outline">Xem dashboard</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Seller Resources -->
    <section class="seller-resources" aria-labelledby="seller-resources-title">
        <div class="container">
            <h2 id="seller-resources-title" class="section-title">Tài nguyên cho người bán</h2>
            <div class="resources-grid">
                <div class="resource-card">
                    <div class="resource-icon">📖</div>
                    <h3>Hướng dẫn bán hàng</h3>
                    <p>Hướng dẫn chi tiết về cách bán hàng hiệu quả trên Bookverse</p>
                    <ul class="resource-links">
                        <li><a href="#guide-1">Cách tạo danh sách sản phẩm</a></li>
                        <li><a href="#guide-2">Tối ưu hóa hình ảnh sản phẩm</a></li>
                        <li><a href="#guide-3">Đặt giá cạnh tranh</a></li>
                        <li><a href="#guide-4">Quản lý kho hàng</a></li>
                    </ul>
                </div>
                
                <div class="resource-card">
                    <div class="resource-icon">📊</div>
                    <h3>Phân tích và báo cáo</h3>
                    <p>Hiểu rõ hiệu suất bán hàng với các công cụ phân tích</p>
                    <ul class="resource-links">
                        <li><a href="#analytics-1">Báo cáo doanh thu</a></li>
                        <li><a href="#analytics-2">Thống kê sản phẩm</a></li>
                        <li><a href="#analytics-3">Phân tích khách hàng</a></li>
                        <li><a href="#analytics-4">Xu hướng bán hàng</a></li>
                    </ul>
                </div>
                
                <div class="resource-card">
                    <div class="resource-icon">🎯</div>
                    <h3>Marketing và quảng cáo</h3>
                    <p>Tăng doanh số với các công cụ marketing</p>
                    <ul class="resource-links">
                        <li><a href="#marketing-1">Quảng cáo sản phẩm</a></li>
                        <li><a href="#marketing-2">Chương trình khuyến mãi</a></li>
                        <li><a href="#marketing-3">Email marketing</a></li>
                        <li><a href="#marketing-4">Social media</a></li>
                    </ul>
                </div>
                
                <div class="resource-card">
                    <div class="resource-icon">⚖️</div>
                    <h3>Chính sách và quy định</h3>
                    <p>Hiểu rõ các chính sách và quy định dành cho người bán</p>
                    <ul class="resource-links">
                        <li><a href="#policy-1">Điều khoản người bán</a></li>
                        <li><a href="#policy-2">Chính sách hoa hồng</a></li>
                        <li><a href="#policy-3">Quy định sản phẩm</a></li>
                        <li><a href="#policy-4">Xử lý tranh chấp</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Seller FAQ -->
    <section class="seller-faq" aria-labelledby="seller-faq-title">
        <div class="container">
            <h2 id="seller-faq-title" class="section-title">Câu hỏi thường gặp cho người bán</h2>
            <div class="faq-categories">
                <button class="faq-category-btn active" data-category="registration">Đăng ký</button>
                <button class="faq-category-btn" data-category="products">Sản phẩm</button>
                <button class="faq-category-btn" data-category="orders">Đơn hàng</button>
                <button class="faq-category-btn" data-category="payments">Thanh toán</button>
                <button class="faq-category-btn" data-category="policies">Chính sách</button>
            </div>
            
            <div class="faq-content">
                <!-- Registration FAQ -->
                <div class="faq-category" data-category="registration">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Làm thế nào để đăng ký trở thành người bán?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Để đăng ký trở thành người bán:</p>
                            <ol>
                                <li>Truy cập trang đăng ký người bán</li>
                                <li>Điền thông tin kinh doanh</li>
                                <li>Upload giấy phép kinh doanh (nếu có)</li>
                                <li>Xác minh danh tính</li>
                                <li>Chờ phê duyệt từ Bookverse</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Thời gian phê duyệt tài khoản người bán là bao lâu?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Thời gian phê duyệt thường là 1-3 ngày làm việc. Chúng tôi sẽ gửi email thông báo kết quả phê duyệt.</p>
                        </div>
                    </div>
                </div>
                
                <!-- Products FAQ -->
                <div class="faq-category" data-category="products" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Loại sách nào được phép bán trên Bookverse?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Bạn có thể bán:</p>
                            <ul>
                                <li>Sách mới và sách cũ</li>
                                <li>Sách giáo khoa, tham khảo</li>
                                <li>Tiểu thuyết, truyện</li>
                                <li>Sách chuyên ngành</li>
                                <li>Tạp chí, báo</li>
                            </ul>
                            <p>Không được bán sách vi phạm bản quyền, nội dung không phù hợp.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Làm thế nào để tối ưu hóa danh sách sản phẩm?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Để tối ưu hóa danh sách sản phẩm:</p>
                            <ul>
                                <li>Viết tiêu đề rõ ràng, hấp dẫn</li>
                                <li>Mô tả chi tiết sản phẩm</li>
                                <li>Upload hình ảnh chất lượng cao</li>
                                <li>Đặt giá cạnh tranh</li>
                                <li>Sử dụng từ khóa phù hợp</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Orders FAQ -->
                <div class="faq-category" data-category="orders" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Làm thế nào để xử lý đơn hàng?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Quy trình xử lý đơn hàng:</p>
                            <ol>
                                <li>Nhận thông báo đơn hàng mới</li>
                                <li>Kiểm tra thông tin đơn hàng</li>
                                <li>Xác nhận đơn hàng</li>
                                <li>Đóng gói sản phẩm</li>
                                <li>Giao cho đơn vị vận chuyển</li>
                                <li>Cập nhật trạng thái giao hàng</li>
                            </ol>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Thời gian xử lý đơn hàng là bao lâu?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Thời gian xử lý đơn hàng:</p>
                            <ul>
                                <li>Xác nhận đơn hàng: 24 giờ</li>
                                <li>Đóng gói và giao hàng: 1-2 ngày</li>
                                <li>Tổng thời gian: 2-3 ngày</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Payments FAQ -->
                <div class="faq-category" data-category="payments" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Khi nào tôi nhận được thanh toán?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Thanh toán được chuyển vào tài khoản ngân hàng của bạn:</p>
                            <ul>
                                <li>Sau khi giao hàng thành công</li>
                                <li>Trong vòng 3-5 ngày làm việc</li>
                                <li>Trừ phí hoa hồng và phí dịch vụ</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Phí hoa hồng được tính như thế nào?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Phí hoa hồng được tính theo tỷ lệ:</p>
                            <ul>
                                <li>Sách mới: 5% giá trị đơn hàng</li>
                                <li>Sách cũ: 3% giá trị đơn hàng</li>
                                <li>Phí xử lý: 2,000đ/đơn hàng</li>
                                <li>Phí rút tiền: 1,000đ/giao dịch</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Policies FAQ -->
                <div class="faq-category" data-category="policies" style="display: none;">
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Chính sách đổi trả cho người bán?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Khi khách hàng yêu cầu đổi trả:</p>
                            <ul>
                                <li>Người bán chịu trách nhiệm xử lý</li>
                                <li>Kiểm tra tình trạng sản phẩm</li>
                                <li>Hoàn tiền hoặc đổi sản phẩm khác</li>
                                <li>Chịu phí vận chuyển đổi trả</li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <button class="faq-question" aria-expanded="false">
                            <span>Điều gì xảy ra nếu vi phạm chính sách?</span>
                            <span class="faq-icon">+</span>
                        </button>
                        <div class="faq-answer">
                            <p>Các hình thức xử phạt:</p>
                            <ul>
                                <li>Cảnh báo lần đầu</li>
                                <li>Tạm khóa tài khoản</li>
                                <li>Khóa vĩnh viễn</li>
                                <li>Không hoàn phí đã nộp</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Support Contact -->
    <section class="support-contact" aria-labelledby="support-contact-title">
        <div class="container">
            <h2 id="support-contact-title" class="section-title">Cần hỗ trợ thêm?</h2>
            <p class="section-subtitle">Đội ngũ hỗ trợ người bán luôn sẵn sàng giúp đỡ bạn</p>
            
            <div class="support-options">
                <div class="support-option">
                    <div class="support-icon">📧</div>
                    <h3>Email hỗ trợ</h3>
                    <p>Gửi email cho đội ngũ hỗ trợ người bán</p>
                    <a href="mailto:seller-support@bookverse.vn" class="support-link">seller-support@bookverse.vn</a>
                </div>
                
                <div class="support-option">
                    <div class="support-icon">📞</div>
                    <h3>Hotline người bán</h3>
                    <p>Gọi trực tiếp cho bộ phận hỗ trợ</p>
                    <a href="tel:19001234" class="support-link">1900 1234 (ext. 3)</a>
                </div>
                
                <div class="support-option">
                    <div class="support-icon">💬</div>
                    <h3>Chat trực tuyến</h3>
                    <p>Chat với chuyên viên hỗ trợ</p>
                    <button class="support-link chat-btn">Bắt đầu chat</button>
                </div>
                
                <div class="support-option">
                    <div class="support-icon">📅</div>
                    <h3>Đặt lịch tư vấn</h3>
                    <p>Đặt lịch tư vấn 1-1 với chuyên gia</p>
                    <button class="support-link consultation-btn">Đặt lịch</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Success Stories -->
    <section class="success-stories" aria-labelledby="success-stories-title">
        <div class="container">
            <h2 id="success-stories-title" class="section-title">Câu chuyện thành công</h2>
            <div class="stories-grid">
                <div class="story-card">
                    <div class="story-avatar">
                        <img src="assets/images/default-avatar.svg" alt="Nguyễn Văn A">
                    </div>
                    <div class="story-content">
                        <h3>Nguyễn Văn A</h3>
                        <p class="story-role">Người bán sách giáo khoa</p>
                        <p class="story-quote">"Bookverse giúp tôi bán được 500 cuốn sách trong tháng đầu tiên. Hệ thống dễ sử dụng và hỗ trợ rất tốt."</p>
                        <div class="story-stats">
                            <span class="stat">500+ sản phẩm</span>
                            <span class="stat">4.9★ đánh giá</span>
                        </div>
                    </div>
                </div>
                
                <div class="story-card">
                    <div class="story-avatar">
                        <img src="assets/images/default-avatar.svg" alt="Trần Thị B">
                    </div>
                    <div class="story-content">
                        <h3>Trần Thị B</h3>
                        <p class="story-role">Người bán sách cũ</p>
                        <p class="story-quote">"Từ một người bán nhỏ lẻ, giờ tôi đã có cửa hàng online ổn định với doanh thu 20 triệu/tháng."</p>
                        <div class="story-stats">
                            <span class="stat">1,000+ sản phẩm</span>
                            <span class="stat">20M VND/tháng</span>
                        </div>
                    </div>
                </div>
                
                <div class="story-card">
                    <div class="story-avatar">
                        <img src="assets/images/default-avatar.svg" alt="Lê Văn C">
                    </div>
                    <div class="story-content">
                        <h3>Lê Văn C</h3>
                        <p class="story-role">Nhà sách online</p>
                        <p class="story-quote">"Bookverse là nền tảng tốt nhất để mở rộng kinh doanh sách. Tôi đã tăng doanh số 300% sau 6 tháng."</p>
                        <div class="story-stats">
                            <span class="stat">2,000+ sản phẩm</span>
                            <span class="stat">300% tăng trưởng</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<style>
/* Seller Support Page Styles */
.main p, .main li, .main a { color: #1a1a1a !important; }
.main a.support-link { color: #ffffff !important; }
.seller-hero {
    background: linear-gradient(135deg, var(--success-color) 0%, var(--primary) 100%);
    color: white;
    padding: 4rem 0 2rem;
    text-align: center;
}

.seller-hero .hero-title {
    font-size: var(--text-3xl);
    margin-bottom: 1rem;
}

.seller-hero .hero-subtitle {
    font-size: var(--text-lg);
    opacity: 0.9;
    margin-bottom: 2rem;
}

.hero-stats {
    display: flex;
    justify-content: center;
    gap: 3rem;
    margin-top: 2rem;
}

.stat-item {
    text-align: center;
}

.stat-number {
    display: block;
    font-size: var(--text-2xl);
    font-weight: 700;
    margin-bottom: 0.5rem;
    color: white;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
}

.stat-label {
    font-size: var(--text-sm);
    opacity: 1;
    color: white;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
}

.quick-actions {
    padding: 4rem 0;
    background: var(--bg-secondary);
}

.actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.action-card {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    text-decoration: none;
    color: inherit;
    transition: var(--transition-normal);
    text-align: center;
}

.action-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
    color: inherit;
}

.action-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.action-card h3 {
    font-size: var(--text-xl);
    margin-bottom: 0.5rem;
    color: #1a1a1a !important;
    font-weight: 700;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.action-card p {
    color: #2d3748 !important;
    line-height: 1.6;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.getting-started {
    padding: 4rem 0;
}

.steps-wrapper {
    max-width: 800px;
    margin: 0 auto;
}

.steps-timeline {
    position: relative;
}

.steps-timeline::before {
    content: '';
    position: absolute;
    left: 2rem;
    top: 0;
    bottom: 0;
    width: 2px;
    background: var(--border-color);
}

.step-item {
    display: flex;
    align-items: flex-start;
    margin-bottom: 3rem;
    position: relative;
}

.step-number {
    width: 4rem;
    height: 4rem;
    background: var(--primary);
    color: white;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: var(--text-xl);
    font-weight: 700;
    margin-right: 2rem;
    flex-shrink: 0;
    position: relative;
    z-index: 1;
}

.step-content {
    flex: 1;
    background: white;
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
}

.step-content h3 {
    font-size: var(--text-xl);
    margin-bottom: 1rem;
    color: #1a1a1a !important;
    font-weight: 700;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.step-content p {
    color: #2d3748 !important;
    line-height: 1.6;
    margin-bottom: 1.5rem;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.seller-resources {
    padding: 4rem 0;
    background: var(--bg-secondary);
}

.resources-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.resource-card {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    transition: var(--transition-normal);
}

.resource-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.resource-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.resource-card h3 {
    font-size: var(--text-xl);
    margin-bottom: 1rem;
    color: #1a1a1a !important;
    font-weight: 700;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.resource-card p {
    color: #2d3748 !important;
    margin-bottom: 1.5rem;
    line-height: 1.6;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.resource-links {
    list-style: none;
    padding: 0;
}

.resource-links li {
    margin-bottom: 0.5rem;
}

.resource-links a {
    color: var(--primary);
    text-decoration: none;
    font-size: var(--text-sm);
    transition: var(--transition-fast);
    font-weight: 500;
}

.resource-links a:hover {
    text-decoration: underline;
}

.seller-faq {
    padding: 4rem 0;
}

.faq-categories {
    display: flex;
    justify-content: center;
    gap: 1rem;
    margin: 2rem 0;
    flex-wrap: wrap;
}

.faq-category-btn {
    padding: 0.75rem 1.5rem;
    border: 2px solid var(--border-color);
    background: white;
    border-radius: var(--radius-full);
    cursor: pointer;
    transition: var(--transition-fast);
    font-weight: 500;
}

.faq-category-btn.active,
.faq-category-btn:hover {
    border-color: var(--success-color);
    background: var(--success-color);
    color: white;
}

.faq-content {
    max-width: 800px;
    margin: 0 auto;
}

.faq-item {
    background: white;
    margin-bottom: 1rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    overflow: hidden;
}

.faq-question {
    width: 100%;
    padding: 1.5rem;
    background: none;
    border: none;
    text-align: left;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: var(--text-lg);
    font-weight: 700;
    color: #1a1a1a !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
    transition: var(--transition-fast);
}

.faq-question:hover {
    background: var(--bg-tertiary);
}

.faq-icon {
    font-size: 1.5rem;
    transition: var(--transition-fast);
}

.faq-question[aria-expanded="true"] .faq-icon {
    transform: rotate(45deg);
}

.faq-answer {
    padding: 0 1.5rem 1.5rem;
    color: #2d3748 !important;
    line-height: 1.6;
    display: none;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.faq-answer.show {
    display: block;
}

.faq-answer ol,
.faq-answer ul {
    margin: 1rem 0;
    padding-left: 1.5rem;
}

.faq-answer li {
    margin-bottom: 0.5rem;
}

.support-contact {
    padding: 4rem 0;
    background: var(--bg-secondary);
}

.support-options {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.support-option {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    text-align: center;
    transition: var(--transition-normal);
}

.support-option:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.support-icon {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.support-option h3 {
    font-size: var(--text-xl);
    margin-bottom: 0.5rem;
    color: #1a1a1a !important;
    font-weight: 700;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.support-option p {
    color: #2d3748 !important;
    margin-bottom: 1rem;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.support-link {
    color: #1a1a1a !important;
    text-decoration: none;
    font-weight: 700;
    font-size: var(--text-lg);
    background: var(--primary);
    color: white !important;
    padding: 0.5rem 1rem;
    border-radius: var(--radius-md);
    display: inline-block;
    transition: all 0.3s ease;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
}

.support-link:hover {
    background: var(--primary-hover);
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    text-decoration: none;
}

.chat-btn,
.consultation-btn {
    background: var(--success-color);
    color: white;
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: var(--radius-md);
    cursor: pointer;
    font-weight: 500;
    transition: var(--transition-fast);
}

.chat-btn:hover,
.consultation-btn:hover {
    background: #059669;
    text-decoration: none;
}

.success-stories {
    padding: 4rem 0;
}

.stories-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.story-card {
    background: white;
    padding: 2rem;
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-sm);
    transition: var(--transition-normal);
}

.story-card:hover {
    transform: translateY(-4px);
    box-shadow: var(--shadow-lg);
}

.story-avatar {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    overflow: hidden;
    margin-bottom: 1rem;
}

.story-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.story-content h3 {
    font-size: var(--text-lg);
    margin-bottom: 0.5rem;
    color: #1a1a1a !important;
    font-weight: 700;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.story-role {
    color: #2d3748 !important;
    font-size: var(--text-sm);
    margin-bottom: 1rem;
    font-weight: 600;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.story-quote {
    color: #2d3748 !important;
    line-height: 1.6;
    margin-bottom: 1rem;
    font-style: italic;
    font-weight: 500;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.story-stats {
    display: flex;
    gap: 1rem;
}

.story-stats .stat {
    background: var(--primary);
    color: white;
    padding: 0.5rem 1rem;
    border-radius: var(--radius-full);
    font-size: var(--text-sm);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
    transition: all 0.3s ease;
}

.story-stats .stat:hover {
    background: var(--primary-hover);
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

/* Enhanced readability */
.action-card h3,
.step-content h3,
.resource-card h3,
.faq-question,
.support-option h3,
.story-content h3 {
    text-shadow: 0 1px 1px rgba(0,0,0,0.1);
}

/* Better step styling */
.step-number {
    font-weight: 700;
    text-shadow: 0 1px 2px rgba(0,0,0,0.2);
}

/* Enhanced buttons */
.btn-primary,
.btn-outline {
    font-weight: 600;
    transition: all 0.3s ease;
}

.btn-primary:hover,
.btn-outline:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

/* Better category buttons */
.faq-category-btn {
    font-weight: 700;
    transition: all 0.3s ease;
    color: #2d3748 !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

/* Section titles */
.section-title {
    color: #dc2626 !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    border-bottom: 3px solid #dc2626;
    padding-bottom: 0.5rem;
    display: inline-block;
    margin-bottom: 2rem;
    text-align: center;
    width: 100%;
}

/* Hero section text */
.hero-title {
    color: white !important;
    font-weight: 800;
    text-shadow: 0 3px 6px rgba(0,0,0,0.3);
}

.hero-subtitle {
    color: rgba(255,255,255,0.95) !important;
    font-weight: 600;
    text-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

/* Step numbers */
.step-number {
    color: white !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

/* Contact information */
.support-option .contact-info {
    color: #1a1a1a !important;
    font-weight: 700;
    font-size: var(--text-lg);
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
    background: var(--primary);
    color: white !important;
    padding: 0.75rem 1.5rem;
    border-radius: var(--radius-md);
    display: inline-block;
    margin-top: 1rem;
    transition: all 0.3s ease;
}

.support-option .contact-info:hover {
    background: var(--primary-hover);
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

/* Support section titles */
.support-section h2 {
    color: #dc2626 !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    border-bottom: 3px solid #dc2626;
    padding-bottom: 0.5rem;
    display: inline-block;
    margin-bottom: 2rem;
    text-align: center;
    width: 100%;
}

/* Getting started section */
.getting-started h2 {
    color: #dc2626 !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    border-bottom: 3px solid #dc2626;
    padding-bottom: 0.5rem;
    display: inline-block;
    margin-bottom: 2rem;
    text-align: center;
    width: 100%;
}

/* Resource links */
.resource-links li {
    margin-bottom: 0.75rem;
}

.resource-links a {
    color: #1a1a1a !important;
    text-decoration: none;
    font-weight: 600;
    font-size: var(--text-base);
    padding: 0.5rem 1rem;
    background: var(--bg-tertiary);
    border-radius: var(--radius-md);
    display: inline-block;
    transition: all 0.3s ease;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

.resource-links a:hover {
    background: var(--primary);
    color: white !important;
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
}

/* List items in cards */
.action-card ul li,
.step-content ul li,
.resource-card ul li {
    color: #2d3748 !important;
    font-weight: 500;
    margin-bottom: 0.5rem;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

/* Card descriptions */
.action-card p,
.step-content p,
.resource-card p,
.support-option p {
    color: #2d3748 !important;
    font-weight: 500;
    line-height: 1.6;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

/* Success stories section */
.success-stories h2 {
    color: #dc2626 !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    border-bottom: 3px solid #dc2626;
    padding-bottom: 0.5rem;
    display: inline-block;
    margin-bottom: 2rem;
    text-align: center;
    width: 100%;
}

/* Story stats */
.story-stats {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
}

.story-stat {
    text-align: center;
    padding: 0.5rem;
    background: var(--bg-tertiary);
    border-radius: var(--radius-md);
    flex: 1;
}

.story-stat-number {
    display: block;
    font-size: var(--text-xl);
    font-weight: 800;
    color: var(--primary) !important;
    text-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.story-stat-label {
    font-size: var(--text-sm);
    color: #2d3748 !important;
    font-weight: 600;
    text-shadow: 0 1px 2px rgba(0,0,0,0.05);
}

/* FAQ section */
.faq-section h2 {
    color: #dc2626 !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    border-bottom: 3px solid #dc2626;
    padding-bottom: 0.5rem;
    display: inline-block;
    margin-bottom: 2rem;
    text-align: center;
    width: 100%;
}

/* Responsive improvements */
@media (max-width: 768px) {
    .hero-stats {
        flex-direction: column;
        gap: 1.5rem;
    }
    
    .actions-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
    
    .story-stats {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .section-title {
        font-size: var(--text-2xl);
        text-align: center;
        width: 100%;
    }
    
    .hero-title {
        font-size: var(--text-3xl);
    }
    
    .hero-subtitle {
        font-size: var(--text-base);
    }
}

/* Better alignment for all sections */
.quick-actions,
.getting-started,
.seller-resources,
.support-section,
.success-stories,
.faq-section {
    text-align: center;
}

.quick-actions .section-title,
.getting-started .section-title,
.seller-resources .section-title,
.support-section .section-title,
.success-stories .section-title,
.faq-section .section-title {
    margin: 0 auto 2rem;
}

/* All h2 elements should be red and centered */
h2 {
    color: #dc2626 !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    border-bottom: 3px solid #dc2626;
    padding-bottom: 0.5rem;
    display: inline-block;
    margin-bottom: 2rem;
    text-align: center;
    width: 100%;
}

/* Specific styling for different h2 contexts */
.quick-actions h2,
.getting-started h2,
.seller-resources h2,
.support-section h2,
.success-stories h2,
.faq-section h2 {
    color: #dc2626 !important;
    font-weight: 800;
    text-shadow: 0 2px 4px rgba(220, 38, 38, 0.3);
    border-bottom: 3px solid #dc2626;
    padding-bottom: 0.5rem;
    display: inline-block;
    margin-bottom: 2rem;
    text-align: center;
    width: 100%;
}

.faq-category-btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    color: white;
}

.faq-category-btn.active {
    color: white;
    background: var(--success-color);
    border-color: var(--success-color);
}

/* Enhanced support options */
.support-option {
    border: 1px solid #e5e7eb;
    transition: all 0.3s ease;
}

.support-option:hover {
    border-color: var(--primary);
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
}

/* Responsive Design */
@media (max-width: 768px) {
    .hero-stats {
        flex-direction: column;
        gap: 1rem;
    }
    
    .steps-timeline::before {
        display: none;
    }
    
    .step-item {
        flex-direction: column;
        text-align: center;
    }
    
    .step-number {
        margin: 0 auto 1rem;
    }
    
    .faq-categories {
        flex-direction: column;
        align-items: center;
    }
    
    .faq-category-btn {
        width: 200px;
    }
    
    .actions-grid,
    .resources-grid,
    .support-options,
    .stories-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // FAQ functionality
    const faqQuestions = document.querySelectorAll('.faq-question');
    const faqCategoryBtns = document.querySelectorAll('.faq-category-btn');
    const faqCategories = document.querySelectorAll('.faq-category');
    
    // Toggle FAQ answers
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            const answer = this.nextElementSibling;
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            
            // Close all other FAQs in the same category
            const category = this.closest('.faq-category');
            const categoryQuestions = category.querySelectorAll('.faq-question');
            categoryQuestions.forEach(q => {
                q.setAttribute('aria-expanded', 'false');
                q.nextElementSibling.classList.remove('show');
            });
            
            // Toggle current FAQ
            if (!isExpanded) {
                this.setAttribute('aria-expanded', 'true');
                answer.classList.add('show');
            }
        });
    });
    
    // FAQ category switching
    faqCategoryBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const category = this.dataset.category;
            
            // Update active button
            faqCategoryBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Show/hide categories
            faqCategories.forEach(cat => {
                if (cat.dataset.category === category) {
                    cat.style.display = 'block';
                } else {
                    cat.style.display = 'none';
                }
            });
        });
    });
    
    // Chat and consultation buttons
    const chatBtn = document.querySelector('.chat-btn');
    const consultationBtn = document.querySelector('.consultation-btn');
    
    if (chatBtn) {
        chatBtn.addEventListener('click', function() {
            alert('Tính năng chat trực tuyến sẽ được triển khai sớm!');
        });
    }
    
    if (consultationBtn) {
        consultationBtn.addEventListener('click', function() {
            alert('Tính năng đặt lịch tư vấn sẽ được triển khai sớm!');
        });
    }
    
    // Smooth scrolling for resource links
    const resourceLinks = document.querySelectorAll('.resource-links a');
    resourceLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            // This would scroll to the specific guide section
            console.log('Navigate to:', this.textContent);
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>
