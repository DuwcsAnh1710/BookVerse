<?php
/**
 * Simple Navigation System for Bookverse
 */

// Include safe auth checker (no redirects)
require_once __DIR__.'/auth-check-safe.php';

// Determine current page context
$currentPath = $_SERVER['REQUEST_URI'];
$isAuthPage = strpos($currentPath, '/auth/') !== false;
$isSellerPage = strpos($currentPath, '/seller/') !== false;
$isAdminPage = strpos($currentPath, '/admin/') !== false;
$isAccountPage = strpos($currentPath, '/account/') !== false;
$isProductsPage = strpos($currentPath, '/products/') !== false;
$isPublicPage = !$isAuthPage && !$isSellerPage && !$isAdminPage && !$isAccountPage && !$isProductsPage;

// Check authentication status (safe - no redirects)
$isAuthenticated = isAuthenticatedSafe();
$userRole = getCurrentUserRoleSafe();
$currentUser = getCurrentUserSafe();

// Determine navigation type
$navType = 'public';
if ($isSellerPage) $navType = 'seller';
if ($isAdminPage) $navType = 'admin';
if ($isAccountPage) $navType = 'account';
if ($isAuthPage) $navType = 'auth';
if ($isProductsPage) $navType = 'public'; // Products pages use public navigation
?>

<!-- Simple Navigation Header -->
<header class="header">
    <div class="container">
        <div class="header-content">
            <!-- Logo -->
            <div class="logo">
                <a href="<?php 
                    if ($navType === 'seller' || $navType === 'admin' || $navType === 'account') {
                        echo '../../index.php';
                    } elseif ($isProductsPage) {
                        echo '../../index.php';
                    } else {
                        echo 'index.php';
                    }
                ?>" aria-label="Bookverse - Trang chủ">
                    <img src="<?php echo $navType === 'seller' || $navType === 'admin' || $navType === 'account' ? '../../' : ($isProductsPage ? '../../' : ''); ?>assets/images/logo-text-new.svg" 
                         alt="Bookverse Logo" class="logo-img" width="150" height="40">
                </a>
            </div>

            <!-- Navigation -->
            <nav class="nav" role="navigation" aria-label="Menu chính">
                <ul class="nav-list">
                    <?php if ($navType === 'public'): ?>
                        <li class="nav-item">
                            <a href="<?php echo $isPublicPage ? 'index.php' : ($isProductsPage ? '../../index.php' : '../index.php'); ?>" class="nav-link">Trang chủ</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo $isPublicPage ? 'pages/products/list.php' : ($isProductsPage ? 'list.php' : '../pages/products/list.php'); ?>" class="nav-link">Sản phẩm</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo $isPublicPage ? 'about.php' : ($isProductsPage ? '../../about.php' : '../about.php'); ?>" class="nav-link">Giới thiệu</a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo $isPublicPage ? 'blog.php' : ($isProductsPage ? '../../blog.php' : '../blog.php'); ?>" class="nav-link">Blog</a>
                        </li>
                    <?php elseif ($navType === 'seller'): ?>
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a href="products.php" class="nav-link">Sản phẩm</a>
                        </li>
                        <li class="nav-item">
                            <a href="orders.php" class="nav-link">Đơn hàng</a>
                        </li>
                        <li class="nav-item">
                            <a href="settings.php" class="nav-link">Cài đặt</a>
                        </li>
                        <li class="nav-item">
                            <a href="bank-account.php" class="nav-link">Ngân hàng</a>
                        </li>
                    <?php elseif ($navType === 'admin'): ?>
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">Dashboard</a>
                        </li>
                        <li class="nav-item">
                            <a href="users.php" class="nav-link">Người dùng</a>
                        </li>
                        <li class="nav-item">
                            <a href="products.php" class="nav-link">Sản phẩm</a>
                        </li>
                        <li class="nav-item">
                            <a href="orders.php" class="nav-link">Đơn hàng</a>
                        </li>
                        <li class="nav-item">
                            <a href="payments.php" class="nav-link">Thanh toán</a>
                        </li>
                    <?php elseif ($navType === 'account'): ?>
                        <li class="nav-item">
                            <a href="profile.php" class="nav-link">Hồ sơ</a>
                        </li>
                        <li class="nav-item">
                            <a href="orders.php" class="nav-link">Đơn hàng</a>
                        </li>
                        <li class="nav-item">
                            <a href="wishlist.php" class="nav-link">Yêu thích</a>
                        </li>
                        <li class="nav-item">
                            <a href="wallet.php" class="nav-link">Ví điện tử</a>
                        </li>
                    <?php elseif ($navType === 'auth'): ?>
                        <li class="nav-item">
                            <a href="../index.php" class="nav-link">Trang chủ</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>

            <!-- User Actions -->
            <div class="user-actions">
                <?php if ($navType === 'public' || $navType === 'account'): ?>
                <a href="<?php echo $isPublicPage ? 'pages/cart/cart.php' : ($isProductsPage ? '../../pages/cart/cart.php' : '../pages/cart/cart.php'); ?>" class="cart-btn" aria-label="Giỏ hàng">
                    <span class="cart-icon">🛒</span>
                    <span class="cart-count" aria-live="polite">0</span>
                </a>
                <?php endif; ?>

                <div class="user-menu">
                    <button class="user-btn" id="userBtn" type="button" aria-label="Menu tài khoản" aria-expanded="false" aria-controls="userDropdown">
                        <span class="user-icon">👤</span>
                        <span id="userDisplayName">Tài khoản</span>
                    </button>
                    <div class="user-dropdown" id="userDropdown" role="menu" aria-hidden="true">
                        <?php if ($navType === 'public'): ?>
                            <?php if ($isAuthenticated): ?>
                                <a href="<?php echo $isPublicPage ? 'pages/account/profile.php' : ($isProductsPage ? '../../pages/account/profile.php' : '../pages/account/profile.php'); ?>" class="dropdown-link" role="menuitem">Hồ sơ</a>
                                <a href="<?php echo $isPublicPage ? 'pages/account/orders.php' : ($isProductsPage ? '../../pages/account/orders.php' : '../pages/account/orders.php'); ?>" class="dropdown-link" role="menuitem">Đơn hàng</a>
                                <a href="<?php echo $isPublicPage ? 'pages/account/wishlist.php' : ($isProductsPage ? '../../pages/account/wishlist.php' : '../pages/account/wishlist.php'); ?>" class="dropdown-link" role="menuitem">Yêu thích</a>
                                <?php if ($userRole === 'admin'): ?>
                                    <a href="<?php echo $isPublicPage ? 'pages/admin/dashboard.php' : ($isProductsPage ? '../../pages/admin/dashboard.php' : '../pages/admin/dashboard.php'); ?>" class="dropdown-link" role="menuitem">Admin</a>
                                <?php elseif ($userRole === 'seller'): ?>
                                    <a href="<?php echo $isPublicPage ? 'pages/seller/dashboard.php' : ($isProductsPage ? '../../pages/seller/dashboard.php' : '../pages/seller/dashboard.php'); ?>" class="dropdown-link" role="menuitem">Seller</a>
                                <?php endif; ?>
                                <a href="#" class="dropdown-link" role="menuitem" onclick="logout()">Đăng xuất</a>
                            <?php else: ?>
                                <a href="<?php echo $isPublicPage ? 'pages/auth/login.php' : ($isProductsPage ? '../../pages/auth/login.php' : '../pages/auth/login.php'); ?>" class="dropdown-link" role="menuitem">Đăng nhập</a>
                                <a href="<?php echo $isPublicPage ? 'pages/auth/register.php' : ($isProductsPage ? '../../pages/auth/register.php' : '../pages/auth/register.php'); ?>" class="dropdown-link" role="menuitem">Đăng ký</a>
                            <?php endif; ?>
                        <?php elseif ($navType === 'account'): ?>
                            <a href="profile.php" class="dropdown-link" role="menuitem">Hồ sơ</a>
                            <a href="orders.php" class="dropdown-link" role="menuitem">Đơn hàng</a>
                            <a href="wishlist.php" class="dropdown-link" role="menuitem">Yêu thích</a>
                            <a href="wallet.php" class="dropdown-link" role="menuitem">Ví điện tử</a>
                            <a href="../index.php" class="dropdown-link" role="menuitem">Về trang chủ</a>
                            <a href="#" class="dropdown-link" role="menuitem" onclick="logout()">Đăng xuất</a>
                        <?php elseif ($navType === 'seller'): ?>
                            <a href="dashboard.php" class="dropdown-link" role="menuitem">Dashboard</a>
                            <a href="../index.php" class="dropdown-link" role="menuitem">Về trang chủ</a>
                            <a href="#" class="dropdown-link" role="menuitem" onclick="logout()">Đăng xuất</a>
                        <?php elseif ($navType === 'admin'): ?>
                            <a href="dashboard.php" class="dropdown-link" role="menuitem">Dashboard</a>
                            <a href="../index.php" class="dropdown-link" role="menuitem">Về trang chủ</a>
                            <a href="#" class="dropdown-link" role="menuitem" onclick="logout()">Đăng xuất</a>
                        <?php elseif ($navType === 'auth'): ?>
                            <a href="login.php" class="dropdown-link" role="menuitem">Đăng nhập</a>
                            <a href="register.php" class="dropdown-link" role="menuitem">Đăng ký</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>

<script>
// User menu toggle
document.addEventListener('DOMContentLoaded', function() {
    // Update user display name from localStorage
    updateUserDisplayName();
    
    // Highlight active navigation item
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        const href = link.getAttribute('href');
        if (href && currentPath.endsWith(href)) {
            link.style.fontWeight = '600';
            link.style.color = 'var(--primary-color, #6366f1)';
            link.style.borderBottom = '2px solid var(--primary-color, #6366f1)';
        }
    });

    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');
    const loginUrl = '<?php echo $isPublicPage 
        ? 'pages/auth/login.php' 
        : ($isProductsPage 
            ? '../../pages/auth/login.php' 
            : (($navType === 'account' || $navType === 'seller' || $navType === 'admin') 
                ? '../auth/login.php' 
                : '../pages/auth/login.php')); ?>';

    if (userBtn && userDropdown) {
        console.log('User menu elements found:', { userBtn, userDropdown });
        
        // Toggle on click
        userBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const isExpanded = userBtn.getAttribute('aria-expanded') === 'true';
            console.log('User button clicked, isExpanded:', isExpanded);
            
            // Toggle dropdown visibility
            if (isExpanded) {
                userBtn.setAttribute('aria-expanded', 'false');
                userDropdown.setAttribute('aria-hidden', 'true');
                userDropdown.classList.remove('show');
                userDropdown.style.display = 'none';
                console.log('Dropdown hidden');
            } else {
                userBtn.setAttribute('aria-expanded', 'true');
                userDropdown.setAttribute('aria-hidden', 'false');
                userDropdown.classList.add('show');
                userDropdown.style.display = 'block';
                console.log('Dropdown shown, classes:', userDropdown.className);
            }
        }, true); // Use capture phase
        
        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!userBtn.contains(e.target) && !userDropdown.contains(e.target)) {
                userBtn.setAttribute('aria-expanded', 'false');
                userDropdown.setAttribute('aria-hidden', 'true');
                userDropdown.classList.remove('show');
            }
        });
        
        // Close dropdown when pressing Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                userBtn.setAttribute('aria-expanded', 'false');
                userDropdown.setAttribute('aria-hidden', 'true');
                userDropdown.classList.remove('show');
            }
        });
    }
});

// Update user display name from localStorage
function updateUserDisplayName() {
    try {
        const token = localStorage.getItem('bookverse_token');
        const userDisplayNameEl = document.getElementById('userDisplayName');
        
        if (!userDisplayNameEl) return;
        
        if (token) {
            // Decode JWT token to get user info
            const payload = JSON.parse(atob(token.split('.')[1]));
            const username = payload.username || payload.email || 'User';
            const role = payload.role || 'user';
            
            // Get display name with role badge
            let displayName = username;
            
            // Add role badge for seller and admin
            if (role === 'seller') {
                displayName = `${username} 🏪`;
            } else if (role === 'admin') {
                displayName = `${username} 👑`;
            }
            
            // Update display name
            userDisplayNameEl.textContent = displayName;
            
            // Also sync token to cookie for PHP (if needed)
            document.cookie = `bookverse_token=${token}; path=/; max-age=${24 * 60 * 60}`;
        } else {
            userDisplayNameEl.textContent = 'Tài khoản';
        }
    } catch (error) {
        console.error('Failed to update user display name:', error);
        const userDisplayNameEl = document.getElementById('userDisplayName');
        if (userDisplayNameEl) {
            userDisplayNameEl.textContent = 'Tài khoản';
        }
    }
}

// Logout function
function logout() {
    if (confirm('Bạn có chắc chắn muốn đăng xuất?')) {
        // Clear all tokens
        localStorage.removeItem('bookverse_token');
        localStorage.removeItem('bookverse_user');
        sessionStorage.removeItem('bookverse_token');
        document.cookie = 'bookverse_token=; path=/; max-age=0';
        
        // Redirect to home
        const baseUrl = window.location.origin + '/Bookverse/frontend';
        window.location.href = baseUrl + '/index.php';
    }
}
</script>
