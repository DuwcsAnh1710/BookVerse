<?php /* Shared footer */ ?>

<!-- Core Scripts (loaded on all pages in correct order) -->
<script src="<?php echo $path ?? ''; ?>assets/js/config.js"></script>
<script src="<?php echo $path ?? ''; ?>assets/js/api.js"></script>

<!-- Page-specific scripts -->
<?php if (!empty($extraJs)) { foreach ($extraJs as $js) { ?>
<script src="<?php echo $path ?? ''; ?><?php echo $js; ?>"></script>
<?php }} ?>

<!-- Main.js last to initialize after everything else -->
<script src="<?php echo $path ?? ''; ?>assets/js/main.js"></script>
</body>
</html>




