<?php 
/* Shared header with smart navigation system */
?>
<!DOCTYPE html>
<html lang="vi">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php echo isset($pageTitle) ? $pageTitle.' - ' : '';?>Bookverse</title>
	
	<!-- Favicon -->
	<link rel="icon" type="image/svg+xml" href="<?php echo $path; ?>assets/images/favicon.svg">
	<link rel="icon" type="image/x-icon" href="<?php echo $path; ?>assets/images/favicon.ico">
	<link rel="apple-touch-icon" sizes="180x180" href="<?php echo $path; ?>assets/images/favicon.svg">
	
	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer">
	<link rel="stylesheet" href="<?php 
		$path = '';
		if (strpos($_SERVER['REQUEST_URI'], '/pages/') !== false) {
			$path = '../../';
		}
		echo $path;
	?>assets/css/main.css">
	<link rel="stylesheet" href="<?php echo $path; ?>assets/css/global.css">
	<link rel="stylesheet" href="<?php echo $path; ?>assets/css/responsive.css">
	<link rel="stylesheet" href="<?php echo $path; ?>assets/css/logo.css">
	<link rel="stylesheet" href="<?php echo $path; ?>assets/css/notifications.css">
<?php if (!empty($extraCss)) { foreach ($extraCss as $css) { ?>
	<link rel="stylesheet" href="<?php echo $path; ?><?php echo $css; ?>">
<?php }} ?>
</head>
<body>
	<?php include 'navigation-simple.php'; ?>


