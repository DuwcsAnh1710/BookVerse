// Overflow Fix Script - Triệt để
(function() {
    'use strict';
    
    // Force fix overflow issues
    function fixOverflow() {
        // Remove any horizontal scroll
        document.documentElement.style.overflowX = 'hidden';
        document.body.style.overflowX = 'hidden';
        document.body.style.maxWidth = '100vw';
        document.body.style.width = '100vw';
        
        // Fix all containers
        const containers = document.querySelectorAll('.container, .account-layout, .account-content, .account-sidebar');
        containers.forEach(container => {
            container.style.maxWidth = '100%';
            container.style.overflowX = 'hidden';
            container.style.boxSizing = 'border-box';
        });
        
        // Fix all forms
        const forms = document.querySelectorAll('form, .profile-form, .preferences-form');
        forms.forEach(form => {
            form.style.maxWidth = '100%';
            form.style.overflowX = 'hidden';
        });
        
        // Fix all inputs
        const inputs = document.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.style.maxWidth = '100%';
            input.style.boxSizing = 'border-box';
        });
        
        // Fix navigation
        const nav = document.querySelector('.nav-list');
        if (nav) {
            nav.style.maxWidth = '100%';
            nav.style.overflowX = 'hidden';
            nav.style.flexWrap = 'wrap';
        }
        
        // Fix header
        const header = document.querySelector('.header');
        if (header) {
            header.style.maxWidth = '100vw';
            header.style.overflowX = 'hidden';
        }
        
        // Fix main content
        const main = document.querySelector('main');
        if (main) {
            main.style.maxWidth = '100vw';
            main.style.overflowX = 'hidden';
        }
        
        // Remove any horizontal scrollbar
        document.documentElement.style.overflowX = 'hidden';
        document.body.style.overflowX = 'hidden';
        
        // Force viewport width
        document.documentElement.style.width = '100vw';
        document.body.style.width = '100vw';
    }
    
    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', fixOverflow);
    } else {
        fixOverflow();
    }
    
    // Run on window resize
    window.addEventListener('resize', fixOverflow);
    
    // Run periodically to ensure fix
    setInterval(fixOverflow, 1000);
    
    // Force fix on any scroll
    window.addEventListener('scroll', function() {
        if (window.scrollX > 0) {
            window.scrollTo(0, window.scrollY);
        }
    });
    
    // Prevent horizontal scroll
    document.addEventListener('wheel', function(e) {
        if (e.deltaX !== 0) {
            e.preventDefault();
        }
    }, { passive: false });
    
    // Prevent horizontal scroll on touch
    document.addEventListener('touchmove', function(e) {
        if (e.touches.length > 1) {
            e.preventDefault();
        }
    }, { passive: false });
    
})();
