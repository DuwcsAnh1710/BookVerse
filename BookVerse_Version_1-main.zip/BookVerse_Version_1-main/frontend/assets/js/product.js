// Product detail rendering

document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    if (!id) return;

    const reviewsEl = document.getElementById('reviewsList');

    try {
        const res = await api.getProduct(id);
        const product = res.data.product;

        // Populate existing DOM instead of replacing markup (keeps CSS layout)
        const mainImage = document.getElementById('mainImage');
        const zoomImage = document.getElementById('zoomImage');
        const titleEl = document.getElementById('productTitle');
        const authorEl = document.getElementById('productAuthor');
        const publisherEl = document.getElementById('productPublisher');
        const categoryEl = document.getElementById('productCategory');
        const descEl = document.getElementById('productDescription');
        const currentPriceEl = document.getElementById('currentPrice');
        const originalPriceEl = document.getElementById('originalPrice');
        const discountBadgeEl = document.getElementById('discountBadge');
        const priceValueEl = document.getElementById('priceValue');
        const thumbsEl = document.getElementById('thumbnailGallery');

        const firstImage = (product.images && (product.images[0]?.url || product.images[0])) || '';
        if (mainImage) mainImage.src = firstImage || '../../assets/images/no-image.jpg';
        if (zoomImage) zoomImage.src = firstImage || '';
        if (titleEl) titleEl.textContent = product.title || '';
        if (authorEl) authorEl.textContent = product.author || 'Không rõ';
        if (publisherEl) publisherEl.textContent = product.publisher || '—';
        if (categoryEl) categoryEl.textContent = product.category?.name || product.category || '—';
        if (descEl) descEl.textContent = product.description || '';

        const hasDiscount = product.originalPrice && product.originalPrice > product.price;
        if (currentPriceEl) currentPriceEl.textContent = api.formatPrice(product.price || 0);
        if (priceValueEl) priceValueEl.textContent = api.formatPrice(product.price || 0);
        if (originalPriceEl) {
            originalPriceEl.style.display = hasDiscount ? '' : 'none';
            if (hasDiscount) originalPriceEl.textContent = api.formatPrice(product.originalPrice);
        }
        if (discountBadgeEl) {
            discountBadgeEl.style.display = hasDiscount ? '' : 'none';
            if (hasDiscount) {
                const percent = Math.round((1 - (product.price / product.originalPrice)) * 100);
                discountBadgeEl.textContent = `-${percent}%`;
            }
        }

        if (thumbsEl) {
            const images = (product.images || []).map(img => (img.url || img)).filter(Boolean);
            thumbsEl.innerHTML = images.map((url, idx) => `
                <div class="thumbnail-item ${idx === 0 ? 'active' : ''}" data-url="${url}">
                    <img src="${url}" alt="Thumb ${idx + 1}">
                </div>
            `).join('');
            thumbsEl.querySelectorAll('.thumbnail-item').forEach(item => {
                item.addEventListener('click', () => {
                    const url = item.getAttribute('data-url') || '';
                    if (mainImage) mainImage.src = url;
                    if (zoomImage) zoomImage.src = url;
                    thumbsEl.querySelectorAll('.thumbnail-item').forEach(i => i.classList.remove('active'));
                    item.classList.add('active');
                });
            });
        }

        // Image zoom
        const overlay = document.getElementById('imageZoom');
        if (overlay && mainImage && zoomImage) {
            mainImage.addEventListener('click', () => overlay.classList.add('show'));
            overlay.addEventListener('click', () => overlay.classList.remove('show'));
        }

        // Quantity and cart actions
        const qtyInput = document.getElementById('quantity');
        document.getElementById('increaseQty')?.addEventListener('click', () => {
            if (!qtyInput) return; qtyInput.value = String(Math.min(99, Number(qtyInput.value || 1) + 1));
        });
        document.getElementById('decreaseQty')?.addEventListener('click', () => {
            if (!qtyInput) return; qtyInput.value = String(Math.max(1, Number(qtyInput.value || 1) - 1));
        });
        document.getElementById('addToCartBtn')?.addEventListener('click', () => {
            const qty = Number(qtyInput?.value || 1) || 1;
            api.addToCart(product, qty);
            showToast('Đã thêm sản phẩm vào giỏ hàng', 'success');
        });
        document.getElementById('buyNowBtn')?.addEventListener('click', () => {
            const qty = Number(qtyInput?.value || 1) || 1;
            api.addToCart(product, qty);
            window.location.href = '../../pages/checkout/checkout.php';
        });
        document.getElementById('addToWishlistBtn')?.addEventListener('click', () => {
            showToast('Đã thêm vào danh sách yêu thích', 'info');
        });

        // Load reviews
        const list = await fetch(`${API_BASE_URL}/reviews/product/${id}`).then(r => r.json());
        const reviews = list?.data?.reviews || [];
        if (reviewsEl) {
            reviewsEl.innerHTML = reviews.map(rv => `
                <div class="review">
                    <div class="review-header">
                        <strong>${rv.isAnonymous ? 'Ẩn danh' : (rv.customer?.username || 'Người dùng')}</strong>
                        <span>⭐ ${rv.rating}/5</span>
                    </div>
                    <div class="review-body">${rv.title ? `<p><em>${rv.title}</em></p>` : ''}<p>${rv.comment}</p></div>
                </div>
            `).join('');
        }

        // Review form submit
        const reviewForm = document.getElementById('reviewForm');
        reviewForm?.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(reviewForm);
            const payload = {
                product: id,
                rating: Number(formData.get('rating')),
                title: formData.get('title') || undefined,
                comment: formData.get('comment')
            };
            try {
                const resCreate = await fetch(`${API_BASE_URL}/reviews`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${api.token}` },
                    body: JSON.stringify(payload)
                }).then(r => r.json());
                if (!resCreate.success) throw new Error(resCreate.message || 'Tạo đánh giá thất bại');
                alert('Đã gửi đánh giá!');
                location.reload();
            } catch (err) { api.handleError(err); }
        });
    } catch (err) {
        api.handleError(err);
    }
});


