const api = window.api;

class WishlistManager {
    constructor() {
        this.wishlistItems = [];
        this.currentView = 'grid';
        this.currentFilters = {
            search: '',
            category: '',
            sort: '-createdAt',
            page: 1,
            limit: 12
        };
        this.selectedItems = new Set();
        this.initializeEventListeners();
        this.loadWishlist();
    }

    // Initialize event listeners
    initializeEventListeners() {
        // Redirect to login if not authenticated
        if (!api.token) {
            window.location.href = '../auth/login.php';
            return;
        }

        // Load sidebar user info
        this.loadSidebarUserInfo();

        // Search functionality
        document.getElementById('wishlistSearch')?.addEventListener('input', debounce(() => {
            this.currentFilters.search = document.getElementById('wishlistSearch').value;
            this.currentFilters.page = 1;
            this.loadWishlist();
        }, 300));

        document.getElementById('searchBtn')?.addEventListener('click', () => {
            this.loadWishlist();
        });

        // Filter controls
        document.getElementById('categoryFilter')?.addEventListener('change', (e) => {
            this.currentFilters.category = e.target.value;
            this.currentFilters.page = 1;
            this.loadWishlist();
        });

        document.getElementById('sortFilter')?.addEventListener('change', (e) => {
            this.currentFilters.sort = e.target.value;
            this.currentFilters.page = 1;
            this.loadWishlist();
        });

        // View toggle
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchView(e.target.dataset.view);
            });
        });

        // Batch actions
        document.getElementById('selectAllWishlist')?.addEventListener('change', (e) => {
            this.toggleSelectAll(e.target.checked);
        });

        document.getElementById('batchAddToCart')?.addEventListener('click', () => {
            this.batchAddToCart();
        });

        document.getElementById('batchRemove')?.addEventListener('click', () => {
            this.batchRemoveFromWishlist();
        });

        document.getElementById('clearWishlistBtn')?.addEventListener('click', () => {
            this.clearWishlist();
        });

        // Logout
        document.getElementById('logoutBtn')?.addEventListener('click', (e) => {
            e.preventDefault();
            this.logout();
        });

        // Modal close buttons
        document.getElementById('closeQuickView')?.addEventListener('click', () => {
            this.closeQuickViewModal();
        });

        document.getElementById('closeQuickViewBtn')?.addEventListener('click', () => {
            this.closeQuickViewModal();
        });

        document.getElementById('closeRemoveModal')?.addEventListener('click', () => {
            this.closeRemoveModal();
        });

        document.getElementById('cancelRemove')?.addEventListener('click', () => {
            this.closeRemoveModal();
        });

        document.getElementById('confirmRemove')?.addEventListener('click', () => {
            this.confirmRemoveFromWishlist();
        });

        // Close modals on outside click
        document.getElementById('quickViewModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'quickViewModal') {
                this.closeQuickViewModal();
            }
        });

        document.getElementById('removeConfirmModal')?.addEventListener('click', (e) => {
            if (e.target.id === 'removeConfirmModal') {
                this.closeRemoveModal();
            }
        });
    }

    // Load sidebar user info
    async loadSidebarUserInfo() {
        try {
            const response = await api.getCurrentUser();
            if (response.success) {
                const user = response.data.user;
                document.getElementById('userName').textContent = 
                    user.profile.firstName && user.profile.lastName ? 
                    `${user.profile.firstName} ${user.profile.lastName}` : user.username;
                document.getElementById('userEmail').textContent = user.email;
                if (user.profile.avatar) {
                    document.getElementById('userAvatar').src = user.profile.avatar;
                }
            } else {
                window.location.href = '../auth/login.php';
            }
        } catch (error) {
            console.error('Error loading user info:', error);
            window.location.href = '../auth/login.php';
        }
    }

    // Load wishlist items
    async loadWishlist() {
        try {
            this.showLoadingState();
            
            const params = {
                page: this.currentFilters.page,
                limit: this.currentFilters.limit,
                sort: this.currentFilters.sort
            };
            
            if (this.currentFilters.search) {
                params.search = this.currentFilters.search;
            }
            if (this.currentFilters.category) {
                params.category = this.currentFilters.category;
            }

            const response = await api.getWishlist(params);
            this.hideLoadingState();

            if (response.success && response.data.items.length > 0) {
                this.wishlistItems = response.data.items;
                this.displayWishlistItems();
                this.renderPagination(response.data.pagination);
                this.hideEmptyState();
            } else {
                this.showEmptyState();
            }
        } catch (error) {
            this.hideLoadingState();
            console.error('Error loading wishlist:', error);
            api.showToast('Không thể tải danh sách yêu thích', 'error');
        }
    }

    // Display wishlist items
    displayWishlistItems() {
        if (this.currentView === 'grid') {
            this.displayGridView();
        } else {
            this.displayListView();
        }
    }

    // Display grid view
    displayGridView() {
        const container = document.getElementById('wishlistGrid');
        const listContainer = document.getElementById('wishlistList');
        
        if (container) {
            container.style.display = 'grid';
            listContainer.style.display = 'none';
            
            const itemsHTML = this.wishlistItems.map(item => this.createWishlistItemCard(item)).join('');
            container.innerHTML = itemsHTML;
        }
    }

    // Display list view
    displayListView() {
        const container = document.getElementById('wishlistList');
        const gridContainer = document.getElementById('wishlistGrid');
        
        if (container) {
            container.style.display = 'block';
            gridContainer.style.display = 'none';
            
            const itemsHTML = this.wishlistItems.map(item => this.createWishlistItemRow(item)).join('');
            container.innerHTML = itemsHTML;
        }
    }

    // Create wishlist item card
    createWishlistItemCard(item) {
        const isSelected = this.selectedItems.has(item._id);
        const isInStock = item.product.stock > 0;
        
        return `
            <div class="wishlist-item-card ${isSelected ? 'selected' : ''}" data-id="${item._id}">
                <div class="item-checkbox">
                    <input type="checkbox" class="item-select" data-id="${item._id}" ${isSelected ? 'checked' : ''} />
                </div>
                <div class="item-image">
                    <img src="${item.product.images[0]?.url || 'https://via.placeholder.com/200x250?text=Book'}" 
                         alt="${this.escapeHtml(item.product.title)}" />
                    <div class="item-overlay">
                        <button class="btn btn-sm btn-primary" onclick="wishlistManager.quickView('${item.product._id}')">
                            👁️ Xem nhanh
                        </button>
                    </div>
                </div>
                <div class="item-content">
                    <h3 class="item-title">${this.escapeHtml(item.product.title)}</h3>
                    <p class="item-author">${this.escapeHtml(item.product.author)}</p>
                    <div class="item-price">
                        ${this.formatPrice(item.product.price)}
                        ${item.product.originalPrice > item.product.price ? 
                            `<span class="original-price">${this.formatPrice(item.product.originalPrice)}</span>` : ''}
                    </div>
                    <div class="item-rating">
                        ${this.generateStars(item.product.rating?.average || 0)}
                        <span class="rating-count">(${item.product.rating?.count || 0})</span>
                    </div>
                    <div class="item-actions">
                        <button class="btn btn-primary btn-sm" 
                                onclick="wishlistManager.addToCart('${item.product._id}')"
                                ${!isInStock ? 'disabled' : ''}>
                            <span class="btn-icon">🛒</span>
                            ${isInStock ? 'Thêm vào giỏ' : 'Hết hàng'}
                        </button>
                        <button class="btn btn-outline btn-sm" 
                                onclick="wishlistManager.removeFromWishlist('${item._id}')">
                            <span class="btn-icon">❤️</span>
                            Bỏ yêu thích
                        </button>
                    </div>
                </div>
                <div class="item-meta">
                    <span class="added-date">Thêm ngày: ${this.formatDate(item.createdAt)}</span>
                </div>
            </div>
        `;
    }

    // Create wishlist item row
    createWishlistItemRow(item) {
        const isSelected = this.selectedItems.has(item._id);
        const isInStock = item.product.stock > 0;
        
        return `
            <div class="wishlist-item-row ${isSelected ? 'selected' : ''}" data-id="${item._id}">
                <div class="item-checkbox">
                    <input type="checkbox" class="item-select" data-id="${item._id}" ${isSelected ? 'checked' : ''} />
                </div>
                <div class="item-image">
                    <img src="${item.product.images[0]?.url || 'https://via.placeholder.com/80x100?text=Book'}" 
                         alt="${this.escapeHtml(item.product.title)}" />
                </div>
                <div class="item-info">
                    <h3 class="item-title">${this.escapeHtml(item.product.title)}</h3>
                    <p class="item-author">${this.escapeHtml(item.product.author)}</p>
                    <div class="item-rating">
                        ${this.generateStars(item.product.rating?.average || 0)}
                        <span class="rating-count">(${item.product.rating?.count || 0})</span>
                    </div>
                </div>
                <div class="item-price">
                    <div class="current-price">${this.formatPrice(item.product.price)}</div>
                    ${item.product.originalPrice > item.product.price ? 
                        `<div class="original-price">${this.formatPrice(item.product.originalPrice)}</div>` : ''}
                </div>
                <div class="item-stock">
                    <span class="stock-status ${isInStock ? 'in-stock' : 'out-of-stock'}">
                        ${isInStock ? 'Còn hàng' : 'Hết hàng'}
                    </span>
                </div>
                <div class="item-actions">
                    <button class="btn btn-primary btn-sm" 
                            onclick="wishlistManager.addToCart('${item.product._id}')"
                            ${!isInStock ? 'disabled' : ''}>
                        <span class="btn-icon">🛒</span>
                        Thêm vào giỏ
                    </button>
                    <button class="btn btn-outline btn-sm" 
                            onclick="wishlistManager.quickView('${item.product._id}')">
                        <span class="btn-icon">👁️</span>
                        Xem nhanh
                    </button>
                    <button class="btn btn-outline btn-sm" 
                            onclick="wishlistManager.removeFromWishlist('${item._id}')">
                        <span class="btn-icon">❤️</span>
                        Bỏ yêu thích
                    </button>
                </div>
            </div>
        `;
    }

    // Switch view
    switchView(view) {
        this.currentView = view;
        
        // Update view buttons
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-view="${view}"]`).classList.add('active');
        
        // Update display
        this.displayWishlistItems();
    }

    // Toggle select all
    toggleSelectAll(checked) {
        this.selectedItems.clear();
        
        if (checked) {
            this.wishlistItems.forEach(item => {
                this.selectedItems.add(item._id);
            });
        }
        
        this.updateItemSelections();
        this.updateBatchActions();
    }

    // Update item selections
    updateItemSelections() {
        document.querySelectorAll('.item-select').forEach(checkbox => {
            const itemId = checkbox.dataset.id;
            checkbox.checked = this.selectedItems.has(itemId);
            
            const itemElement = document.querySelector(`[data-id="${itemId}"]`);
            if (itemElement) {
                itemElement.classList.toggle('selected', this.selectedItems.has(itemId));
            }
        });
    }

    // Update batch actions
    updateBatchActions() {
        const batchActions = document.getElementById('batchActions');
        const selectedCount = document.getElementById('selectedCount');
        
        if (this.selectedItems.size > 0) {
            batchActions.style.display = 'flex';
            selectedCount.textContent = this.selectedItems.size;
        } else {
            batchActions.style.display = 'none';
        }
    }

    // Add to cart
    async addToCart(productId) {
        try {
            const response = await api.addToCart(productId, 1);
            if (response.success) {
                api.showToast('Đã thêm vào giỏ hàng', 'success');
            } else {
                throw new Error(response.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Error adding to cart:', error);
            api.showToast(error.message || 'Không thể thêm vào giỏ hàng', 'error');
        }
    }

    // Batch add to cart
    async batchAddToCart() {
        if (this.selectedItems.size === 0) return;
        
        try {
            const productIds = Array.from(this.selectedItems).map(itemId => {
                const item = this.wishlistItems.find(i => i._id === itemId);
                return item.product._id;
            });
            
            const response = await api.batchAddToCart(productIds);
            if (response.success) {
                api.showToast(`Đã thêm ${this.selectedItems.size} sản phẩm vào giỏ hàng`, 'success');
                this.selectedItems.clear();
                this.updateBatchActions();
                this.updateItemSelections();
            } else {
                throw new Error(response.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Error batch adding to cart:', error);
            api.showToast(error.message || 'Không thể thêm vào giỏ hàng', 'error');
        }
    }

    // Remove from wishlist
    removeFromWishlist(itemId) {
        const item = this.wishlistItems.find(i => i._id === itemId);
        if (!item) return;
        
        // Show confirmation modal
        this.showRemoveConfirmation(item);
    }

    // Show remove confirmation
    showRemoveConfirmation(item) {
        const modal = document.getElementById('removeConfirmModal');
        const preview = document.getElementById('removeProductPreview');
        
        preview.innerHTML = `
            <div class="product-preview-item">
                <img src="${item.product.images[0]?.url || 'https://via.placeholder.com/60x80?text=Book'}" 
                     alt="${this.escapeHtml(item.product.title)}" />
                <div class="product-info">
                    <h4>${this.escapeHtml(item.product.title)}</h4>
                    <p>${this.escapeHtml(item.product.author)}</p>
                </div>
            </div>
        `;
        
        modal.style.display = 'block';
        this.currentRemoveItemId = item._id;
    }

    // Close remove modal
    closeRemoveModal() {
        document.getElementById('removeConfirmModal').style.display = 'none';
        this.currentRemoveItemId = null;
    }

    // Confirm remove from wishlist
    async confirmRemoveFromWishlist() {
        if (!this.currentRemoveItemId) return;
        
        try {
            const response = await api.removeFromWishlist(this.currentRemoveItemId);
            if (response.success) {
                api.showToast('Đã xóa khỏi danh sách yêu thích', 'success');
                this.closeRemoveModal();
                this.loadWishlist(); // Reload wishlist
            } else {
                throw new Error(response.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Error removing from wishlist:', error);
            api.showToast(error.message || 'Không thể xóa khỏi danh sách yêu thích', 'error');
        }
    }

    // Batch remove from wishlist
    async batchRemoveFromWishlist() {
        if (this.selectedItems.size === 0) return;
        
        if (!confirm(`Bạn có chắc chắn muốn xóa ${this.selectedItems.size} sản phẩm khỏi danh sách yêu thích?`)) {
            return;
        }
        
        try {
            const itemIds = Array.from(this.selectedItems);
            const response = await api.batchRemoveFromWishlist(itemIds);
            if (response.success) {
                api.showToast(`Đã xóa ${this.selectedItems.size} sản phẩm khỏi danh sách yêu thích`, 'success');
                this.selectedItems.clear();
                this.updateBatchActions();
                this.loadWishlist(); // Reload wishlist
            } else {
                throw new Error(response.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Error batch removing from wishlist:', error);
            api.showToast(error.message || 'Không thể xóa khỏi danh sách yêu thích', 'error');
        }
    }

    // Clear wishlist
    async clearWishlist() {
        if (this.wishlistItems.length === 0) return;
        
        if (!confirm('Bạn có chắc chắn muốn xóa tất cả sản phẩm khỏi danh sách yêu thích?')) {
            return;
        }
        
        try {
            const response = await api.clearWishlist();
            if (response.success) {
                api.showToast('Đã xóa tất cả sản phẩm khỏi danh sách yêu thích', 'success');
                this.loadWishlist(); // Reload wishlist
            } else {
                throw new Error(response.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Error clearing wishlist:', error);
            api.showToast(error.message || 'Không thể xóa danh sách yêu thích', 'error');
        }
    }

    // Quick view product
    async quickView(productId) {
        try {
            const response = await api.getProduct(productId);
            if (response.success) {
                this.showQuickViewModal(response.data.product);
            } else {
                throw new Error(response.message || 'Có lỗi xảy ra');
            }
        } catch (error) {
            console.error('Error loading product:', error);
            api.showToast(error.message || 'Không thể tải thông tin sản phẩm', 'error');
        }
    }

    // Show quick view modal
    showQuickViewModal(product) {
        const modal = document.getElementById('quickViewModal');
        const title = document.getElementById('quickViewTitle');
        const content = document.getElementById('quickViewContent');
        
        title.textContent = this.escapeHtml(product.title);
        content.innerHTML = `
            <div class="product-quick-view-content">
                <div class="product-image">
                    <img src="${product.images[0]?.url || 'https://via.placeholder.com/300x400?text=Book'}" 
                         alt="${this.escapeHtml(product.title)}" />
                </div>
                <div class="product-details">
                    <h3>${this.escapeHtml(product.title)}</h3>
                    <p class="product-author">Tác giả: ${this.escapeHtml(product.author)}</p>
                    <div class="product-price">
                        ${this.formatPrice(product.price)}
                        ${product.originalPrice > product.price ? 
                            `<span class="original-price">${this.formatPrice(product.originalPrice)}</span>` : ''}
                    </div>
                    <div class="product-rating">
                        ${this.generateStars(product.rating?.average || 0)}
                        <span class="rating-count">(${product.rating?.count || 0} đánh giá)</span>
                    </div>
                    <div class="product-stock">
                        <span class="stock-status ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}">
                            ${product.stock > 0 ? `Còn ${product.stock} sản phẩm` : 'Hết hàng'}
                        </span>
                    </div>
                    <div class="product-description">
                        <p>${this.escapeHtml(product.description || 'Không có mô tả')}</p>
                    </div>
                    <div class="product-actions">
                        <button class="btn btn-primary" 
                                onclick="wishlistManager.addToCart('${product._id}')"
                                ${product.stock === 0 ? 'disabled' : ''}>
                            <span class="btn-icon">🛒</span>
                            ${product.stock > 0 ? 'Thêm vào giỏ' : 'Hết hàng'}
                        </button>
                        <a href="../../pages/products/detail.php?id=${product._id}" class="btn btn-outline">
                            <span class="btn-icon">👁️</span>
                            Xem chi tiết
                        </a>
                    </div>
                </div>
            </div>
        `;
        
        modal.style.display = 'block';
    }

    // Close quick view modal
    closeQuickViewModal() {
        document.getElementById('quickViewModal').style.display = 'none';
    }

    // Render pagination
    renderPagination(pagination) {
        const container = document.getElementById('wishlistPagination');
        if (!container) return;
        
        if (pagination.pages <= 1) {
            container.style.display = 'none';
            return;
        }
        
        container.style.display = 'flex';
        container.innerHTML = '';
        
        const paginationContent = document.createElement('div');
        paginationContent.className = 'pagination-content';
        
        // Previous button
        const prevBtn = document.createElement('button');
        prevBtn.className = 'pagination-btn';
        prevBtn.textContent = 'Trước';
        prevBtn.disabled = pagination.page === 1;
        prevBtn.addEventListener('click', () => {
            this.currentFilters.page--;
            this.loadWishlist();
        });
        paginationContent.appendChild(prevBtn);
        
        // Page numbers
        for (let i = 1; i <= pagination.pages; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.className = `pagination-btn ${i === pagination.page ? 'active' : ''}`;
            pageBtn.textContent = i;
            pageBtn.addEventListener('click', () => {
                this.currentFilters.page = i;
                this.loadWishlist();
            });
            paginationContent.appendChild(pageBtn);
        }
        
        // Next button
        const nextBtn = document.createElement('button');
        nextBtn.className = 'pagination-btn';
        nextBtn.textContent = 'Sau';
        nextBtn.disabled = pagination.page === pagination.pages;
        nextBtn.addEventListener('click', () => {
            this.currentFilters.page++;
            this.loadWishlist();
        });
        paginationContent.appendChild(nextBtn);
        
        container.appendChild(paginationContent);
    }

    // Show loading state
    showLoadingState() {
        document.getElementById('wishlistLoading').style.display = 'flex';
        document.getElementById('wishlistGrid').style.display = 'none';
        document.getElementById('wishlistList').style.display = 'none';
        document.getElementById('wishlistEmpty').style.display = 'none';
    }

    // Hide loading state
    hideLoadingState() {
        document.getElementById('wishlistLoading').style.display = 'none';
    }

    // Show empty state
    showEmptyState() {
        document.getElementById('wishlistEmpty').style.display = 'flex';
        document.getElementById('wishlistGrid').style.display = 'none';
        document.getElementById('wishlistList').style.display = 'none';
    }

    // Hide empty state
    hideEmptyState() {
        document.getElementById('wishlistEmpty').style.display = 'none';
    }

    // Logout
    async logout() {
        try {
            await api.logout();
            api.clearToken();
            window.location.href = '../auth/login.php';
        } catch (error) {
            console.error('Error logging out:', error);
            api.showToast('Đăng xuất thất bại', 'error');
        }
    }

    // Utility functions
    formatPrice(price) {
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(price);
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('vi-VN', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    }

    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
        
        return '★'.repeat(fullStars) + 
               (hasHalfStar ? '☆' : '') + 
               '☆'.repeat(emptyStars);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Debounce function
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Initialize wishlist manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.wishlistManager = new WishlistManager();
});

// Export for global access
window.WishlistManager = WishlistManager;
