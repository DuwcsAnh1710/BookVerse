// Wallet Page JavaScript for Bookverse

class WalletManager {
    constructor() {
        this.currentPage = 1;
        this.currentStatus = '';
        this.currentType = '';
        this.init();
    }

    init() {
        this.loadWalletBalance();
        this.loadPaymentHistory();
        this.bindEvents();
    }

    bindEvents() {
        // Deposit form
        const depositForm = document.getElementById('depositForm');
        if (depositForm) {
            depositForm.addEventListener('submit', (e) => this.handleDeposit(e));
        }

        // Filters
        const statusFilter = document.getElementById('statusFilter');
        const typeFilter = document.getElementById('typeFilter');
        
        if (statusFilter) {
            statusFilter.addEventListener('change', (e) => {
                this.currentStatus = e.target.value;
                this.currentPage = 1;
                this.loadPaymentHistory();
            });
        }

        if (typeFilter) {
            typeFilter.addEventListener('change', (e) => {
                this.currentType = e.target.value;
                this.currentPage = 1;
                this.loadPaymentHistory();
            });
        }

        // Modal events
        const closeModal = document.getElementById('closeDepositModal');
        const confirmModal = document.getElementById('confirmDepositModal');
        const depositModal = document.getElementById('depositModal');

        if (closeModal) {
            closeModal.addEventListener('click', () => this.closeModal());
        }

        if (confirmModal) {
            confirmModal.addEventListener('click', () => this.closeModal());
        }

        if (depositModal) {
            depositModal.addEventListener('click', (e) => {
                if (e.target === depositModal) {
                    this.closeModal();
                }
            });
        }
    }

    async loadWalletBalance() {
        try {
            const response = await fetch('/api/payments/balance', {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (!response.ok) {
                throw new Error('Không thể tải số dư ví');
            }

            const data = await response.json();
            if (data.success) {
                this.updateBalanceDisplay(data.data.balance);
            }
        } catch (error) {
            console.error('Error loading wallet balance:', error);
            this.showToast('Lỗi khi tải số dư ví', 'error');
        }
    }

    updateBalanceDisplay(balance) {
        const balanceElement = document.getElementById('walletBalance');
        if (balanceElement) {
            balanceElement.textContent = `${balance.toLocaleString('vi-VN')} VND`;
        }
    }

    async loadPaymentHistory() {
        const historyContainer = document.getElementById('paymentHistory');
        if (!historyContainer) return;

        // Show loading state
        historyContainer.innerHTML = `
            <div class="loading-state">
                <div class="loading-spinner"></div>
                <p>Đang tải lịch sử giao dịch...</p>
            </div>
        `;

        try {
            const params = new URLSearchParams({
                page: this.currentPage,
                limit: 10
            });

            if (this.currentStatus) params.append('status', this.currentStatus);
            if (this.currentType) params.append('type', this.currentType);

            const response = await fetch(`/api/payments/history?${params}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (!response.ok) {
                throw new Error('Không thể tải lịch sử giao dịch');
            }

            const data = await response.json();
            if (data.success) {
                this.renderPaymentHistory(data.data.payments);
                this.renderPagination(data.data.pagination);
            } else {
                throw new Error(data.message || 'Lỗi khi tải lịch sử giao dịch');
            }
        } catch (error) {
            console.error('Error loading payment history:', error);
            this.renderErrorState(error.message);
        }
    }

    renderPaymentHistory(payments) {
        const historyContainer = document.getElementById('paymentHistory');
        
        if (!payments || payments.length === 0) {
            historyContainer.innerHTML = `
                <div class="empty-state">
                    <div class="empty-icon">📊</div>
                    <h3>Chưa có giao dịch nào</h3>
                    <p>Lịch sử giao dịch của bạn sẽ hiển thị ở đây</p>
                </div>
            `;
            return;
        }

        const historyHTML = payments.map(payment => this.createPaymentItemHTML(payment)).join('');
        historyContainer.innerHTML = historyHTML;
    }

    createPaymentItemHTML(payment) {
        const typeIcons = {
            'deposit': '💰',
            'withdrawal': '💸',
            'payment': '🛒',
            'commission': '💎'
        };

        const typeLabels = {
            'deposit': 'Nạp tiền',
            'withdrawal': 'Rút tiền',
            'payment': 'Thanh toán',
            'commission': 'Hoa hồng'
        };

        const statusLabels = {
            'pending': 'Chờ xử lý',
            'completed': 'Hoàn thành',
            'failed': 'Thất bại',
            'cancelled': 'Đã hủy'
        };

        const isPositive = payment.type === 'deposit' || payment.type === 'commission';
        const amountClass = isPositive ? 'amount-positive' : 'amount-negative';
        const amountPrefix = isPositive ? '+' : '-';

        const date = new Date(payment.createdAt).toLocaleDateString('vi-VN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });

        return `
            <div class="history-item">
                <div class="history-info">
                    <div class="history-type">
                        <span class="type-icon">${typeIcons[payment.type] || '💳'}</span>
                        <span class="type-text">${typeLabels[payment.type] || payment.type}</span>
                    </div>
                    <div class="history-description">${payment.description}</div>
                    <div class="history-date">${date}</div>
                </div>
                <div class="history-amount">
                    <div class="amount-value ${amountClass}">
                        ${amountPrefix}${payment.amount.toLocaleString('vi-VN')} VND
                    </div>
                    <div class="history-status status-${payment.status}">
                        ${statusLabels[payment.status] || payment.status}
                    </div>
                </div>
            </div>
        `;
    }

    renderPagination(pagination) {
        const paginationContainer = document.getElementById('pagination');
        if (!paginationContainer || pagination.pages <= 1) {
            paginationContainer.innerHTML = '';
            return;
        }

        const { current, pages, total } = pagination;
        let paginationHTML = '';

        // Previous button
        paginationHTML += `
            <button ${current === 1 ? 'disabled' : ''} onclick="walletManager.goToPage(${current - 1})">
                ← Trước
            </button>
        `;

        // Page numbers
        const startPage = Math.max(1, current - 2);
        const endPage = Math.min(pages, current + 2);

        if (startPage > 1) {
            paginationHTML += `<button onclick="walletManager.goToPage(1)">1</button>`;
            if (startPage > 2) {
                paginationHTML += `<span>...</span>`;
            }
        }

        for (let i = startPage; i <= endPage; i++) {
            paginationHTML += `
                <button class="${i === current ? 'active' : ''}" onclick="walletManager.goToPage(${i})">
                    ${i}
                </button>
            `;
        }

        if (endPage < pages) {
            if (endPage < pages - 1) {
                paginationHTML += `<span>...</span>`;
            }
            paginationHTML += `<button onclick="walletManager.goToPage(${pages})">${pages}</button>`;
        }

        // Next button
        paginationHTML += `
            <button ${current === pages ? 'disabled' : ''} onclick="walletManager.goToPage(${current + 1})">
                Sau →
            </button>
        `;

        paginationContainer.innerHTML = paginationHTML;
    }

    renderErrorState(message) {
        const historyContainer = document.getElementById('paymentHistory');
        historyContainer.innerHTML = `
            <div class="empty-state">
                <div class="empty-icon">❌</div>
                <h3>Lỗi khi tải dữ liệu</h3>
                <p>${message}</p>
                <button class="btn btn-primary" onclick="walletManager.loadPaymentHistory()">
                    Thử lại
                </button>
            </div>
        `;
    }

    goToPage(page) {
        this.currentPage = page;
        this.loadPaymentHistory();
    }

    async handleDeposit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const depositData = {
            amount: parseFloat(formData.get('amount')),
            method: formData.get('method'),
            description: formData.get('description') || ''
        };

        // Validation
        if (depositData.amount < 1000) {
            this.showToast('Số tiền tối thiểu là 1,000 VND', 'error');
            return;
        }

        if (!depositData.method) {
            this.showToast('Vui lòng chọn phương thức thanh toán', 'error');
            return;
        }

        try {
            const response = await fetch('/api/payments/deposit', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(depositData)
            });

            const data = await response.json();

            if (data.success) {
                this.showDepositSuccessModal(depositData);
                e.target.reset();
                this.loadPaymentHistory();
            } else {
                throw new Error(data.message || 'Lỗi khi tạo yêu cầu nạp tiền');
            }
        } catch (error) {
            console.error('Error creating deposit:', error);
            this.showToast(error.message || 'Lỗi khi tạo yêu cầu nạp tiền', 'error');
        }
    }

    showDepositSuccessModal(depositData) {
        const modal = document.getElementById('depositModal');
        const modalAmount = document.getElementById('modalAmount');
        const modalMethod = document.getElementById('modalMethod');

        if (modalAmount) {
            modalAmount.textContent = `${depositData.amount.toLocaleString('vi-VN')} VND`;
        }

        if (modalMethod) {
            const methodLabels = {
                'bank_transfer': 'Chuyển khoản ngân hàng',
                'cash': 'Thanh toán tiền mặt'
            };
            modalMethod.textContent = methodLabels[depositData.method] || depositData.method;
        }

        if (modal) {
            modal.classList.add('show');
        }
    }

    closeModal() {
        const modal = document.getElementById('depositModal');
        if (modal) {
            modal.classList.remove('show');
        }
    }

    showToast(message, type = 'info') {
        // Use the global showToast function from api.js
        if (typeof showToast === 'function') {
            showToast(message, type);
        } else {
            alert(message);
        }
    }
}

// Initialize wallet manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.walletManager = new WalletManager();
});
