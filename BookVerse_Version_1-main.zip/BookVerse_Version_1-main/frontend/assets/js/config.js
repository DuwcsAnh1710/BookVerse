// ========================================
// BOOKVERSE FRONTEND CONFIGURATION
// Environment-based configuration
// ========================================

class AppConfig {
    constructor() {
        this.environment = this.detectEnvironment();
        this.config = this.getConfig();
    }

    detectEnvironment() {
        const hostname = window.location.hostname;
        
        if (hostname === 'localhost' || hostname === '127.0.0.1') {
            return 'development';
        } else if (hostname.includes('staging')) {
            return 'staging';
        } else {
            return 'production';
        }
    }

    getConfig() {
        const configs = {
            development: {
                API_BASE_URL: 'http://localhost:5000/api',
                ADMIN_API_BASE: 'http://localhost:5000/api/admin',
                FRONTEND_URL: 'http://localhost:8000',
                DEBUG: true,
                CACHE_DURATION: 5 * 60 * 1000, // 5 minutes
                REQUEST_TIMEOUT: 10000, // 10 seconds
                RETRY_ATTEMPTS: 3
            },
            staging: {
                API_BASE_URL: 'https://api-staging.bookverse.com/api',
                ADMIN_API_BASE: 'https://api-staging.bookverse.com/api/admin',
                FRONTEND_URL: 'https://staging.bookverse.com',
                DEBUG: true,
                CACHE_DURATION: 10 * 60 * 1000, // 10 minutes
                REQUEST_TIMEOUT: 15000, // 15 seconds
                RETRY_ATTEMPTS: 3
            },
            production: {
                API_BASE_URL: 'https://api.bookverse.com/api',
                ADMIN_API_BASE: 'https://api.bookverse.com/api/admin',
                FRONTEND_URL: 'https://bookverse.com',
                DEBUG: false,
                CACHE_DURATION: 30 * 60 * 1000, // 30 minutes
                REQUEST_TIMEOUT: 20000, // 20 seconds
                RETRY_ATTEMPTS: 2
            }
        };

        return configs[this.environment];
    }

    get(key) {
        return this.config[key];
    }

    isDevelopment() {
        return this.environment === 'development';
    }

    isProduction() {
        return this.environment === 'production';
    }

    getApiUrl(endpoint = '') {
        return `${this.config.API_BASE_URL}${endpoint}`;
    }

    getAdminApiUrl(endpoint = '') {
        return `${this.config.ADMIN_API_BASE}${endpoint}`;
    }
}

// Create global config instance
window.appConfig = new AppConfig();

// Export for use in other scripts
window.AppConfig = AppConfig;
