// Authentication JavaScript
class AuthManager {
    constructor() {
        this.api = window.api;
        console.log('[Auth] AuthManager initialized', { apiReady: !!this.api });
        this.initializeEventListeners();
        this.checkAuthStatus();
    }

    initializeEventListeners() {
        // Login form
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            console.log('[Auth] Binding login form submit');
            loginForm.addEventListener('submit', (e) => this.handleLogin(e));
        } else {
            console.warn('[Auth] loginForm not found');
        }

        // Register form
        const registerForm = document.getElementById('registerForm');
        if (registerForm) {
            registerForm.addEventListener('submit', (e) => this.handleRegister(e));
        }

        // Forgot password form
        const forgotForm = document.getElementById('forgotForm');
        if (forgotForm) {
            forgotForm.addEventListener('submit', (e) => this.handleForgotPassword(e));
        }

        // Reset password form
        const resetForm = document.getElementById('resetForm');
        if (resetForm) {
            resetForm.addEventListener('submit', (e) => this.handleResetPassword(e));
        }

        // Password toggle buttons
        this.initializePasswordToggles();
    }

    initializePasswordToggles() {
        // Login page password toggle
        const togglePwd = document.getElementById('togglePwd');
        const passwordInput = document.getElementById('passwordInput');
        if (togglePwd && passwordInput) {
            togglePwd.addEventListener('click', () => this.togglePassword(passwordInput, togglePwd));
        }

        // Register page password toggles
        const toggleRegisterPwd = document.getElementById('togglePwd');
        const toggleConfirmPwd = document.getElementById('toggleConfirmPwd');
        const registerPasswordInput = document.getElementById('passwordInput');
        const confirmPasswordInput = document.getElementById('confirmPasswordInput');
        
        if (toggleRegisterPwd && registerPasswordInput) {
            toggleRegisterPwd.addEventListener('click', () => this.togglePassword(registerPasswordInput, toggleRegisterPwd));
        }
        
        if (toggleConfirmPwd && confirmPasswordInput) {
            toggleConfirmPwd.addEventListener('click', () => this.togglePassword(confirmPasswordInput, toggleConfirmPwd));
        }

        // Reset page password toggles
        const toggleNewPwd = document.getElementById('toggleNewPwd');
        const toggleConfirmNewPwd = document.getElementById('toggleConfirmNewPwd');
        const newPasswordInput = document.getElementById('newPasswordInput');
        const confirmNewPasswordInput = document.getElementById('confirmNewPasswordInput');
        
        if (toggleNewPwd && newPasswordInput) {
            toggleNewPwd.addEventListener('click', () => this.togglePassword(newPasswordInput, toggleNewPwd));
        }
        
        if (toggleConfirmNewPwd && confirmNewPasswordInput) {
            toggleConfirmNewPwd.addEventListener('click', () => this.togglePassword(confirmNewPasswordInput, toggleConfirmNewPwd));
        }
    }

    togglePassword(input, button) {
        const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
        input.setAttribute('type', type);
        button.textContent = type === 'password' ? '👁️' : '🙈';
    }

    async handleLogin(e) {
        e.preventDefault();
        console.log('[Auth] handleLogin submit');
        
        const form = e.target;
        const formData = new FormData(form);
        const email = formData.get('email');
        const password = formData.get('password');
        
        const loginBtn = document.getElementById('loginBtn');
        const btnText = loginBtn.querySelector('.btn-text');
        const btnLoading = loginBtn.querySelector('.btn-loading');
        
        try {
            this.setLoading(loginBtn, btnText, btnLoading, true);
            const loadingId = (typeof notificationManager !== 'undefined' && notificationManager)
                ? notificationManager.loading('Đang đăng nhập...')
                : null;
            
            // Call real API
            console.log('[Auth] Calling API login');
            const resp = await this.api.login(email, password);
            console.log('[Auth] Login response OK');
            if (loadingId && typeof notificationManager !== 'undefined') notificationManager.close(loadingId);
            
            // Save token for frontend JS
            const token = resp?.data?.token;
            if (!token) {
                throw new Error('Phản hồi không hợp lệ từ máy chủ (không có token)');
            }
            this.api.setToken(token);
            console.log('[Auth] Token set');
            
            // Also set cookie for PHP detection (24h)
            document.cookie = `bookverse_token=${token}; path=/; max-age=${24 * 60 * 60}`;
            
            // Determine user and redirect
            let user = resp?.data?.user;
            try {
                if (!user) {
                    console.log('[Auth] Fetching /auth/me as fallback');
                    const me = await this.api.getCurrentUser();
                    user = me?.data?.user;
                }
            } catch (_) {}
            
            // Redirect based on user role - use absolute paths from frontend root
            let redirectUrl;
            let successMessage;
            
            // Get base URL (frontend root)
            const baseUrl = window.location.origin + '/Bookverse/frontend';
            
            if (user?.role === 'admin') {
                redirectUrl = baseUrl + '/pages/admin/dashboard.php';
                successMessage = '🎉 Chào mừng Admin! Đang chuyển đến Dashboard quản trị...';
            } else if (user?.role === 'seller') {
                // Check if seller is approved
                const isApproved = user?.sellerProfile?.isApproved;
                if (isApproved) {
                    redirectUrl = baseUrl + '/pages/seller/dashboard.php';
                    successMessage = '🎉 Chào mừng Seller! Đang chuyển đến Dashboard bán hàng...';
                } else {
                    // Seller not approved yet
                    redirectUrl = baseUrl + '/index.php';
                    successMessage = '⏳ Đăng nhập thành công! Tài khoản seller của bạn đang chờ admin phê duyệt. Bạn có thể mua sắm trong khi chờ.';
                }
            } else {
                redirectUrl = baseUrl + '/index.php';
                successMessage = '🎉 Đăng nhập thành công! Chào mừng bạn quay trở lại!';
            }
            
            // Show success notification and redirect
            if (typeof notificationManager !== 'undefined' && notificationManager) {
                notificationManager.success(successMessage);
            }
            
            // Always use direct redirect with setTimeout
            setTimeout(() => {
                window.location.href = redirectUrl;
            }, 1500);
        } catch (error) {
            console.error('Login error:', error);
            // Prefer APIError details if available
            const apiMsg = error?.data?.message || error?.message || 'Đăng nhập thất bại. Vui lòng kiểm tra lại!';
            if (typeof notificationManager !== 'undefined' && notificationManager?.showAuthError) {
                notificationManager.showAuthError(apiMsg);
            } else if (typeof showAuthError === 'function') {
                showAuthError(apiMsg);
            } else if (typeof showError === 'function') {
                showError(apiMsg);
            } else {
                alert(apiMsg);
            }
        } finally {
            this.setLoading(loginBtn, btnText, btnLoading, false);
        }
    }

    async handleRegister(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        
        // Validate password confirmation
        const password = formData.get('password');
        const confirmPassword = formData.get('confirmPassword');
        
        if (password !== confirmPassword) {
            showError('Mật khẩu xác nhận không khớp.');
            return;
        }
        
        // Validate terms agreement
        const agreeTerms = formData.get('agreeTerms');
        if (!agreeTerms) {
            showError('Vui lòng đồng ý với điều khoản sử dụng.');
            return;
        }
        
        // Get account type
        const accountType = document.querySelector('input[name="accountType"]:checked')?.value || 'user';
        
        const userData = {
            username: formData.get('username'),
            email: formData.get('email'),
            password: password,
            role: accountType, // Set role based on selection
            profile: {
                firstName: formData.get('firstName'),
                lastName: formData.get('lastName')
            }
        };
        
        const registerBtn = document.getElementById('registerBtn');
        const btnText = registerBtn.querySelector('.btn-text');
        const btnLoading = registerBtn.querySelector('.btn-loading');
        
        try {
            this.setLoading(registerBtn, btnText, btnLoading, true);
            
            // Show loading notification
            const loadingId = showLoading('Đang tạo tài khoản...');
            
            // Call real API
            const resp = await this.api.register(userData);
            if (!resp?.success) {
                throw new Error(resp?.message || 'Đăng ký thất bại');
            }
            
            // Close loading notification
            notificationManager.close(loadingId);
            
            // Show success notification with redirect
            const accountTypeText = accountType === 'buyer' ? 'Người mua' : 
                                  accountType === 'seller' ? 'Người bán' : 'Người dùng';
            
            // Check if needs approval from API response
            const needsApproval = resp?.data?.needsApproval || false;
            const approvalNote = needsApproval 
                ? '\\n\\n⏳ Lưu ý: Tài khoản seller cần admin phê duyệt trước khi có thể bán hàng.'
                : '';
            
            if (typeof notificationManager !== 'undefined' && notificationManager?.showAuthSuccess) {
                notificationManager.showAuthSuccess(`🎉 Đăng ký thành công!\\n\\nLoại tài khoản: ${accountTypeText}\\nEmail: ${userData.email}${approvalNote}\\n\\nChuyển đến trang đăng nhập...`, 'login.php');
            } else if (typeof showAuthSuccess === 'function') {
                showAuthSuccess(`🎉 Đăng ký thành công!\\n\\nLoại tài khoản: ${accountTypeText}\\nEmail: ${userData.email}${approvalNote}\\n\\nChuyển đến trang đăng nhập...`, 'login.php');
            } else {
                window.location.href = 'login.php';
            }
            
        } catch (error) {
            console.error('Registration error:', error);
            const msg = error?.data?.message || error?.message || 'Có lỗi xảy ra khi đăng ký. Vui lòng thử lại!';
            if (typeof notificationManager !== 'undefined' && notificationManager?.showAuthError) {
                notificationManager.showAuthError(msg);
            } else if (typeof showAuthError === 'function') {
                showAuthError(msg);
            } else {
                alert(msg);
            }
        } finally {
            this.setLoading(registerBtn, btnText, btnLoading, false);
        }
    }

    async handleForgotPassword(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const email = formData.get('email');
        
        const forgotBtn = document.getElementById('forgotBtn');
        const btnText = forgotBtn.querySelector('.btn-text');
        const btnLoading = forgotBtn.querySelector('.btn-loading');
        const errorDiv = document.getElementById('forgotError');
        const successDiv = document.getElementById('forgotSuccess');
        
        try {
            this.setLoading(forgotBtn, btnText, btnLoading, true);
            this.hideError(errorDiv);
            this.hideSuccess(successDiv);
            
            const response = await this.api.forgotPassword(email);
            
            if (response.success) {
                this.showSuccess(successDiv, 'Mã OTP đã được gửi đến email của bạn. Vui lòng kiểm tra hộp thư.');
                
                // Show OTP in development mode
                if (response.data && response.data.otp) {
                    this.showSuccess(successDiv, `Mã OTP: ${response.data.otp} (Chỉ hiển thị trong development)`);
                }
                
                // Redirect to reset page after 3 seconds
                setTimeout(() => {
                    window.location.href = 'reset.php';
                }, 3000);
            }
        } catch (error) {
            this.showError(errorDiv, error.message || 'Gửi mã OTP thất bại. Vui lòng thử lại.');
        } finally {
            this.setLoading(forgotBtn, btnText, btnLoading, false);
        }
    }

    async handleResetPassword(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        
        // Validate password confirmation
        const newPassword = formData.get('newPassword');
        const confirmPassword = formData.get('confirmPassword');
        
        if (newPassword !== confirmPassword) {
            const errorDiv = document.getElementById('resetError');
            this.showError(errorDiv, 'Mật khẩu xác nhận không khớp.');
            return;
        }
        
        const resetData = {
            email: formData.get('email'),
            otp: formData.get('otp'),
            newPassword: newPassword
        };
        
        const resetBtn = document.getElementById('resetBtn');
        const btnText = resetBtn.querySelector('.btn-text');
        const btnLoading = resetBtn.querySelector('.btn-loading');
        const errorDiv = document.getElementById('resetError');
        const successDiv = document.getElementById('resetSuccess');
        
        try {
            this.setLoading(resetBtn, btnText, btnLoading, true);
            this.hideError(errorDiv);
            this.hideSuccess(successDiv);
            
            const response = await this.api.resetPasswordWithOtp(resetData.email, resetData.otp, resetData.newPassword);
            
            if (response.success) {
                this.showSuccess(successDiv, 'Đặt lại mật khẩu thành công! Đang chuyển hướng...');
                
                setTimeout(() => {
                    window.location.href = 'login.php';
                }, 2000);
            }
        } catch (error) {
            this.showError(errorDiv, error.message || 'Đặt lại mật khẩu thất bại. Vui lòng thử lại.');
        } finally {
            this.setLoading(resetBtn, btnText, btnLoading, false);
        }
    }

    setLoading(button, textElement, loadingElement, isLoading) {
        if (isLoading) {
            button.disabled = true;
            textElement.style.display = 'none';
            loadingElement.style.display = 'inline';
        } else {
            button.disabled = false;
            textElement.style.display = 'inline';
            loadingElement.style.display = 'none';
        }
    }

    showError(errorDiv, message) {
        if (errorDiv) {
            errorDiv.textContent = message;
            errorDiv.style.display = 'block';
        }
    }

    hideError(errorDiv) {
        if (errorDiv) {
            errorDiv.style.display = 'none';
        }
    }

    showSuccess(successDiv, message) {
        if (successDiv) {
            successDiv.textContent = message;
            successDiv.style.display = 'block';
        } else {
            // Create temporary success message
            this.createToast(message, 'success');
        }
    }

    hideSuccess(successDiv) {
        if (successDiv) {
            successDiv.style.display = 'none';
        }
    }

    createToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 1rem 1.5rem;
            background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 10000;
            animation: slideIn 0.3s ease;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 300);
        }, 3000);
    }

    checkAuthStatus() {
        const token = this.api.token;
        if (token) {
            // User is already logged in, redirect to appropriate page
            this.api.getCurrentUser()
                .then(response => {
                    const user = response.data.user;
                    if (user.role === 'admin') {
                        window.location.href = '../../pages/admin/dashboard.php';
                    } else if (user.role === 'seller') {
                        window.location.href = '../../pages/seller/dashboard.php';
                    } else {
                        window.location.href = '../../index.php';
                    }
                })
                .catch(() => {
                    // Token is invalid, clear it
                    this.api.clearToken();
                });
        }
    }
}

// Social login handlers
function handleSocialLogin(provider) {
    // Placeholder for social login implementation
    console.log(`Social login with ${provider} - Feature coming soon!`);
    
    // Show coming soon message
    const authManager = new AuthManager();
    authManager.createToast(`Đăng nhập bằng ${provider} sẽ có sớm!`, 'info');
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new AuthManager();
});

// Add CSS for animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
    
    .error-message {
        background: #fef2f2;
        color: #dc2626;
        padding: 0.75rem 1rem;
        border-radius: 8px;
        border: 1px solid #fecaca;
        margin-bottom: 1rem;
        font-size: 0.875rem;
    }
    
    .success-message {
        background: #f0fdf4;
        color: #16a34a;
        padding: 0.75rem 1rem;
        border-radius: 8px;
        border: 1px solid #bbf7d0;
        margin-bottom: 1rem;
        font-size: 0.875rem;
    }
    
    .form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
    }
    
    .form-checkbox {
        display: flex;
        align-items: flex-start;
        gap: 0.5rem;
        margin: 1rem 0;
    }
    
    .form-checkbox input[type="checkbox"] {
        margin: 0;
        width: auto;
    }
    
    .form-checkbox label {
        font-size: 0.875rem;
        line-height: 1.4;
        color: #6b7280;
    }
    
    .form-checkbox a {
        color: #667eea;
        text-decoration: none;
    }
    
    .form-checkbox a:hover {
        text-decoration: underline;
    }
    
    @media (max-width: 480px) {
        .form-row {
            grid-template-columns: 1fr;
        }
    }
`;
document.head.appendChild(style);// JWT Token creation (simplified for demo)
function createJWTToken(payload) {
    const header = {
        alg: 'HS256',
        typ: 'JWT'
    };
    
    const encodedHeader = btoa(JSON.stringify(header));
    const encodedPayload = btoa(JSON.stringify(payload));
    const signature = btoa('mock-signature'); // In production, use proper HMAC
    
    return `${encodedHeader}.${encodedPayload}.${signature}`;
}

// Check token expiry
function isTokenExpired(token) {
    try {
        const parts = token.split('.');
        const payload = JSON.parse(atob(parts[1]));
        return payload.exp < Math.floor(Date.now() / 1000);
    } catch (error) {
        return true;
    }
}

// Auto-logout when token expires
function checkTokenExpiry() {
    const token = sessionStorage.getItem('bookverse_token');
    if (token && isTokenExpired(token)) {
        sessionStorage.removeItem('bookverse_token');
        document.cookie = 'bookverse_token=; path=/; max-age=0';
        showError('Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.');
        setTimeout(() => {
            window.location.href = 'pages/auth/login.php';
        }, 2000);
    }
}

// Check token every 5 minutes
setInterval(checkTokenExpiry, 5 * 60 * 1000);

