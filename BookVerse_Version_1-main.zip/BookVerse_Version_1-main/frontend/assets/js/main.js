// Enhanced Main JavaScript functionality for Bookverse

// Performance optimization
const performanceObserver = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
        if (entry.entryType === 'navigation') {
            console.log('Page load time:', entry.loadEventEnd - entry.loadEventStart, 'ms');
        }
    }
});

performanceObserver.observe({ entryTypes: ['navigation'] });

// Intersection Observer for lazy loading
const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const img = entry.target;
            if (img.dataset.src) {
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        }
    });
}, {
    rootMargin: '50px 0px',
    threshold: 0.01
});

// Enhanced initialization
document.addEventListener('DOMContentLoaded', function() {
    // Initialize the application with error handling
    try {
        initializeApp();
    } catch (error) {
        console.error('Failed to initialize app:', error);
        showError('Không thể khởi tạo ứng dụng. Vui lòng tải lại trang.');
    }
});

function initializeApp() {
    // Load initial data with loading states
    Promise.allSettled([
        loadCategories(),
        loadFeaturedProducts(),
        loadTopSellers()
    ]).then(results => {
        results.forEach((result, index) => {
            if (result.status === 'rejected') {
                console.error(`Failed to load data ${index}:`, result.reason);
            }
        });
    });
    
    // Setup event listeners
    setupEventListeners();
    
    // Initialize user interface
    initializeUI();
    
    // Initialize performance optimizations
    initializePerformanceOptimizations();
}

// Enhanced load categories with better error handling
async function loadCategories() {
    const categoriesGrid = document.getElementById('categoriesGrid');
    if (!categoriesGrid) return;

    try {
        // Show loading state
        showLoadingState(categoriesGrid, 'Đang tải danh mục...');
        
        const response = await api.getCategories();
        if (response.success && response.data.categories) {
            displayCategories(response.data.categories);
        } else {
            throw new Error('Invalid response format');
        }
    } catch (error) {
        console.error('Error loading categories:', error);
        showErrorState(categoriesGrid, 'Không thể tải danh mục sách', () => loadCategories());
    }
}

// Enhanced display categories with animations
function displayCategories(categories) {
    const categoriesGrid = document.getElementById('categoriesGrid');
    if (!categoriesGrid) return;

    const categoriesHTML = categories.slice(0, 6).map((category, index) => `
        <div class="category-card animate-in" style="animation-delay: ${index * 100}ms">
            <div class="category-icon">${getCategoryIcon(category.name)}</div>
            <h3 class="category-name">${escapeHtml(category.name)}</h3>
            <p class="category-description">${escapeHtml(category.description || 'Khám phá bộ sưu tập sách đa dạng')}</p>
            <a href="pages/products/list.php?category=${category._id}" class="category-link">
                Xem sách
                <span class="arrow">→</span>
            </a>
        </div>
    `).join('');

    categoriesGrid.innerHTML = categoriesHTML;
    
    // Add intersection observer for animations
    const cards = categoriesGrid.querySelectorAll('.category-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        observer.observe(card);
    });
}

// Get appropriate icon for category
function getCategoryIcon(categoryName) {
    const iconMap = {
        'Văn học': '📖',
        'Khoa học': '🔬',
        'Lịch sử': '📜',
        'Kinh tế': '💰',
        'Công nghệ': '💻',
        'Nghệ thuật': '🎨',
        'Thể thao': '⚽',
        'Du lịch': '✈️',
        'Nấu ăn': '🍳',
        'Sức khỏe': '💊'
    };
    
    for (const [key, icon] of Object.entries(iconMap)) {
        if (categoryName.toLowerCase().includes(key.toLowerCase())) {
            return icon;
        }
    }
    
    return '📚'; // Default icon
}

// Enhanced load featured products with better error handling
async function loadFeaturedProducts() {
    const productsGrid = document.getElementById('productsGrid');
    if (!productsGrid) return;
    // If a page manages the products grid manually (e.g., products list mockup), skip
    if (productsGrid.dataset && productsGrid.dataset.managed === 'manual') return;

    try {
        // Show loading state
        showLoadingState(productsGrid, 'Đang tải sách nổi bật...');
        
        const response = await api.getFeaturedProducts();
        if (response.success && response.data.products) {
            displayProducts(response.data.products);
        } else {
            throw new Error('Invalid response format');
        }
    } catch (error) {
        console.error('Error loading featured products:', error);
        showErrorState(productsGrid, 'Không thể tải sách nổi bật', () => loadFeaturedProducts());
    }
}

// Enhanced display products with lazy loading and animations
function displayProducts(products) {
    const productsGrid = document.getElementById('productsGrid');
    if (!productsGrid) return;

    const productsHTML = products.map((product, index) => `
        <div class="product-card animate-in" style="animation-delay: ${index * 100}ms">
            <div class="product-image-container">
                <img data-src="${(product.images && product.images[0] && (product.images[0].url || product.images[0])) || 'assets/images/placeholder-book.svg'}" 
                     alt="${escapeHtml(product.title)}" 
                     class="product-image lazy"
                     onerror="this.src='assets/images/placeholder-book.svg'">
                <div class="product-badge">
                    ${product.isFeatured ? '<span class="badge featured">Nổi bật</span>' : ''}
                    ${product.originalPrice && product.originalPrice > product.price ? 
                        `<span class="badge discount">-${Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%</span>` : ''}
                </div>
            </div>
            <div class="product-info">
                <h3 class="product-title">${escapeHtml(product.title)}</h3>
                <p class="product-author">Tác giả: ${escapeHtml(product.author)}</p>
                <div class="product-rating">
                    <div class="stars">${generateStars(product.rating.average)}</div>
                    <span class="rating-text">(${product.rating.count} đánh giá)</span>
                </div>
                <div class="product-price">
                    ${api.formatPrice(product.price)}
                    ${product.originalPrice && product.originalPrice > product.price ? 
                        `<span class="original-price">${api.formatPrice(product.originalPrice)}</span>` : ''}
                </div>
                <div class="product-actions">
                    <button class="btn btn-primary" onclick="addToCart('${product._id}')" data-product-id="${product._id}">
                        <span class="btn-text">Thêm vào giỏ</span>
                        <span class="btn-icon">🛒</span>
                    </button>
                    <a href="pages/products/detail.php?id=${product._id}" class="btn btn-outline">
                        Xem chi tiết
                    </a>
                </div>
            </div>
        </div>
    `).join('');

    productsGrid.innerHTML = productsHTML;
    
    // Setup lazy loading for images
    const lazyImages = productsGrid.querySelectorAll('.lazy');
    lazyImages.forEach(img => imageObserver.observe(img));
    
    // Add intersection observer for animations
    const cards = productsGrid.querySelectorAll('.product-card');
    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });
        
        observer.observe(card);
    });
}

// Load top sellers from API
async function loadTopSellers() {
    try {
        const response = await api.getSellers({ limit: 6 });
        if (response.success) {
            displaySellers(response.data.sellers);
        }
    } catch (error) {
        console.error('Error loading top sellers:', error);
        showError('Không thể tải danh sách người bán');
    }
}

// Display sellers in the grid
function displaySellers(sellers) {
    const sellersGrid = document.getElementById('sellersGrid');
    if (!sellersGrid) return;

    const sellersHTML = sellers.map(seller => `
        <div class="seller-card">
            <div class="seller-avatar">
                <img src="${seller.profile?.avatar || 'assets/images/default-avatar.svg'}" 
                     alt="${seller.username}" 
                     class="avatar-image"
                     onerror="this.src='assets/images/default-avatar.svg'">
            </div>
            <div class="seller-info">
                <h3 class="seller-name">${seller.sellerProfile?.businessName || seller.username}</h3>
                <p class="seller-description">${seller.sellerProfile?.description || 'Người bán uy tín'}</p>
                <div class="seller-stats">
                    <span class="stat">⭐ 4.8/5</span>
                    <span class="stat">📦 100+ sản phẩm</span>
                </div>
                <a href="pages/sellers/top-sellers.php" class="btn btn-outline btn-center">
                    Xem cửa hàng
                </a>
            </div>
        </div>
    `).join('');

    sellersGrid.innerHTML = sellersHTML;
}

// Generate star rating display
function generateStars(rating) {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);
    
    return '★'.repeat(fullStars) + 
           (hasHalfStar ? '☆' : '') + 
           '☆'.repeat(emptyStars);
}

// Enhanced add product to cart with better UX
async function addToCart(productId) {
    const button = document.querySelector(`[data-product-id="${productId}"]`);
    if (!button) return;

    try {
        // Show loading state on button
        const originalText = button.innerHTML;
        button.innerHTML = '<span class="btn-text">Đang thêm...</span><span class="btn-icon">⏳</span>';
        button.disabled = true;

        // Get product details first
        const response = await api.getProduct(productId);
        if (response.success) {
            api.addToCart(response.data.product);
            
            // Show success animation
            button.innerHTML = '<span class="btn-text">Đã thêm!</span><span class="btn-icon">✅</span>';
            button.classList.add('success');
            
            // Show toast notification
            showToast('Đã thêm sản phẩm vào giỏ hàng', 'success');
            
            // Reset button after animation
            setTimeout(() => {
                button.innerHTML = originalText;
                button.disabled = false;
                button.classList.remove('success');
            }, 2000);
        } else {
            throw new Error('Failed to get product details');
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
        
        // Show error state
        button.innerHTML = '<span class="btn-text">Lỗi!</span><span class="btn-icon">❌</span>';
        button.classList.add('error');
        
        showToast('Không thể thêm sản phẩm vào giỏ hàng', 'error');
        
        // Reset button after error
        setTimeout(() => {
            button.innerHTML = originalText;
            button.disabled = false;
            button.classList.remove('error');
        }, 2000);
    }
}

// Setup event listeners
function setupEventListeners() {
    // User dropdown toggle
    const userBtn = document.getElementById('userBtn');
    const userDropdown = document.getElementById('userDropdown');
    
    if (userBtn && userDropdown) {
        // Toggle on click
        userBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            const isExpanded = userBtn.getAttribute('aria-expanded') === 'true';
            
            // Toggle dropdown visibility
            if (isExpanded) {
                userBtn.setAttribute('aria-expanded', 'false');
                userDropdown.setAttribute('aria-hidden', 'true');
                userDropdown.classList.remove('show');
                userDropdown.style.display = 'none';
            } else {
                userBtn.setAttribute('aria-expanded', 'true');
                userDropdown.setAttribute('aria-hidden', 'false');
                userDropdown.classList.add('show');
                userDropdown.style.display = 'block';
            }
        }, true);

        // Close dropdown when clicking outside
        document.addEventListener('click', function(e) {
            if (!userBtn.contains(e.target) && !userDropdown.contains(e.target)) {
                userBtn.setAttribute('aria-expanded', 'false');
                userDropdown.setAttribute('aria-hidden', 'true');
                userDropdown.classList.remove('show');
                userDropdown.style.display = 'none';
            }
        });
        
        // Close dropdown when pressing Escape
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                userBtn.setAttribute('aria-expanded', 'false');
                userDropdown.setAttribute('aria-hidden', 'true');
                userDropdown.classList.remove('show');
                userDropdown.style.display = 'none';
            }
        });
    }

    // Search form submission
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const searchInput = this.querySelector('.search-input');
            const query = searchInput.value.trim();
            
            if (query) {
                window.location.href = `pages/products/list.php?search=${encodeURIComponent(query)}`;
            }
        });
    }

    // Check authentication status
    checkAuthStatus();
}

// Check if user is authenticated
async function checkAuthStatus() {
    try {
        const response = await api.getCurrentUser();
        if (response.success) {
            updateUserInterface(response.data.user);
        }
    } catch (error) {
        // User is not authenticated
        console.log('User not authenticated');
    }
}

// Update user interface based on authentication status
function updateUserInterface(user) {
    const userDropdown = document.getElementById('userDropdown');
    const userBtn = document.getElementById('userBtn');
    if (userBtn && user) {
        const labelSpan = userBtn.querySelector('span:nth-child(2)');
        if (labelSpan) {
            const displayName = (user.profile?.firstName || user.profile?.lastName)
                ? `${user.profile?.firstName || ''} ${user.profile?.lastName || ''}`.trim()
                : (user.username || 'Tài khoản');
            labelSpan.textContent = displayName;
        }
    }
    if (userDropdown && user) {
        const balance = user.wallet?.balance ?? 0;
        const fmt = (window.api && typeof window.api.formatPrice === 'function')
            ? window.api.formatPrice(balance)
            : `${balance} VND`;
        userDropdown.innerHTML = `
            <div class="dropdown-balance">Số dư ví: <strong>${fmt}</strong></div>
            <hr>
            <a href="profile.php" class="dropdown-link">Hồ sơ cá nhân</a>
            <a href="orders.php" class="dropdown-link">Đơn hàng</a>
            <a href="wishlist.php" class="dropdown-link">Yêu thích</a>
            <a href="settings.php" class="dropdown-link">Cài đặt</a>
            <hr>
            <a href="#" class="dropdown-link" onclick="logout()">Đăng xuất</a>
        `;
    }
}

// Logout function
async function logout() {
    try {
        await api.logout();
        api.clearToken();
        location.reload();
    } catch (error) {
        console.error('Logout error:', error);
        // Clear token anyway
        api.clearToken();
        location.reload();
    }
}

// Initialize UI components
function initializeUI() {
    // Add loading states
    addLoadingStates();
    
    // Initialize tooltips
    initializeTooltips();
    
    // Initialize animations
    initializeAnimations();
}

// Add loading states to dynamic content
function addLoadingStates() {
    const grids = ['categoriesGrid', 'productsGrid', 'sellersGrid'];
    
    grids.forEach(gridId => {
        const grid = document.getElementById(gridId);
        if (grid) {
            if (grid.dataset && grid.dataset.managed === 'manual') return;
            grid.innerHTML = `
                <div class="loading">
                    <div class="spinner"></div>
                </div>
            `;
        }
    });
}

// Initialize tooltips
function initializeTooltips() {
    // Add tooltip functionality if needed
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

// Show tooltip
function showTooltip(e) {
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = e.target.dataset.tooltip;
    document.body.appendChild(tooltip);
    
    const rect = e.target.getBoundingClientRect();
    tooltip.style.left = rect.left + rect.width / 2 - tooltip.offsetWidth / 2 + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 10 + 'px';
}

// Hide tooltip
function hideTooltip() {
    const tooltip = document.querySelector('.tooltip');
    if (tooltip) {
        tooltip.remove();
    }
}

// Initialize animations
function initializeAnimations() {
    // Add scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-in');
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const animateElements = document.querySelectorAll('.category-card, .product-card, .seller-card');
    animateElements.forEach(el => observer.observe(el));
}

// Enhanced utility functions
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showLoadingState(container, message = 'Đang tải...') {
    container.innerHTML = `
        <div class="loading-state">
            <div class="spinner"></div>
            <p class="loading-text">${message}</p>
        </div>
    `;
}

function showErrorState(container, message, retryCallback = null) {
	container.innerHTML = `
		<div class="error-state">
			<div class="error-icon">⚠️</div>
			<p class="error-text">${message}</p>
			${retryCallback ? `<button class="btn btn-outline" onclick="(${retryCallback.toString()})()">Thử lại</button>` : ''}
		</div>
	`;
}

// Global function to load user info in navigation (used across all pages)
window.loadUserInfo = async function() {
    try {
        const token = localStorage.getItem('bookverse_token');
        if (!token) return;
        
        const response = await api.getUserProfile();
        if (response.success && response.data.user) {
            const user = response.data.user;
            const username = user.username || user.profile?.firstName || user.email?.split('@')[0] || 'User';
            
            // Update user button text
            const userBtn = document.getElementById('userBtn');
            if (userBtn) {
                const span = userBtn.querySelector('span');
                if (span && (span.textContent === 'User' || span.textContent === 'Tài khoản')) {
                    span.textContent = username;
                    console.log('✅ User info loaded:', username);
                }
            }
        }
    } catch (error) {
        console.error('❌ Error loading user info:', error);
    }
}

// Auto-load user info on all pages
document.addEventListener('DOMContentLoaded', function() {
    if (localStorage.getItem('bookverse_token')) {
        window.loadUserInfo();
    }
});