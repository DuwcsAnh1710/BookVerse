# Bookverse Logo Collection

## Tổng Quan
Bộ logo Bookverse được thiết kế với phong cách hiện đại, chuyên nghiệp và dễ nhận biết. Logo sử dụng gradient màu xanh-tím đặc trưng và icon sách đơn giản nhưng ấn tượng.

## Các Phiên Bản Logo

### 1. Full Logo (logo.svg)
- **Kích thước:** 200x60px
- **Sử dụng:** Header chính của website
- **Đặc điểm:** Bao gồm icon sách và text "Bookverse"
- **Màu sắc:** Gradient xanh-tím với hiệu ứng shadow

### 2. Icon Only (logo-icon.svg)
- **Kích thước:** 48x48px
- **Sử dụng:** Mobile header, favicon, social media
- **Đặc điểm:** Chỉ có icon sách với bookmark đỏ
- **Màu sắc:** Gradient xanh-tím với background tròn

### 3. Text Only (logo-text.svg)
- **Kích thước:** 180x40px
- **Sử dụng:** Email signature, documents, khi cần tiết kiệm không gian
- **Đặc điểm:** Chỉ có text "Bookverse" với gradient
- **Màu sắc:** Gradient xanh-tím với decorative dot

### 4. Favicon (favicon.svg)
- **Kích thước:** 32x32px
- **Sử dụng:** Browser tab, bookmarks
- **Đặc điểm:** Icon sách đơn giản với background vuông
- **Màu sắc:** Gradient xanh-tím

## Hướng Dẫn Sử Dụng

### Website
- **Header Desktop:** Sử dụng `logo.svg`
- **Header Mobile:** Sử dụng `logo-icon.svg`
- **Footer:** Sử dụng `logo-text.svg`

### Marketing Materials
- **Business Cards:** Sử dụng `logo.svg`
- **Email Signature:** Sử dụng `logo-text.svg`
- **Social Media:** Sử dụng `logo-icon.svg`

### Digital Assets
- **Favicon:** Sử dụng `favicon.svg`
- **App Icons:** Sử dụng `logo-icon.svg`
- **Print Materials:** Sử dụng `logo.svg`

## Màu Sắc

### Primary Colors
- **Gradient Start:** #667eea (Blue)
- **Gradient End:** #764ba2 (Purple)
- **Accent Color:** #ff6b6b (Red bookmark)
- **Highlight:** #ffd93d (Yellow sparkle)

### Usage Guidelines
- Luôn sử dụng logo với gradient gốc
- Không thay đổi màu sắc của logo
- Đảm bảo contrast tốt với background
- Sử dụng logo với kích thước tối thiểu 24px

## Kích Thước Tối Thiểu

- **Full Logo:** 120px width
- **Icon Only:** 24px width/height
- **Text Only:** 100px width
- **Favicon:** 16px width/height

## File Formats

- **SVG:** Vector format, scalable, recommended
- **PNG:** Raster format, fallback option
- **ICO:** Favicon format for browsers

## Technical Specifications

### SVG Features
- Scalable vector graphics
- CSS-compatible
- Optimized for web
- Cross-browser support

### Performance
- File size: < 5KB each
- Load time: < 100ms
- Compatible with all modern browsers

## Brand Guidelines

### Do's ✅
- Sử dụng logo với đầy đủ màu sắc
- Giữ nguyên tỷ lệ aspect ratio
- Đảm bảo khoảng trắng xung quanh logo
- Sử dụng logo trên background có contrast tốt

### Don'ts ❌
- Không thay đổi màu sắc
- Không kéo dãn logo
- Không đặt logo trên background tương tự màu
- Không sử dụng logo với kích thước quá nhỏ

## Download Links

- [Full Logo](logo.svg)
- [Icon Only](logo-icon.svg)
- [Text Only](logo-text.svg)
- [Favicon](favicon.svg)

## Support

Nếu cần hỗ trợ về logo hoặc muốn tạo thêm phiên bản khác, vui lòng liên hệ team design.

---

**© 2025 Bookverse. All rights reserved.**
